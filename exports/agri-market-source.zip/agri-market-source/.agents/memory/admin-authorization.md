---
name: Admin authorization and retention
description: Security and data-retention rules for marketplace administration.
---

Administrative access must be enforced by the API using a verified Clerk session plus an allowed role; frontend route guards are only a user-experience layer. Ordinary listing mutations must resolve the current Clerk-linked marketplace user and enforce seller ownership.

**Why:** Hiding links or guarding React routes does not protect direct API calls. Marketplace records are also referenced by payments, messages, reports, and saved items, so physical deletion can break history and foreign-key relationships.

**How to apply:** Require server authorization for every administrative mutation and ownership checks for seller mutations. Treat destructive admin actions on listings, packages, payment methods, categories, and subcategories as soft deletion or deactivation unless an explicit retention migration approves physical deletion.

Implicit local administrator provisioning is reserved for the first Clerk identity with an administrator claim. Explicitly claimed moderators may bootstrap an additional local moderator, while another administrator must still be explicitly added through administrator management.

**Why:** Clerk account changes can otherwise turn a changed administrator identity into a second local administrator while claim-based authorization continues to grant access; moderators are intentionally a separate, additive review role.

**How to apply:** Keep administrator bootstrap unique, allow only the verified moderator claim to create its own local moderator record, and require persisted local actors for protected routes after bootstrap.