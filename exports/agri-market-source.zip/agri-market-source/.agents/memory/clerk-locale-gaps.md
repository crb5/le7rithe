---
name: Clerk locale gaps
description: Non-obvious missing French strings in Clerk's official localization bundle.
---

Use Clerk's official Arabic, French, and English locale objects, while preserving the project's narrow French sign-up overrides for the password placeholder and password-visibility accessibility label.

**Why:** The official French locale used by this project left the sign-up password placeholder undefined and the visibility toggle labelled in English during browser testing.

**How to apply:** When changing Clerk localization or upgrading its packages, retest both concealed and revealed password states in French before removing the overrides. Language changes must update localization without keying or remounting ClerkProvider so the active session survives.