---
name: Playwright browser runtime
description: Environment behavior affecting authenticated browser regression execution.
---

The environment can expose a working Chromium binary at `/repl/tools/bin/chromium`, but the installed Playwright test runner may still resolve its own browser-cache path instead of honoring the configured executable override.

**Why:** Browser regression failures can occur before any test code runs, so they should not be mistaken for application or authentication regressions.

**How to apply:** Verify the managed binary with a direct Playwright launch and separately confirm the test runner’s resolved browser before changing application code or adding project-specific browser configuration.