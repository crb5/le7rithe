---
name: Authenticated-only marketplace
description: Project-wide access policy for the marketplace UI and API.
---

Require an active Clerk session before rendering any marketplace or administration route and before serving any API route. Only the Clerk sign-in and sign-up experiences remain reachable while signed out.

**Why:** The product owner explicitly requires the entire site, including formerly public listings and categories, to be private. Logout and browser history must never reveal protected content.

**How to apply:** New frontend routes belong behind the global auth gate by default, and new API routes belong after the global Clerk middleware. Preserve sign-in/sign-up access and verify direct URLs, logout, Back navigation, and unauthenticated API responses.