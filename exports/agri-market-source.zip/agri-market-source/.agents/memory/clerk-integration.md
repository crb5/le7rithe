---
name: Clerk integration in the workspace
description: Setup and dependency behavior for Replit-managed Clerk in this pnpm workspace.
---

Install Clerk dependencies with workspace filters targeting the API and web packages; a root-level package install is rejected by pnpm's workspace-root guard. Replit-managed Clerk also requires the server proxy middleware and the client provider wiring, even though development uses Clerk's direct frontend API.

**Why:** The workspace is a pnpm monorepo with auto-install peers disabled, so package ownership and the production proxy must be explicit.

**How to apply:** When another web artifact needs Clerk, install its packages in that artifact, reuse the canonical proxy/provider pattern from the Clerk skill, and restart the managed API and web workflows together before validating.

Authenticated browser storage states created by the E2E setup use short-lived Clerk sign-in tickets; refresh them immediately before long-running browser runs if a test unexpectedly lands on sign-in.

**Why:** A valid storage file can still expire between setup and execution, producing misleading UI timeouts instead of an application failure.

**How to apply:** Run the E2E auth setup before authenticated browser validation when the existing storage states are stale or the test redirects to `/sign-in`.

Protected marketplace query components must render only after the Clerk token getter is registered with the shared API client.

**Why:** Registering the getter in an effect while rendering query hooks immediately can let the first request run without its bearer token, even though Clerk already reports a signed-in user.

**How to apply:** Keep the auth bridge ahead of protected query consumers and gate their initial render until registration completes; cover both generated API calls and manual upload fetches in browser tests.