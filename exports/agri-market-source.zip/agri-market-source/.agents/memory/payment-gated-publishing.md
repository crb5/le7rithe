---
name: Payment-gated publishing
description: Marketplace publication rules for paid listings.
---

An agricultural listing must not become publicly active until an administrator confirms a payment linked to that listing and then explicitly approves publication. Payment confirmation and publication are separate administrative actions; listing moderation must never bypass either gate.

**Why:** Manual payments are reviewed outside the application, so publishing before receipt is confirmed would expose unpaid listings and undermine the marketplace’s revenue and trust controls.

**How to apply:** Keep new and edited listings in `pending_payment` or another non-public state, make public queries depend on `active`, let payment review change only the payment record (or reject the listing), and require a confirmed linked payment before the separate administrative publish action.