---
name: Payment proof storage
description: The current manual payment flow's proof-image storage boundary and production migration requirement.
---

Payment proof images use private object storage with a short-lived presigned upload and an access-controlled object path persisted in the payment record. In development only, when App Storage is unavailable, the API uses a bounded in-memory upload fallback; production still requires App Storage.

**Why:** Payment evidence should not cause large PostgreSQL rows or expose a permanent public data URL.

**How to apply:** Keep the upload path private and serve proofs only through authenticated admin routes; never reintroduce data URLs or public object URLs into payment records. Treat the development fallback as temporary test support, not durable storage.