import { defineConfig } from '@playwright/test';

const baseURL =
  process.env.E2E_BASE_URL ??
  (process.env.REPLIT_DEV_DOMAIN
    ? `https://${process.env.REPLIT_DEV_DOMAIN}`
    : undefined);

export default defineConfig({
  testDir: './',
  fullyParallel: false,
  forbidOnly: Boolean(process.env.CI),
  retries: process.env.CI ? 2 : 0,
  reporter: process.env.CI ? 'dot' : 'list',
  timeout: 120_000,
  expect: { timeout: 15_000 },
  use: {
    baseURL,
    launchOptions: {
      executablePath: process.env.REPLIT_PLAYWRIGHT_CHROMIUM_EXECUTABLE,
    },
    trace: 'retain-on-failure',
    video: 'retain-on-failure',
    screenshot: 'only-on-failure',
  },
  projects: [
    {
      name: 'general-e2e',
      testMatch: '**/*.spec.ts',
      testIgnore: '**/payment-review-flow.spec.ts',
    },
    {
      name: 'payment-review-auth',
      testMatch: '**/payment-review-auth.setup.ts',
    },
    {
      name: 'payment-review',
      testMatch: '**/payment-review-flow.spec.ts',
      dependencies: ['payment-review-auth'],
    },
  ],
});
