import { expect, request, test, type BrowserContext, type Page, type Request, type Response } from '@playwright/test';
import { resolve } from 'node:path';

const defaultAuthDir = resolve(process.cwd(), 'e2e/.auth');
const sellerStorageState =
  process.env.E2E_SELLER_STORAGE_STATE ?? resolve(defaultAuthDir, 'seller.json');
const secondSellerStorageState =
  process.env.E2E_SECOND_SELLER_STORAGE_STATE ??
  resolve(defaultAuthDir, 'second-seller.json');
const adminStorageState =
  process.env.E2E_ADMIN_STORAGE_STATE ?? resolve(defaultAuthDir, 'admin.json');
const moderatorStorageState =
  process.env.E2E_MODERATOR_STORAGE_STATE ?? resolve(defaultAuthDir, 'moderator.json');
const secondaryAdminStorageState =
  process.env.E2E_SECONDARY_ADMIN_STORAGE_STATE ?? resolve(defaultAuthDir, 'admin-secondary.json');

const proofPng = Buffer.from(
  'iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mNk+A8AAQUBAScY42YAAAAASUVORK5CYII=',
  'base64',
);

type PaymentOptions = {
  packages: Array<{
    id: number;
    name: string;
    price: string;
    currency: string;
    durationDays: number;
    featured: boolean;
    pinned: boolean;
  }>;
  methods: Array<{ id: number; name: string }>;
};

type Payment = {
  id: number;
  listingId: number;
  amount: string;
  currency: string;
  status: string;
  transactionReference: string;
  package?: { id: number; name: string; price: string; currency: string } | null;
  method?: { id: number; name: string } | null;
};

type Listing = {
  id: number;
  title: string;
  status?: string;
  featured?: boolean;
  expiresAt?: string | null;
  contactPhone?: string | null;
  price?: number;
};

type Notification = {
  type: string;
  body: string;
};

type JsonResponse = {
  status(): number;
  text(): Promise<string>;
  json(): Promise<unknown>;
};

const expectedPaymentProofStorage = process.env.E2E_PAYMENT_PROOF_STORAGE;
if (
  expectedPaymentProofStorage !== undefined &&
  expectedPaymentProofStorage !== 'local' &&
  expectedPaymentProofStorage !== 'private'
) {
  throw new Error('E2E_PAYMENT_PROOF_STORAGE must be "local" or "private" when provided.');
}

async function expectJson<T>(response: JsonResponse, status: number): Promise<T> {
  expect(response.status(), await response.text()).toBe(status);
  return (await response.json()) as T;
}

async function createListing(
  page: Page,
  title: string,
  contactPhone = '+222 36 12 45 67',
): Promise<Listing> {
  await page.goto('/add-listing');
  await page.getByTestId('input-listing-title').fill(title);
  await page.getByTestId('select-listing-category').selectOption('tractors');
  await page.getByTestId('select-listing-location').selectOption({ index: 1 });
  await page.getByTestId('input-listing-price').fill('125000');
  await page.getByTestId('input-listing-contact-phone').fill(contactPhone);
  await page.getByTestId('textarea-listing-description').fill('Authenticated payment review flow test listing.');
  const listingResponsePromise = page.waitForResponse(
    (response) =>
      response.url().includes('/api/listings') &&
      response.request().method() === 'POST',
  );
  await page.getByTestId('button-submit-listing').click();
  const listingResponse = await listingResponsePromise;
  expect(listingResponse.status()).toBe(201);
  const listingId = await page
    .getByTestId('payment-confirmation-panel')
    .getAttribute('data-listing-id');
  expect(listingId).toMatch(/^\d+$/);
  const listing = { id: Number(listingId), title } satisfies Listing;
  await expect(page.getByTestId('select-payment-package')).toBeVisible();
  expect(listing.title).toBe(title);
  await expectJson(await page.context().request.get(`/api/listings/${listing.id}`), 404);
  return listing;
}

async function submitPayment(page: Page, listing: Listing, reference: string): Promise<Payment> {
  const optionsResponse = await page.context().request.get('/api/payment-options');
  const options = await expectJson<PaymentOptions>(optionsResponse, 200);
  const paymentPackage =
    options.packages.find((item) => item.featured && !item.pinned) ??
    options.packages.find((item) => item.featured);
  const paymentMethod = options.methods[0];
  if (!paymentPackage) throw new Error('No featured payment package is configured');
  if (!paymentMethod) throw new Error('No payment method is configured');

  await page.getByTestId('select-payment-package').selectOption(String(paymentPackage.id));
  await page.getByTestId('select-payment-method').selectOption(String(paymentMethod.id));
  await page.getByTestId('input-payment-reference').fill(reference);
  await page.getByTestId('input-payment-account-holder').fill('Payment Flow Test User');
  await page.getByTestId('input-payment-proof').setInputFiles({
    name: `${reference}.png`,
    mimeType: 'image/png',
    buffer: proofPng,
  });

  const pageOrigin = new URL(page.url()).origin;
  const paymentProofUploadRequests: Array<{ url: string; headers: Record<string, string> }> = [];
  const paymentProofUploadResponses: Array<{ url: string; status: number }> = [];
  const recordPaymentProofUploadRequest = (request: Request) => {
    if (request.method() === 'PUT' && request.headers()['content-type'] === 'image/png') {
      paymentProofUploadRequests.push({ url: request.url(), headers: request.headers() });
    }
  };
  const recordPaymentProofUploadResponse = (response: Response) => {
    if (response.request().method() === 'PUT' && response.request().headers()['content-type'] === 'image/png') {
      paymentProofUploadResponses.push({ url: response.url(), status: response.status() });
    }
  };
  page.on('request', recordPaymentProofUploadRequest);
  page.on('response', recordPaymentProofUploadResponse);
  const proofUploadResponsePromise = page.waitForResponse(
    (response) =>
      response.url().includes('/api/payment-proof/uploads/request-url') &&
      response.request().method() === 'POST',
  );
  const proofUploadRequestPromise = page.waitForRequest(
    (request) =>
      request.url().includes('/api/payment-proof/uploads/request-url') &&
      request.method() === 'POST',
  );
  try {
    await page.getByTestId('button-submit-payment').click();
    const proofUploadRequest = await proofUploadRequestPromise;
    expect(proofUploadRequest.headers().authorization, 'Payment proof request-url must include the Clerk bearer token').toMatch(/^Bearer \S+$/);
    const proofUploadResponse = await proofUploadResponsePromise;
    const proofUpload = await expectJson<{
      uploadURL: string;
      objectPath: string;
    }>(proofUploadResponse, 200);
    expect(proofUploadResponse.status(), 'Payment proof request-url must not be rejected as unauthorized').not.toBe(401);
    expect(proofUpload.objectPath).toMatch(
      /^\/objects\/uploads\/[0-9a-f-]{36}\.[A-Za-z0-9_-]{43}$/i,
    );
    expect(
      proofUpload.uploadURL.startsWith('/api/payment-proof/uploads/local/') ||
        proofUpload.uploadURL.startsWith('https://'),
    ).toBe(true);

    const resolvedUploadURL = new URL(proofUpload.uploadURL, pageOrigin).toString();
    const proofStorage =
      new URL(resolvedUploadURL).origin === pageOrigin ? 'local' : 'private';
    if (expectedPaymentProofStorage) {
      expect(proofStorage).toBe(expectedPaymentProofStorage);
    }
    expect(proofUpload.objectPath).not.toMatch(/^https?:\/\//);
    const proofFileUpload = paymentProofUploadRequests.find((request) => request.url === resolvedUploadURL);
    const proofFileUploadResponse = paymentProofUploadResponses.find((response) => response.url === resolvedUploadURL);
    expect(proofFileUpload, 'Payment proof file upload request was not sent').toBeDefined();
    expect(proofFileUploadResponse, 'Payment proof file upload response was not received').toBeDefined();
    expect(proofFileUploadResponse!.status, 'Payment proof file upload must not be rejected as unauthorized').not.toBe(401);
    if (new URL(resolvedUploadURL).origin === pageOrigin) {
      expect(proofFileUpload!.headers.authorization, 'Same-origin payment proof upload must include the Clerk bearer token').toMatch(/^Bearer \S+$/);
    }

    await expect(page).toHaveURL(/\/dashboard$/);
  } finally {
    page.off('request', recordPaymentProofUploadRequest);
    page.off('response', recordPaymentProofUploadResponse);
  }

  const paymentsResponse = await page.context().request.get('/api/payments/mine');
  const payments = await expectJson<{ items: Payment[] }>(paymentsResponse, 200);
  const payment = payments.items.find((item) => item.transactionReference === reference);
  expect(payment, `Could not find payment "${reference}"`).toBeTruthy();
  expect(payment!.listingId).toBe(listing.id);
  expect(payment!.status).toBe('pending');
  expect(payment!.package?.id).toBe(paymentPackage.id);
  expect(payment!.method?.id).toBe(paymentMethod.id);
  return payment!;
}

async function uploadPaymentProof(context: BrowserContext): Promise<string> {
  const uploadResponse = await context.request.post('/api/payment-proof/uploads/request-url', {
    data: {
      name: 'reused-proof.png',
      size: proofPng.length,
      contentType: 'image/png',
    },
  });
  const upload = await expectJson<{ uploadURL: string; objectPath: string }>(
    uploadResponse,
    200,
  );
  const fileResponse = await context.request.put(upload.uploadURL, {
    data: proofPng,
    headers: { 'content-type': 'image/png' },
  });
  expect(fileResponse.status(), await fileResponse.text()).toBeLessThan(300);
  return upload.objectPath;
}

async function submitPaymentWithProof(
  context: BrowserContext,
  listing: Listing,
  proofObjectPath: string,
  reference: string,
): Promise<JsonResponse> {
  const options = await expectJson<PaymentOptions>(
    await context.request.get('/api/payment-options'),
    200,
  );
  const paymentPackage =
    options.packages.find((item) => item.featured && !item.pinned) ??
    options.packages.find((item) => item.featured);
  const paymentMethod = options.methods[0];
  if (!paymentPackage) throw new Error('No featured payment package is configured');
  if (!paymentMethod) throw new Error('No payment method is configured');

  return context.request.post('/api/payments', {
    data: {
      listingId: listing.id,
      packageId: paymentPackage.id,
      paymentMethodId: paymentMethod.id,
      amount: Number(paymentPackage.price),
      transactionReference: reference,
      transactionDate: new Date().toISOString(),
      accountHolderName: 'Payment Proof Ownership Test',
      proofObjectPath,
    },
  });
}

const featuredHeadings = {
  ar: 'إعلانات تستحق المشاهدة',
  fr: 'Des annonces à découvrir',
  en: 'Listings worth a look',
} as const;

async function expectFeaturedListingOnHome(
  page: Page,
  title: string,
  language: keyof typeof featuredHeadings,
  visible: boolean,
) {
  const featuredResponsePromise = page.waitForResponse(
    (response) =>
      response.url().includes('/api/listings') &&
      response.url().includes('featured=true') &&
      response.request().method() === 'GET',
  );
  await page.goto('/');
  expect((await featuredResponsePromise).status()).toBe(200);
  await page.getByTestId('select-language').selectOption(language);
  await expect(page.getByTestId('select-language')).toHaveValue(language);

  const featuredSection = page.getByTestId('section-featured-listings');
  await expect(
    featuredSection.getByRole('heading', { name: featuredHeadings[language] }),
  ).toBeVisible();
  const listingTitle = featuredSection.getByText(title, { exact: true });
  if (visible) {
    await expect(listingTitle).toBeVisible();
  } else {
    await expect(listingTitle).toHaveCount(0);
  }
}

async function getListing(context: BrowserContext, title: string): Promise<Listing> {
  const response = await context.request.get(`/api/admin/listings?q=${encodeURIComponent(title)}`);
  const body = await expectJson<{ items: Listing[] }>(response, 200);
  const listing = body.items.find((item) => item.title === title);
  expect(listing, `Could not find admin listing "${title}"`).toBeTruthy();
  return listing!;
}

async function getPaymentProofAudits(
  context: BrowserContext,
  paymentId: number,
): Promise<Array<{ action: string; resourceId: number | null; actorClerkUserId: string | null }>> {
  const response = await context.request.get('/api/admin/audit-logs');
  const body = await expectJson<{
    items: Array<{ action: string; resourceId: number | null; actorClerkUserId: string | null }>;
  }>(response, 200);
  return body.items.filter(
    (item) => item.action === 'payment.proof_viewed' && item.resourceId === paymentId,
  );
}

async function reviewPayment(
  page: Page,
  context: BrowserContext,
  sellerContext: BrowserContext,
  moderatorContext: BrowserContext | null,
  payment: Payment,
  listingTitle: string,
  status: 'confirmed' | 'rejected',
  reason?: string,
) {
  await page.goto('/admin/payments');
  const pageOrigin = new URL(page.url()).origin;
  await page.locator('main select').first().selectOption('en');
  const statusFilter = page.locator('main select').nth(1);
  const pendingQueueResponsePromise = page.waitForResponse(
    (response) =>
      response.url().includes('/api/admin/payments?status=pending') &&
      response.request().method() === 'GET',
  );
  await statusFilter.selectOption('pending');
  await expect(statusFilter).toHaveValue('pending');
  const pendingQueue = await expectJson<{
    items: Array<Payment & {
      user: { id: number; name: string | null; email: string | null; phone: string | null };
      listing: { id: number; title: string; status: string; createdAt: string } | null;
      package: { id: number; name: string; price: string; currency: string } | null;
      method: { id: number; name: string } | null;
      proofImageUrl: string | null;
    }>;
  }>(await pendingQueueResponsePromise, 200);
  const queuedPayment = pendingQueue.items.find((item) => item.id === payment.id);
  expect(queuedPayment).toMatchObject({
    status: 'pending',
    listing: { id: payment.listingId, title: listingTitle },
    package: { name: payment.package?.name, price: payment.amount, currency: payment.currency },
    method: { name: payment.method?.name },
    transactionReference: payment.transactionReference,
    proofImageUrl: `/api/admin/payments/${payment.id}/proof`,
  });
  expect(queuedPayment?.proofImageUrl).not.toMatch(/^https?:\/\//);

  const row = page.locator('tr').filter({ hasText: listingTitle });
  await expect(row).toBeVisible();
  await expect(row).toContainText(payment.package?.name || '');
  await expect(row.locator('td').nth(3)).toContainText(
    new Intl.NumberFormat('en-MR-u-nu-latn', {
      style: 'currency',
      currency: payment.currency,
    }).format(Number(payment.amount)),
  );
  await expect(row.locator('td').nth(4)).toContainText(payment.method?.name || '');
  await expect(row.locator('td').nth(5)).toContainText(payment.transactionReference);
  await expect(row.getByTestId(`link-payment-proof-${payment.id}`)).toHaveAttribute(
    'href',
    `/api/admin/payments/${payment.id}/proof`,
  );
  const auditsBeforeProofView = await getPaymentProofAudits(context, payment.id);
  expect(auditsBeforeProofView).toHaveLength(0);

  const proofResponse = await context.request.get(`/api/admin/payments/${payment.id}/proof`);
  const proofBody = await proofResponse.body();
  expect(proofResponse.status(), proofBody.toString()).toBe(200);
  expect(proofResponse.headers()['content-type']).toContain('image/png');
  expect(proofResponse.headers()['cache-control']).toBe('private, no-store');
  expect(proofResponse.headers()['x-content-type-options']).toBe('nosniff');
  expect(proofResponse.headers()['content-disposition']).toBe('inline');
  expect(proofBody).toEqual(proofPng);
  const auditsAfterAdminProofView = await getPaymentProofAudits(context, payment.id);
  expect(auditsAfterAdminProofView).toHaveLength(1);
  expect(auditsAfterAdminProofView[0]).toMatchObject({
    action: 'payment.proof_viewed',
    resourceId: payment.id,
  });
  expect(auditsAfterAdminProofView[0].actorClerkUserId).toBeTruthy();

  if (moderatorContext) {
    const moderatorProofResponse = await moderatorContext.request.get(
      `/api/admin/payments/${payment.id}/proof`,
    );
    const moderatorProofBody = await moderatorProofResponse.body();
    expect(moderatorProofResponse.status(), moderatorProofBody.toString()).toBe(200);
    expect(moderatorProofResponse.headers()['content-type']).toContain('image/png');
    expect(moderatorProofResponse.headers()['cache-control']).toBe('private, no-store');
    expect(moderatorProofResponse.headers()['x-content-type-options']).toBe('nosniff');
    expect(moderatorProofResponse.headers()['content-disposition']).toBe('inline');
    expect(moderatorProofBody).toEqual(proofPng);
    await expect
      .poll(() => getPaymentProofAudits(context, payment.id))
      .toHaveLength(2);
  }

  const sellerProofResponse = await sellerContext.request.get(
    `/api/admin/payments/${payment.id}/proof`,
  );
  const sellerProofBody = await expectJson<{ error: string }>(sellerProofResponse, 403);
  expect(sellerProofBody).toEqual({ error: 'Admin access required' });
  await expect
    .poll(() => getPaymentProofAudits(context, payment.id))
    .toHaveLength(moderatorContext ? 2 : 1);

  const unauthenticatedContext = await request.newContext({ baseURL: pageOrigin });
  try {
    const unauthenticatedProofResponse = await unauthenticatedContext.get(
      `/api/admin/payments/${payment.id}/proof`,
    );
    expect(unauthenticatedProofResponse.status()).toBe(401);
  } finally {
    await unauthenticatedContext.dispose();
  }

  const responsePromise = page.waitForResponse(
    (response) =>
      response.url().includes(`/api/admin/payments/${payment.id}/status`) &&
      response.request().method() === 'PATCH',
  );
  if (status === 'confirmed') {
    await row.getByTestId(`button-confirm-payment-${payment.id}`).click();
  } else {
    await row.getByTestId(`button-reject-payment-${payment.id}`).click();
    await page.locator('textarea').fill(reason!);
  }
  await page.getByRole('dialog').getByRole('button').last().click();
  await expect((await responsePromise).status()).toBe(200);

  const paymentsResponse = await context.request.get('/api/admin/payments');
  const payments = await expectJson<{ items: Payment[] }>(paymentsResponse, 200);
  expect(payments.items.find((item) => item.id === payment.id)?.status).toBe(status);
}

async function publishListing(page: Page, context: BrowserContext, listing: Listing) {
  await page.goto('/admin/payments');
  const row = page.locator('tr').filter({ hasText: listing.title });
  await expect(row).toBeVisible();
  const responsePromise = page.waitForResponse(
    (response) =>
      response.url().includes(`/api/admin/listings/${listing.id}/status`) &&
      response.request().method() === 'PATCH',
  );
  await row.getByTestId(`button-publish-listing-${listing.id}`).click();
  await page.getByRole('dialog').getByRole('button').last().click();
  await expect((await responsePromise).status()).toBe(200);
  const published = await getListing(context, listing.title);
  expect(published.status).toBe('active');
}

async function seedListingExpiration(listingId: number): Promise<() => Promise<void>> {
  const { pool } = await import('../lib/db/src/index');
  await pool.query(
    'UPDATE marketplace_listings SET expires_at = NOW() - INTERVAL \'1 second\' WHERE id = $1',
    [listingId],
  );
  return () => pool.end();
}

test.describe('payment review flow', () => {
  test('repeated admin requests keep one local administrator', async ({ browser }) => {
    const adminContext = await browser.newContext({ storageState: adminStorageState });
    const adminPage = await adminContext.newPage();
    try {
      await adminPage.goto('/admin');
      const responses = await Promise.all([
        adminContext.request.get('/api/admin/me'),
        adminContext.request.get('/api/admin/me'),
        adminContext.request.get('/api/admin/me'),
      ]);
      const meResponses = await Promise.all(
        responses.map((response) => expectJson<{
          role: string;
          user: { id: number; role: string } | null;
        }>(response, 200)),
      );
      expect(meResponses.map((response) => response.user?.id)).toEqual([
        meResponses[0].user?.id,
        meResponses[0].user?.id,
        meResponses[0].user?.id,
      ]);
      expect(meResponses[0]).toMatchObject({
        role: 'admin',
        user: { role: 'admin' },
      });

      const users = await expectJson<{
        items: Array<{ id: number; role: string; clerkUserId: string | null }>;
      }>(await adminContext.request.get('/api/admin/users'), 200);
      const administrators = users.items.filter(
        (user) => user.role === 'admin',
      );
      expect(administrators).toHaveLength(1);
      expect(administrators[0].id).toBe(meResponses[0].user?.id);
    } finally {
      await adminContext.close();
    }
  });

  test('a changed Clerk administrator cannot create a second local administrator', async ({ browser }) => {
    const adminContext = await browser.newContext({ storageState: adminStorageState });
    const secondaryAdminContext = await browser.newContext({ storageState: secondaryAdminStorageState });
    const adminPage = await adminContext.newPage();
    const secondaryAdminPage = await secondaryAdminContext.newPage();
    try {
      await adminPage.goto('/admin');
      await secondaryAdminPage.goto('/admin');
      const secondaryMe = await expectJson<{
        role: string;
        user: { id: number; role: string } | null;
      }>(await secondaryAdminContext.request.get('/api/admin/me'), 200);
      expect(secondaryMe).toEqual({ role: 'user', user: null, authenticated: true });
      await expectJson<{ error: string }>(
        await secondaryAdminContext.request.get('/api/admin/overview'),
        403,
      );

      const users = await expectJson<{
        items: Array<{ id: number; role: string }>;
      }>(await adminContext.request.get('/api/admin/users'), 200);
      expect(users.items.filter((user) => user.role === 'admin')).toHaveLength(1);
    } finally {
      await secondaryAdminContext.close();
      await adminContext.close();
    }
  });

  test('seller can submit payment and admin review updates listings and notifications', async ({ browser }) => {
  const sellerContext = await browser.newContext({ storageState: sellerStorageState });
  const secondSellerContext = await browser.newContext({ storageState: secondSellerStorageState });
  const adminContext = await browser.newContext({ storageState: adminStorageState });
  const moderatorContext = await browser.newContext({ storageState: moderatorStorageState });
  const sellerPage = await sellerContext.newPage();
  const adminPage = await adminContext.newPage();
  const runId = `${Date.now()}-${Math.random().toString(36).slice(2, 8)}`;
  const confirmedTitle = `E2E confirmed listing ${runId}`;
  const rejectedTitle = `E2E rejected listing ${runId}`;
  const rejectionReason = 'Payment proof does not match the transaction reference.';

  try {
    await adminPage.goto('/admin/notifications');
    const confirmedListing = await createListing(sellerPage, confirmedTitle);
    const adminNotifications = adminPage.locator('button').filter({ hasText: confirmedTitle });
    await expect(adminNotifications).toBeVisible({ timeout: 15_000 });
    const adminNotificationResponse = await adminContext.request.get('/api/admin/notifications');
    const adminNotificationBody = await expectJson<{
      items: Array<{ listingId: number; read: boolean; sellerName: string | null; listingTitle: string | null; paymentStatus: string }>;
      unreadCount: number;
    }>(adminNotificationResponse, 200);
    const newAdminNotification = adminNotificationBody.items.find(
      (item) => item.listingId === confirmedListing.id,
    );
    expect(newAdminNotification).toMatchObject({
      listingId: confirmedListing.id,
      read: false,
      listingTitle: confirmedTitle,
      paymentStatus: 'pending',
    });
    expect(adminNotificationBody.unreadCount).toBeGreaterThan(0);
    await adminNotifications.click();
    await expect(adminPage).toHaveURL(/\/admin\/listings\?status=pending_payment$/);
    const readAdminNotificationResponse = await adminContext.request.get('/api/admin/notifications');
    const readAdminNotificationBody = await expectJson<{
      items: Array<{ listingId: number; read: boolean }>;
    }>(readAdminNotificationResponse, 200);
    expect(readAdminNotificationBody.items.find((item) => item.listingId === confirmedListing.id)?.read).toBe(true);

    const confirmedPayment = await submitPayment(sellerPage, confirmedListing, `E2E-CONFIRM-${runId}`);
    const pendingNotifications = await expectJson<{ items: Notification[] }>(
      await sellerContext.request.get('/api/notifications'),
      200,
    );
    expect(pendingNotifications.items.some((item) => item.type === 'payment_pending')).toBe(true);

    await expectJson(await sellerContext.request.get(`/api/listings/${confirmedListing.id}`), 404);
    const activationAttempt = await adminContext.request.patch(`/api/admin/listings/${confirmedListing.id}/status`, {
      data: { status: 'active' },
    });
    await expectJson<{ error: string }>(activationAttempt, 409);

    await reviewPayment(
      adminPage,
      adminContext,
      secondSellerContext,
      moderatorContext,
      confirmedPayment,
      confirmedTitle,
      'confirmed',
    );
    const confirmedAdminListing = await getListing(adminContext, confirmedTitle);
    expect(confirmedAdminListing.status).toBe('pending_payment');
    await expectJson(await sellerContext.request.get(`/api/listings/${confirmedListing.id}`), 404);
    await publishListing(adminPage, adminContext, confirmedListing);
    await expectJson<{ items: Listing[] }>(
      await sellerContext.request.get(`/api/listings/${confirmedListing.id}`),
      200,
    );

    const rejectedListing = await createListing(sellerPage, rejectedTitle);
    const rejectedPayment = await submitPayment(sellerPage, rejectedListing, `E2E-REJECT-${runId}`);
    await reviewPayment(
      adminPage,
      adminContext,
      secondSellerContext,
      moderatorContext,
      rejectedPayment,
      rejectedTitle,
      'rejected',
      rejectionReason,
    );

    const notifications = await expectJson<{ items: Notification[] }>(
      await sellerContext.request.get('/api/notifications'),
      200,
    );
    expect(notifications.items.filter((item) => item.type === 'payment_status').length).toBeGreaterThanOrEqual(2);
    expect(notifications.items.some((item) => item.body === rejectionReason)).toBe(true);
    const rejectedAdminListing = await getListing(adminContext, rejectedTitle);
    expect(rejectedAdminListing.status).toBe('rejected');
    await expectJson(await sellerContext.request.get(`/api/listings/${rejectedListing.id}`), 404);

    const auditLogs = await expectJson<{ items: Array<{ action: string; resourceId: number }> }>(
      await adminContext.request.get('/api/admin/audit-logs'),
      200,
    );
    expect(auditLogs.items).toEqual(
      expect.arrayContaining([
        expect.objectContaining({ action: 'payment.confirmed', resourceId: confirmedPayment.id }),
        expect.objectContaining({ action: 'payment.rejected', resourceId: rejectedPayment.id }),
      ]),
    );

    await sellerPage.goto('/notifications');
    await expect(sellerPage.locator('body')).toContainText(rejectionReason);
  } finally {
    await sellerContext.close();
    await secondSellerContext.close();
    await adminContext.close();
    await moderatorContext.close();
  }
  });

  test('rejects invalid payment proof metadata before issuing an upload URL', async ({ browser }) => {
    const sellerContext = await browser.newContext({ storageState: sellerStorageState });
    try {
      const invalidProofs = [
        { name: 'receipt.gif', size: proofPng.length, contentType: 'image/gif' },
        { name: '   ', size: proofPng.length, contentType: 'image/png' },
        { name: 'receipt.png', size: 1_800_001, contentType: 'image/png' },
      ];

      for (const proof of invalidProofs) {
        const response = await sellerContext.request.post(
          '/api/payment-proof/uploads/request-url',
          { data: proof },
        );
        const body = await expectJson<{ error: string }>(response, 400);
        expect(body).toEqual({ error: 'Invalid payment proof file' });
        expect(body).not.toHaveProperty('uploadURL');
        expect(body).not.toHaveProperty('objectPath');
      }
    } finally {
      await sellerContext.close();
    }
  });

  test('shows the localized validation message for an unsupported payment proof file', async ({ browser }) => {
    const sellerContext = await browser.newContext({ storageState: sellerStorageState });
    const sellerPage = await sellerContext.newPage();
    const runId = `${Date.now()}-${Math.random().toString(36).slice(2, 8)}`;
    let requestUrlCount = 0;
    const recordRequestUrl = (request: Request) => {
      if (
        request.method() === 'POST' &&
        request.url().includes('/api/payment-proof/uploads/request-url')
      ) {
        requestUrlCount += 1;
      }
    };

    try {
      const listing = await createListing(sellerPage, `E2E invalid proof ${runId}`);
      await sellerPage.getByTestId('select-language').selectOption('en');
      await expect(sellerPage.getByTestId('select-language')).toHaveValue('en');
      sellerPage.on('request', recordRequestUrl);

      await sellerPage.getByTestId('input-payment-proof').setInputFiles({
        name: 'receipt.gif',
        mimeType: 'image/gif',
        buffer: proofPng,
      });

      await expect(sellerPage.getByRole('alert')).toHaveText(
        'Choose a PNG, JPG, or WebP image smaller than 1.8 MB.',
      );
      expect(requestUrlCount).toBe(0);
      expect(listing.id).toBeGreaterThan(0);
    } finally {
      sellerPage.off('request', recordRequestUrl);
      await sellerContext.close();
    }
  });

  test('a seller cannot submit another seller payment proof', async ({ browser }) => {
    const sellerContext = await browser.newContext({ storageState: sellerStorageState });
    const secondSellerContext = await browser.newContext({
      storageState: secondSellerStorageState,
    });
    const sellerPage = await sellerContext.newPage();
    const secondSellerPage = await secondSellerContext.newPage();
    const runId = `${Date.now()}-${Math.random().toString(36).slice(2, 8)}`;

    try {
      const sellerListing = await createListing(
        sellerPage,
        `E2E proof owner ${runId}`,
      );
      const secondSellerListing = await createListing(
        secondSellerPage,
        `E2E proof reuser ${runId}`,
      );
      const proofObjectPath = await uploadPaymentProof(sellerContext);

      const rejectedResponse = await submitPaymentWithProof(
        secondSellerContext,
        secondSellerListing,
        proofObjectPath,
        `E2E-PROOF-REJECT-${runId}`,
      );
      const rejectedBody = await expectJson<{ error: string }>(rejectedResponse, 403);
      expect(rejectedBody.error).toBe(
        'Payment proof upload does not belong to this user',
      );

      const acceptedResponse = await submitPaymentWithProof(
        sellerContext,
        sellerListing,
        proofObjectPath,
        `E2E-PROOF-OWNER-${runId}`,
      );
      const acceptedPayment = await expectJson<Payment>(acceptedResponse, 201);
      expect(acceptedPayment.listingId).toBe(sellerListing.id);
      expect(acceptedPayment.status).toBe('pending');
    } finally {
      await sellerContext.close();
      await secondSellerContext.close();
    }
  });

  test('featured listings follow the payment, moderation, removal, and expiry lifecycle', async ({ browser }) => {
    const sellerContext = await browser.newContext({ storageState: sellerStorageState });
    const adminContext = await browser.newContext({ storageState: adminStorageState });
    const sellerPage = await sellerContext.newPage();
    const adminPage = await adminContext.newPage();
    const runId = `${Date.now()}-${Math.random().toString(36).slice(2, 8)}`;
    const listingTitle = `E2E featured listing ${runId}`;
    let closeDatabase: (() => Promise<void>) | undefined;

    try {
      const listing = await createListing(sellerPage, listingTitle);
      const payment = await submitPayment(sellerPage, listing, `E2E-FEATURED-${runId}`);

      await expectJson(await sellerContext.request.get(`/api/listings/${listing.id}`), 404);
      await expectFeaturedListingOnHome(sellerPage, listingTitle, 'ar', false);

      await reviewPayment(
        adminPage,
        adminContext,
        sellerContext,
        null,
        payment,
        listingTitle,
        'confirmed',
      );
      const pendingPaymentListing = await getListing(adminContext, listingTitle);
      expect(pendingPaymentListing.status).toBe('pending_payment');
      expect(pendingPaymentListing.featured).toBe(false);
      await expectJson(await sellerContext.request.get(`/api/listings/${listing.id}`), 404);

      await publishListing(adminPage, adminContext, listing);
      const published = await expectJson<Listing>(
        await sellerContext.request.get(`/api/listings/${listing.id}`),
        200,
      );
      expect(published.featured).toBe(true);
      expect(published.expiresAt).toBeTruthy();

      for (const language of ['ar', 'fr', 'en'] as const) {
        await expectFeaturedListingOnHome(sellerPage, listingTitle, language, true);
      }

      await adminPage.goto('/admin/listings');
      await adminPage.locator('main select').first().selectOption('en');
      await adminPage.locator('main input[type="text"]').fill(listingTitle);
      const listingRow = adminPage.locator('tbody tr').filter({ hasText: listingTitle });
      await expect(listingRow).toBeVisible();

      const unfeatureResponsePromise = adminPage.waitForResponse(
        (response) =>
          response.url().includes(`/api/admin/listings/${listing.id}/featured`) &&
          response.request().method() === 'PATCH',
      );
      await listingRow.getByTestId(`button-featured-listing-${listing.id}`).click();
      await adminPage.getByRole('dialog').getByRole('button').last().click();
      expect((await unfeatureResponsePromise).status()).toBe(200);

      await expect.poll(async () => (await getListing(adminContext, listingTitle)).featured).toBe(false);
      await expectFeaturedListingOnHome(sellerPage, listingTitle, 'en', false);

      const refeatureResponsePromise = adminPage.waitForResponse(
        (response) =>
          response.url().includes(`/api/admin/listings/${listing.id}/featured`) &&
          response.request().method() === 'PATCH',
      );
      await listingRow.getByTestId(`button-featured-listing-${listing.id}`).click();
      await adminPage.getByRole('dialog').getByRole('button').last().click();
      expect((await refeatureResponsePromise).status()).toBe(200);
      await expect.poll(async () => (await getListing(adminContext, listingTitle)).featured).toBe(true);
      await expectFeaturedListingOnHome(sellerPage, listingTitle, 'en', true);

      closeDatabase = await seedListingExpiration(listing.id);
      await expectFeaturedListingOnHome(sellerPage, listingTitle, 'en', false);
      await expect.poll(
        async () => (await getListing(adminContext, listingTitle)).status,
        { timeout: 75_000, intervals: [1_000, 5_000] },
      ).toBe('expired');
      await expectFeaturedListingOnHome(sellerPage, listingTitle, 'en', false);
    } finally {
      if (closeDatabase) await closeDatabase();
      await sellerContext.close();
      await adminContext.close();
    }
  });

  test('listing contact phone survives title and price edits', async ({ browser }) => {
    const sellerContext = await browser.newContext({ storageState: sellerStorageState });
    const adminContext = await browser.newContext({ storageState: adminStorageState });
    const sellerPage = await sellerContext.newPage();
    const adminPage = await adminContext.newPage();
    const runId = `${Date.now()}-${Math.random().toString(36).slice(2, 8)}`;
    const listingTitle = `E2E contact phone listing ${runId}`;
    const editedTitle = `${listingTitle} updated`;
    const contactPhone = '+222 45 67 89 01';
    const changedContactPhone = '+222 22 33 44 55';

    try {
      const listing = await createListing(sellerPage, listingTitle, contactPhone);
      const payment = await submitPayment(sellerPage, listing, `E2E-CONTACT-${runId}`);
      await reviewPayment(
        adminPage,
        adminContext,
        sellerContext,
        null,
        payment,
        listingTitle,
        'confirmed',
      );
      await publishListing(adminPage, adminContext, listing);

      const published = await expectJson<Listing>(
        await sellerContext.request.get(`/api/listings/${listing.id}`),
        200,
      );
      expect(published.contactPhone).toBe(contactPhone);

      await sellerPage.goto(`/listings/${listing.id}`);
      await expect(sellerPage.getByTestId('link-call-seller')).toHaveAttribute(
        'href',
        `tel:${contactPhone}`,
      );
      await expect(sellerPage.getByTestId('link-call-seller')).toContainText(contactPhone);

      await sellerPage.goto('/dashboard');
      await sellerPage.getByTestId(`button-edit-listing-${listing.id}`).click();
      await expect(sellerPage.getByTestId('input-edit-contact-phone')).toHaveValue(contactPhone);
      await sellerPage.getByTestId('input-edit-title').fill(editedTitle);
      const titleRequestPromise = sellerPage.waitForRequest(
        (request) =>
          request.url().includes(`/api/listings/${listing.id}`) &&
          request.method() === 'PATCH',
      );
      const titleResponsePromise = sellerPage.waitForResponse(
        (response) =>
          response.url().includes(`/api/listings/${listing.id}`) &&
          response.request().method() === 'PATCH',
      );
      await sellerPage.getByTestId('button-save-edit').click();
      const titleRequest = await titleRequestPromise;
      expect(titleRequest.postDataJSON()).not.toHaveProperty('contactPhone');
      const titleUpdate = await expectJson<Listing>(await titleResponsePromise, 200);
      expect(titleUpdate.contactPhone).toBe(contactPhone);

      await publishListing(adminPage, adminContext, { ...listing, title: editedTitle });
      await sellerPage.goto(`/listings/${listing.id}`);
      await expect(sellerPage.getByTestId('link-call-seller')).toHaveAttribute(
        'href',
        `tel:${contactPhone}`,
      );
      await expect(sellerPage.getByTestId('link-call-seller')).toContainText(contactPhone);

      await sellerPage.goto('/dashboard');
      await sellerPage.getByTestId(`button-edit-listing-${listing.id}`).click();
      await expect(sellerPage.getByTestId('input-edit-contact-phone')).toHaveValue(contactPhone);
      await sellerPage.getByTestId('input-edit-price').fill('135000');
      const priceRequestPromise = sellerPage.waitForRequest(
        (request) =>
          request.url().includes(`/api/listings/${listing.id}`) &&
          request.method() === 'PATCH',
      );
      const priceResponsePromise = sellerPage.waitForResponse(
        (response) =>
          response.url().includes(`/api/listings/${listing.id}`) &&
          response.request().method() === 'PATCH',
      );
      await sellerPage.getByTestId('button-save-edit').click();
      const priceRequest = await priceRequestPromise;
      expect(priceRequest.postDataJSON()).not.toHaveProperty('contactPhone');
      const priceUpdate = await expectJson<Listing>(await priceResponsePromise, 200);
      expect(priceUpdate.contactPhone).toBe(contactPhone);

      await publishListing(adminPage, adminContext, { ...listing, title: editedTitle });
      await sellerPage.goto(`/listings/${listing.id}`);
      await expect(sellerPage.getByTestId('link-call-seller')).toHaveAttribute(
        'href',
        `tel:${contactPhone}`,
      );
      await expect(sellerPage.getByTestId('link-call-seller')).toContainText(contactPhone);

      await sellerPage.goto('/dashboard');
      await sellerPage.getByTestId(`button-edit-listing-${listing.id}`).click();
      await sellerPage.getByTestId('input-edit-contact-phone').fill(changedContactPhone);
      const phoneRequestPromise = sellerPage.waitForRequest(
        (request) =>
          request.url().includes(`/api/listings/${listing.id}`) &&
          request.method() === 'PATCH',
      );
      const phoneResponsePromise = sellerPage.waitForResponse(
        (response) =>
          response.url().includes(`/api/listings/${listing.id}`) &&
          response.request().method() === 'PATCH',
      );
      await sellerPage.getByTestId('button-save-edit').click();
      const phoneRequest = await phoneRequestPromise;
      expect(phoneRequest.postDataJSON()).toMatchObject({ contactPhone: changedContactPhone });
      const phoneUpdate = await expectJson<Listing>(await phoneResponsePromise, 200);
      expect(phoneUpdate.contactPhone).toBe(changedContactPhone);

      await publishListing(adminPage, adminContext, { ...listing, title: editedTitle });
      await sellerPage.goto(`/listings/${listing.id}`);
      await expect(sellerPage.getByTestId('link-call-seller')).toHaveAttribute(
        'href',
        `tel:${changedContactPhone}`,
      );
      await expect(sellerPage.getByTestId('link-call-seller')).toContainText(changedContactPhone);
    } finally {
      await sellerContext.close();
      await adminContext.close();
    }
  });

  test('admin removal hides a listing by default but retains it under the suspended filter', async ({ browser }) => {
    const sellerContext = await browser.newContext({ storageState: sellerStorageState });
    const adminContext = await browser.newContext({ storageState: adminStorageState });
    const sellerPage = await sellerContext.newPage();
    const adminPage = await adminContext.newPage();
    const runId = `${Date.now()}-${Math.random().toString(36).slice(2, 8)}`;
    const listingTitle = `E2E suspended listing ${runId}`;

    try {
      const listing = await createListing(sellerPage, listingTitle);

      await adminPage.goto('/admin/listings');
      await adminPage.locator('main select').first().selectOption('en');
      await adminPage.locator('main input[type="text"]').fill(listingTitle);

      const listingRow = adminPage.locator('tbody tr').filter({ hasText: listingTitle });
      await expect(listingRow).toBeVisible();

      const deleteResponsePromise = adminPage.waitForResponse(
        (response) =>
          response.url().includes(`/api/admin/listings/${listing.id}`) &&
          response.request().method() === 'DELETE',
      );
      await listingRow.locator('button').last().click();
      await adminPage.getByRole('dialog').getByRole('button').last().click();
      await expect((await deleteResponsePromise).status()).toBe(204);

      await expect(listingRow).toHaveCount(0);

      await adminPage.locator('main select').nth(1).selectOption('suspended');
      await expect(listingRow).toBeVisible();
      await expect(listingRow).toContainText('Suspended');
    } finally {
      await sellerContext.close();
      await adminContext.close();
    }
  });
});
