import { expect, test } from '@playwright/test';

const baseURL =
  process.env.E2E_BASE_URL ??
  (process.env.REPLIT_DEV_DOMAIN
    ? `https://${process.env.REPLIT_DEV_DOMAIN}`
    : undefined);
const clerkSecretKey = process.env.CLERK_SECRET_KEY;
const adminEmail = process.env.E2E_ADMIN_EMAIL ?? 'e2e-admin@example.com';
const missingConfiguration = !baseURL || !clerkSecretKey;

const artifactBasePath = baseURL
  ? new URL(baseURL).pathname.replace(/\/$/, '')
  : '';

function artifactRoute(path: string) {
  return `${artifactBasePath}${path}` || path;
}

type ClerkUser = {
  id: string;
  email_addresses?: Array<{ email_address: string }>;
};

type ClerkUsersResponse = {
  data?: ClerkUser[];
};

async function createAdminSignInTicket() {
  const headers = {
    Authorization: `Bearer ${clerkSecretKey}`,
    'Content-Type': 'application/json',
  };
  const usersResponse = await fetch(
    `https://api.clerk.com/v1/users?email_address=${encodeURIComponent(adminEmail)}&limit=10`,
    { headers },
  );
  expect(usersResponse.ok, `Could not find the E2E admin user (${usersResponse.status}).`).toBeTruthy();
  const usersBody = (await usersResponse.json()) as ClerkUsersResponse | ClerkUser[];
  const users = Array.isArray(usersBody) ? usersBody : usersBody.data ?? [];
  const admin = users.find((user) =>
    user.email_addresses?.some((address) => address.email_address === adminEmail),
  );
  expect(admin, `No Clerk user exists for ${adminEmail}. Run pnpm setup:e2e-auth first.`).toBeTruthy();

  const ticketResponse = await fetch('https://api.clerk.com/v1/sign_in_tokens', {
    method: 'POST',
    headers,
    body: JSON.stringify({ user_id: admin!.id, expires_in_seconds: 600 }),
  });
  expect(ticketResponse.ok, `Could not create a Clerk sign-in ticket (${ticketResponse.status}).`).toBeTruthy();
  const ticket = (await ticketResponse.json()) as { token?: string };
  expect(ticket.token).toBeTruthy();
  return ticket.token!;
}

test.describe('admin login route', () => {
  test.skip(
    missingConfiguration,
    'Set E2E_BASE_URL (or REPLIT_DEV_DOMAIN) and CLERK_SECRET_KEY to run the admin login browser regression.',
  );

  test('shows the admin sign-in screen and returns to the admin portal', async ({ browser }) => {
    const context = await browser.newContext();
    const page = await context.newPage();

    try {
      await page.goto(artifactRoute('/admin/login'), { waitUntil: 'domcontentloaded' });
      await expect(page.getByRole('heading', { name: 'بوابة المشرفين' })).toBeVisible();
      await expect(
        page.getByText('الوصول مقيّد للأعضاء المصرّح لهم فقط.'),
      ).toBeVisible();

      const ticket = await createAdminSignInTicket();
      await page.goto(
        `${artifactRoute('/admin/login')}?__clerk_ticket=${encodeURIComponent(ticket)}`,
        { waitUntil: 'domcontentloaded' },
      );
      await page.waitForURL(
        (url) => url.pathname === `${artifactBasePath}/admin`,
        { timeout: 30_000 },
      );
      await expect(page).toHaveURL(
        new RegExp(`${artifactBasePath.replace('/', '\\/')}/admin\\/?$`),
      );
    } finally {
      await context.close();
    }
  });
});