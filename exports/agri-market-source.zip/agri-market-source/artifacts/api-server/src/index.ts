import app from "./app";
import { logger } from "./lib/logger";
import { cleanupAbandonedPaymentProofs } from "./routes/marketplace";
import { expireListings } from "./lib/listing-expiration";

const rawPort = process.env["PORT"];

if (!rawPort) {
  throw new Error(
    "PORT environment variable is required but was not provided.",
  );
}

const port = Number(rawPort);

if (Number.isNaN(port) || port <= 0) {
  throw new Error(`Invalid PORT value: "${rawPort}"`);
}

const paymentProofCleanupSchedule = setInterval(
  () => cleanupAbandonedPaymentProofs(logger),
  60 * 60 * 1000,
);
paymentProofCleanupSchedule.unref();

void expireListings(logger);
const listingExpirationSchedule = setInterval(
  () => void expireListings(logger),
  60 * 1000,
);
listingExpirationSchedule.unref();

app.listen(port, (err) => {
  if (err) {
    logger.error({ err }, "Error listening on port");
    process.exit(1);
  }

  logger.info({ port }, "Server listening");
});
