export type FeaturedListingVisibilityInput = {
  status: string;
  featured: boolean;
  expiresAt: Date | null;
  hasConfirmedFeaturedPayment: boolean;
};

export function isFeaturedListingVisible(
  listing: FeaturedListingVisibilityInput,
  now = new Date(),
): boolean {
  return (
    listing.status === "active" &&
    listing.featured &&
    listing.hasConfirmedFeaturedPayment &&
    (listing.expiresAt === null || listing.expiresAt > now)
  );
}