import { randomUUID } from "node:crypto";
import { Readable } from "node:stream";
import { File, Storage } from "@google-cloud/storage";
import { setObjectAclPolicy, type ObjectAclPolicy } from "./objectAcl";
import { isPaymentProofUploadObjectName } from "./paymentProof";

const REPLIT_SIDECAR_ENDPOINT = "http://127.0.0.1:1106";
export const objectStorageClient = new Storage({
  credentials: {
    audience: "replit",
    subject_token_type: "access_token",
    token_url: `${REPLIT_SIDECAR_ENDPOINT}/token`,
    type: "external_account",
    credential_source: {
      url: `${REPLIT_SIDECAR_ENDPOINT}/credential`,
      format: {
        type: "json",
        subject_token_field_name: "access_token",
      },
    },
    universe_domain: "googleapis.com",
  },
  projectId: "",
});

export class ObjectNotFoundError extends Error {
  constructor() {
    super("Object not found");
    this.name = "ObjectNotFoundError";
    Object.setPrototypeOf(this, ObjectNotFoundError.prototype);
  }
}

export class ObjectStorageService {
  getPrivateObjectDir(): string {
    const dir = process.env.PRIVATE_OBJECT_DIR || "";
    if (!dir) {
      throw new Error(
        "PRIVATE_OBJECT_DIR not set. Create a bucket in 'Object Storage' tool and set PRIVATE_OBJECT_DIR env var.",
      );
    }
    return dir;
  }

  async getObjectEntityUploadURL(
    prefix = "uploads",
    objectId: string = randomUUID(),
  ): Promise<string> {
    if (
      !/^[a-z0-9-]+$/i.test(prefix) ||
      !/^[a-z0-9._-]+$/i.test(objectId)
    ) {
      throw new Error("Invalid object storage upload prefix");
    }
    const privateObjectDir = this.getPrivateObjectDir();
    const { bucketName, objectName } = parseObjectPath(
      `${privateObjectDir}/${prefix}/${objectId}`,
    );
    return signObjectURL({
      bucketName,
      objectName,
      method: "PUT",
      ttlSec: 900,
    });
  }

  normalizeObjectEntityPath(rawPath: string): string {
    if (!rawPath.startsWith("https://storage.googleapis.com/")) {
      return rawPath;
    }

    const url = new URL(rawPath);
    const rawObjectPath = url.pathname;
    let objectEntityDir = this.getPrivateObjectDir();
    if (!objectEntityDir.endsWith("/")) objectEntityDir += "/";
    if (!rawObjectPath.startsWith(objectEntityDir)) return rawObjectPath;
    return `/objects/${rawObjectPath.slice(objectEntityDir.length)}`;
  }

  async getObjectEntityFile(objectPath: string): Promise<File> {
    if (!objectPath.startsWith("/objects/")) {
      throw new ObjectNotFoundError();
    }

    const entityId = objectPath.slice("/objects/".length);
    if (!entityId) throw new ObjectNotFoundError();

    const privateObjectDir = this.getPrivateObjectDir();
    const { bucketName, objectName } = parseObjectPath(
      `${privateObjectDir}/${entityId}`,
    );
    const objectFile = objectStorageClient.bucket(bucketName).file(objectName);
    const [exists] = await objectFile.exists();
    if (!exists) throw new ObjectNotFoundError();
    return objectFile;
  }

  async cleanupUnreferencedPaymentProofs({
    referencedObjectPaths,
    olderThan,
  }: {
    referencedObjectPaths: ReadonlySet<string>;
    olderThan: Date;
  }): Promise<{
    scanned: number;
    deleted: number;
    failedObjectPaths: string[];
  }> {
    const privateObjectDir = this.getPrivateObjectDir();
    const { bucketName, objectName: uploadsObjectName } = parseObjectPath(
      `${privateObjectDir}/uploads`,
    );
    const uploadsPrefix = `${uploadsObjectName}/`;
    const [files] = await objectStorageClient.bucket(bucketName).getFiles({
      prefix: uploadsPrefix,
    });
    const staleFiles = files.filter((file) => {
      const entityPath = file.name.slice(uploadsPrefix.length);
      const objectPath = `/objects/uploads/${entityPath}`;
      const timeCreated = file.metadata.timeCreated
        ? Date.parse(file.metadata.timeCreated)
        : Number.NaN;

      // Missing creation metadata is handled conservatively: leave the object
      // in place rather than risk deleting a recently uploaded proof.
      return (
        file.name.startsWith(uploadsPrefix) &&
        isPaymentProofUploadObjectName(`uploads/${entityPath}`) &&
        !referencedObjectPaths.has(objectPath) &&
        Number.isFinite(timeCreated) &&
        timeCreated < olderThan.getTime()
      );
    });
    const failedObjectPaths: string[] = [];
    let deleted = 0;

    for (const file of staleFiles) {
      const objectPath = `/objects/uploads/${file.name.slice(uploadsPrefix.length)}`;
      try {
        await file.delete();
        deleted += 1;
      } catch {
        failedObjectPaths.push(objectPath);
      }
    }

    return {
      scanned: staleFiles.length,
      deleted,
      failedObjectPaths,
    };
  }

  async markObjectPrivate(
    objectPath: string,
    owner: string,
  ): Promise<void> {
    const objectFile = await this.getObjectEntityFile(objectPath);
    const policy: ObjectAclPolicy = { owner, visibility: "private" };
    await setObjectAclPolicy(objectFile, policy);
  }

  async downloadObject(file: File): Promise<Response> {
    const [metadata] = await file.getMetadata();
    const nodeStream = file.createReadStream();
    const webStream = Readable.toWeb(nodeStream) as ReadableStream;
    const headers: Record<string, string> = {
      "Content-Type": (metadata.contentType as string) || "application/octet-stream",
      "Cache-Control": "private, no-store",
      "X-Content-Type-Options": "nosniff",
      "Content-Disposition": "inline",
    };
    if (metadata.size) headers["Content-Length"] = String(metadata.size);
    return new Response(webStream, { headers });
  }
}

function parseObjectPath(path: string): {
  bucketName: string;
  objectName: string;
} {
  const normalized = path.startsWith("/") ? path : `/${path}`;
  const parts = normalized.split("/");
  if (parts.length < 3 || !parts[1] || !parts.slice(2).join("/")) {
    throw new Error("Invalid object storage path");
  }
  return { bucketName: parts[1], objectName: parts.slice(2).join("/") };
}

async function signObjectURL({
  bucketName,
  objectName,
  method,
  ttlSec,
}: {
  bucketName: string;
  objectName: string;
  method: "GET" | "PUT";
  ttlSec: number;
}): Promise<string> {
  const response = await fetch(
    `${REPLIT_SIDECAR_ENDPOINT}/object-storage/signed-object-url`,
    {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        bucket_name: bucketName,
        object_name: objectName,
        method,
        expires_at: new Date(Date.now() + ttlSec * 1000).toISOString(),
      }),
      signal: AbortSignal.timeout(30_000),
    },
  );
  if (!response.ok) {
    throw new Error(`Failed to sign object URL, errorcode: ${response.status}`);
  }
  const body = (await response.json()) as { signed_url?: string };
  if (!body.signed_url) throw new Error("Object storage returned no signed URL");
  return body.signed_url;
}