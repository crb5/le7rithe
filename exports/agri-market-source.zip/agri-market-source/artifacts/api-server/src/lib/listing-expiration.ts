import { and, eq, lte } from "drizzle-orm";
import { db, listingsTable } from "@workspace/db";
import type { Logger } from "pino";

export async function expireListings(log: Pick<Logger, "info" | "error">): Promise<number> {
  try {
    const expired = await db
      .update(listingsTable)
      .set({
        status: "expired",
        moderationReason: "انتهت مدة الإعلان تلقائيًا",
      })
      .where(and(
        eq(listingsTable.status, "active"),
        lte(listingsTable.expiresAt, new Date()),
      ))
      .returning({ id: listingsTable.id });

    if (expired.length > 0) {
      log.info({ count: expired.length, listingIds: expired.map(({ id }) => id) }, "Expired marketplace listings");
    }
    return expired.length;
  } catch (error) {
    log.error({ err: error }, "Failed to expire marketplace listings");
    return 0;
  }
}