import { Router, type IRouter, type Request, type Response, type NextFunction } from "express";
import { getAuth } from "@clerk/express";
import { and, asc, count, desc, eq, ilike, inArray, ne, or, sql } from "drizzle-orm";
import {
  auditLogsTable,
  categoriesTable,
  db,
  listingsTable,
  notificationsTable,
  paymentMethodsTable,
  paymentPackagesTable,
  paymentsTable,
  reportsTable,
  usersTable,
} from "@workspace/db";
import { Readable } from "node:stream";
import { ObjectNotFoundError, ObjectStorageService } from "../lib/objectStorage";
import { isFeaturedListingVisible } from "../lib/featured-listing-policy";
import { loadPaymentProofResponse } from "../lib/paymentProof";
import { getLocalPaymentProof } from "./marketplace";

const router: IRouter = Router();
const objectStorageService = new ObjectStorageService();

type AdminActor = typeof usersTable.$inferSelect | null;

function claimRole(req: Request): string | undefined {
  const auth = getAuth(req) as { userId?: string | null; sessionClaims?: Record<string, unknown> | null };
  const configuredAdmins = (process.env.ADMIN_CLERK_USER_IDS ?? "").split(",").map((value) => value.trim()).filter(Boolean);
  if (auth.userId && configuredAdmins.includes(auth.userId)) return "admin";
  const claims = auth.sessionClaims ?? {};
  const metadata = (claims.metadata ?? claims.publicMetadata ?? {}) as Record<string, unknown>;
  const role = metadata.role ?? claims.role;
  return typeof role === "string" ? role : undefined;
}

async function actorForRequest(req: Request): Promise<AdminActor> {
  const { userId } = getAuth(req);
  if (!userId) return null;
  const [existingActor] = await db.select().from(usersTable).where(eq(usersTable.clerkUserId, userId)).limit(1);
  if (existingActor) return existingActor;

  const role = claimRole(req);
  if (role !== "admin" && role !== "moderator") return null;

  return db.transaction(async (tx) => {
    // Serialize bootstrap so two newly configured Clerk admins cannot both
    // become implicit local administrators before either insert is visible.
    await tx.execute(sql`SELECT pg_advisory_xact_lock(hashtext('marketplace_admin_bootstrap'))`);

    const [actor] = await tx.select().from(usersTable).where(eq(usersTable.clerkUserId, userId)).limit(1);
    if (actor) return actor;

    if (role === "admin") {
      const [existingAdministrator] = await tx
        .select({ id: usersTable.id })
        .from(usersTable)
        .where(or(eq(usersTable.role, "admin"), eq(usersTable.role, "moderator")))
        .limit(1);
      if (existingAdministrator) return null;
    }

    const claims = (getAuth(req).sessionClaims ?? {}) as Record<string, unknown>;
    const displayName = typeof claims.name === "string"
      ? claims.name
      : typeof claims.first_name === "string"
        ? String(claims.first_name)
        : "مشرف الإدارة";
    const initials = displayName.trim().split(/\s+/).slice(0, 2).map((part) => part[0] || "").join("") || "م";
    const email = typeof claims.email === "string" ? claims.email : null;
    const [created] = await tx.insert(usersTable).values({
      clerkUserId: userId,
      name: displayName,
      email,
      initials,
      role,
      status: "active",
    }).onConflictDoNothing({ target: usersTable.clerkUserId }).returning();
    if (created) return created;

    const [existingAfterConflict] = await tx
      .select()
      .from(usersTable)
      .where(eq(usersTable.clerkUserId, userId))
      .limit(1);
    return existingAfterConflict ?? null;
  });
}

async function requireAdmin(req: Request, res: Response, next: NextFunction): Promise<void> {
  const { userId } = getAuth(req);
  const actor = await actorForRequest(req);
  if (!userId) {
    res.status(401).json({ error: "Authentication required" });
    return;
  }
  if (!actor || (actor.role !== "admin" && actor.role !== "moderator")) {
    res.status(403).json({ error: "Admin access required" });
    return;
  }
  res.locals.adminActor = actor;
  res.locals.adminRole = actor.role;
  next();
}

async function audit(req: Request, action: string, resourceType: string, resourceId: number | null, details: Record<string, unknown> = {}) {
  const actor = resActor(req);
  const { userId } = getAuth(req);
  await db.insert(auditLogsTable).values({
    actorId: actor?.id ?? null,
    actorClerkUserId: userId ?? null,
    action,
    resourceType,
    resourceId,
    details,
  });
}

function resActor(req: Request): AdminActor {
  return (req.res?.locals.adminActor as AdminActor | undefined) ?? null;
}

function numeric(value: unknown): number {
  const parsed = Number(value);
  return Number.isFinite(parsed) ? parsed : 0;
}

router.get("/admin/me", async (req, res): Promise<void> => {
  const { userId } = getAuth(req);
  const actor = await actorForRequest(req);
  const role = actor?.role ?? claimRole(req) ?? "user";
  res.json({ authenticated: Boolean(userId), role, user: actor });
});

router.use("/admin", requireAdmin);

router.get("/admin/notifications", async (req, res): Promise<void> => {
    const actor = resActor(req);
  if (!actor) {
    res.json({ items: [], unreadCount: 0 });
    return;
  }

  const notificationWhere = and(
    eq(notificationsTable.userId, actor.id),
    eq(notificationsTable.type, "admin_new_listing"),
  );
  const [rows, unreadRows] = await Promise.all([
    db.select({
      notification: notificationsTable,
      listing: listingsTable,
      seller: usersTable,
    })
      .from(notificationsTable)
      .leftJoin(listingsTable, eq(notificationsTable.listingId, listingsTable.id))
      .leftJoin(usersTable, eq(listingsTable.sellerId, usersTable.id))
      .where(notificationWhere)
      .orderBy(desc(notificationsTable.createdAt))
      .limit(50),
    db.select({ value: count() })
      .from(notificationsTable)
      .where(and(notificationWhere, eq(notificationsTable.read, false))),
  ]);

  const listingIds = rows
    .map(({ notification }) => notification.listingId)
    .filter((id): id is number => typeof id === "number");
  const payments = listingIds.length
    ? await db.select({
      listingId: paymentsTable.listingId,
      status: paymentsTable.status,
      createdAt: paymentsTable.createdAt,
    })
      .from(paymentsTable)
      .where(inArray(paymentsTable.listingId, listingIds))
      .orderBy(desc(paymentsTable.createdAt))
    : [];
  const latestPaymentByListing = new Map<number, string>();
  for (const payment of payments) {
    if (payment.listingId !== null && !latestPaymentByListing.has(payment.listingId)) {
      latestPaymentByListing.set(payment.listingId, payment.status);
    }
  }

  res.json({
    items: rows.map(({ notification, listing, seller }) => ({
      ...notification,
      listingTitle: listing?.title ?? null,
      sellerName: seller?.name ?? null,
      listingCreatedAt: listing?.createdAt ?? notification.createdAt,
      listingStatus: listing?.status ?? null,
      paymentStatus: listing?.id ? latestPaymentByListing.get(listing.id) ?? "pending" : "pending",
    })),
    unreadCount: numeric(unreadRows[0]?.value),
  });
});

router.patch("/admin/notifications/:id/read", async (req, res): Promise<void> => {
    const actor = resActor(req);
  const id = numeric(req.params.id);
  if (!actor || !id) {
    res.status(400).json({ error: "Invalid notification id" });
    return;
  }
  const [notification] = await db.update(notificationsTable)
    .set({ read: true })
    .where(and(eq(notificationsTable.id, id), eq(notificationsTable.userId, actor.id), eq(notificationsTable.type, "admin_new_listing")))
    .returning();
  if (!notification) {
    res.status(404).json({ error: "Notification not found" });
    return;
  }
  res.json(notification);
});

router.patch("/admin/notifications/listing/:listingId/read", async (req, res): Promise<void> => {
    const actor = resActor(req);
  const listingId = numeric(req.params.listingId);
  if (!actor || !listingId) {
    res.status(400).json({ error: "Invalid listing id" });
    return;
  }
  await db.update(notificationsTable)
    .set({ read: true })
    .where(and(
      eq(notificationsTable.userId, actor.id),
      eq(notificationsTable.listingId, listingId),
      eq(notificationsTable.type, "admin_new_listing"),
    ));
  res.status(204).send();
});

router.get("/admin/overview", async (_req, res): Promise<void> => {
  const [[users], [listings], [pendingReview], [activeListings], [expired], [payments], [pendingPayments], [revenue], [reports], recentListings] = await Promise.all([
    db.select({ value: count() }).from(usersTable),
    db.select({ value: count() }).from(listingsTable),
    db.select({ value: count() }).from(listingsTable).where(eq(listingsTable.status, "pending_payment")),
    db.select({ value: count() }).from(listingsTable).where(eq(listingsTable.status, "active")),
    db.select({ value: count() }).from(listingsTable).where(eq(listingsTable.status, "expired")),
    db.select({ value: count() }).from(paymentsTable),
    db.select({ value: count() }).from(paymentsTable).where(eq(paymentsTable.status, "pending")),
    db.select({ value: sql<string>`coalesce(sum(case when ${paymentsTable.status} = 'confirmed' then ${paymentsTable.amount} else 0 end), 0)` }).from(paymentsTable),
    db.select({ value: count() }).from(reportsTable).where(eq(reportsTable.status, "open")),
    db.select({ listing: listingsTable, category: categoriesTable, seller: usersTable }).from(listingsTable).innerJoin(categoriesTable, eq(listingsTable.categoryId, categoriesTable.id)).innerJoin(usersTable, eq(listingsTable.sellerId, usersTable.id)).orderBy(desc(listingsTable.createdAt)).limit(8),
  ]);
  res.json({
    stats: {
      users: numeric(users.value),
      listings: numeric(listings.value),
      pendingReview: numeric(pendingReview.value),
      activeListings: numeric(activeListings.value),
      expiredListings: numeric(expired.value),
      payments: numeric(payments.value),
      pendingPayments: numeric(pendingPayments.value),
      revenue: numeric(revenue.value),
      openReports: numeric(reports.value),
    },
    recentListings: recentListings.map(({ listing, category, seller }) => ({
      ...listing,
      category: category.name,
      categorySlug: category.slug,
      seller: { id: seller.id, name: seller.name, phone: seller.phone },
    })),
  });
});

router.get("/admin/listings", async (req, res): Promise<void> => {
  const q = typeof req.query.q === "string" ? req.query.q.trim() : "";
  const status = typeof req.query.status === "string" && req.query.status ? req.query.status : undefined;
  const category = typeof req.query.category === "string" && req.query.category ? req.query.category : undefined;
  const page = Math.max(numeric(req.query.page), 1);
  const limit = Math.min(Math.max(numeric(req.query.limit) || 20, 1), 100);
  const filters = [
    q ? or(ilike(listingsTable.title, `%${q}%`), ilike(usersTable.name, `%${q}%`)) : undefined,
    status ? eq(listingsTable.status, status) : ne(listingsTable.status, "suspended"),
    category ? eq(categoriesTable.slug, category) : undefined,
  ].filter(Boolean);
  const where = filters.length ? and(...filters as [ReturnType<typeof eq>, ...ReturnType<typeof eq>[]]) : undefined;
  const [items, totals] = await Promise.all([
    db.select({ listing: listingsTable, category: categoriesTable, seller: usersTable }).from(listingsTable).innerJoin(categoriesTable, eq(listingsTable.categoryId, categoriesTable.id)).innerJoin(usersTable, eq(listingsTable.sellerId, usersTable.id)).where(where).orderBy(desc(listingsTable.createdAt)).limit(limit).offset((page - 1) * limit),
    db.select({ total: count() }).from(listingsTable).innerJoin(categoriesTable, eq(listingsTable.categoryId, categoriesTable.id)).innerJoin(usersTable, eq(listingsTable.sellerId, usersTable.id)).where(where),
  ]);
  res.json({ items: items.map(({ listing, category: categoryRow, seller }) => ({ ...listing, category: categoryRow.name, categorySlug: categoryRow.slug, seller: { id: seller.id, name: seller.name, phone: seller.phone } })), total: numeric(totals[0]?.total), page, limit });
});

router.patch("/admin/listings/:id/status", async (req, res): Promise<void> => {
  const id = numeric(req.params.id);
  const status = typeof req.body?.status === "string" ? req.body.status : "";
  const allowed = ["draft", "pending_payment", "pending_review", "active", "rejected", "expired", "suspended"];
  if (!id || !allowed.includes(status)) {
    res.status(400).json({ error: "Invalid listing status" });
    return;
  }

  let listing: typeof listingsTable.$inferSelect | undefined;
  try {
    listing = await db.transaction(async (tx) => {
       const [existingListing] = await tx
         .select({ id: listingsTable.id, status: listingsTable.status })
        .from(listingsTable)
        .where(eq(listingsTable.id, id))
        .limit(1);
      if (!existingListing) return undefined;

      if (status === "active") {
        const [confirmedPayment] = await tx
          .select({ id: paymentsTable.id, package: paymentPackagesTable })
          .from(paymentsTable)
          .innerJoin(paymentPackagesTable, eq(paymentsTable.packageId, paymentPackagesTable.id))
          .where(and(eq(paymentsTable.listingId, id), eq(paymentsTable.status, "confirmed")))
          .orderBy(desc(paymentsTable.createdAt))
          .limit(1);
        if (!confirmedPayment) throw new Error("LISTING_PAYMENT_NOT_CONFIRMED");
         const [currentListing] = await tx
          .select({ expiresAt: listingsTable.expiresAt })
          .from(listingsTable)
          .where(eq(listingsTable.id, id))
          .limit(1);
        if (currentListing?.expiresAt && currentListing.expiresAt <= new Date()) {
          throw new Error("LISTING_EXPIRATION_PAST");
        }
        const [updatedListing] = await tx
          .update(listingsTable)
          .set({
            status,
            moderationReason: req.body.reason || null,
            moderatedAt: new Date(),
            moderatedBy: resActor(req)?.id ?? null,
            featured: confirmedPayment.package.featured,
            pinned: confirmedPayment.package.pinned,
             expiresAt: existingListing.status === "active"
               ? currentListing?.expiresAt ?? new Date(Date.now() + confirmedPayment.package.durationDays * 86400000)
               : new Date(Date.now() + confirmedPayment.package.durationDays * 86400000),
          })
          .where(eq(listingsTable.id, id))
          .returning();
        return updatedListing;
      }

      const [updatedListing] = await tx
        .update(listingsTable)
        .set({
          status,
          moderationReason: req.body.reason || null,
          moderatedAt: new Date(),
          moderatedBy: resActor(req)?.id ?? null,
        })
        .where(eq(listingsTable.id, id))
        .returning();
      return updatedListing;
    });
  } catch (error) {
    if (error instanceof Error && error.message === "LISTING_PAYMENT_NOT_CONFIRMED") {
      res.status(409).json({ error: "Listing cannot be activated before payment is confirmed" });
      return;
    }
    if (error instanceof Error && error.message === "LISTING_EXPIRATION_PAST") {
      res.status(409).json({ error: "Listing expiration has passed" });
      return;
    }
    throw error;
  }

  if (!listing) {
    res.status(404).json({ error: "Listing not found" });
    return;
  }
  await audit(req, `listing.${status}`, "listing", id, { reason: req.body.reason || null });
  await db.insert(notificationsTable).values({
    userId: listing.sellerId,
    title: status === "active" ? "تم قبول إعلانك" : status === "rejected" ? "تم رفض إعلانك" : status === "suspended" ? "تم إيقاف إعلانك" : "تم تحديث حالة إعلانك",
    body: req.body.reason ? `${listing.title}: ${req.body.reason}` : `تم تحديث حالة «${listing.title}» إلى ${status}.`,
    type: "listing_status",
  });
  res.json(listing);
});

router.patch("/admin/listings/:id/featured", async (req, res): Promise<void> => {
  const id = numeric(req.params.id);
  const requestedFeatured = Boolean(req.body?.featured);
  const requestedPinned = requestedFeatured && Boolean(req.body?.pinned);

  if (requestedFeatured) {
    const [eligibleListing] = await db
      .select({
        id: listingsTable.id,
        status: listingsTable.status,
        expiresAt: listingsTable.expiresAt,
        packageFeatured: paymentPackagesTable.featured,
      })
      .from(listingsTable)
      .innerJoin(paymentsTable, eq(paymentsTable.listingId, listingsTable.id))
      .innerJoin(paymentPackagesTable, eq(paymentsTable.packageId, paymentPackagesTable.id))
      .where(and(
        eq(listingsTable.id, id),
        eq(listingsTable.status, "active"),
        eq(paymentsTable.status, "confirmed"),
        eq(paymentPackagesTable.featured, true),
      ))
      .limit(1);
    if (!eligibleListing || !isFeaturedListingVisible({
      status: eligibleListing.status,
      featured: true,
      expiresAt: eligibleListing.expiresAt,
      hasConfirmedFeaturedPayment: eligibleListing.packageFeatured,
    })) {
      res.status(409).json({ error: "Only an active listing with a confirmed featured package can be featured" });
      return;
    }
  }

  const [listing] = await db.update(listingsTable).set({ featured: requestedFeatured, pinned: requestedPinned }).where(eq(listingsTable.id, id)).returning();
  if (!listing) {
    res.status(404).json({ error: "Listing not found" });
    return;
  }
  await audit(req, "listing.promote", "listing", id, { featured: listing.featured, pinned: listing.pinned });
  res.json(listing);
});

router.delete("/admin/listings/:id", async (req, res): Promise<void> => {
  const id = numeric(req.params.id);
  const [listing] = await db.update(listingsTable).set({ status: "suspended", moderationReason: "تمت الإزالة بواسطة الإدارة", moderatedBy: resActor(req)?.id ?? null, moderatedAt: new Date() }).where(eq(listingsTable.id, id)).returning();
  if (!listing) {
    res.status(404).json({ error: "Listing not found" });
    return;
  }
  await audit(req, "listing.delete", "listing", id, { title: listing.title });
  res.sendStatus(204);
});

router.get("/admin/users", async (req, res): Promise<void> => {
  const q = typeof req.query.q === "string" ? req.query.q.trim() : "";
  const status = typeof req.query.status === "string" && req.query.status ? req.query.status : undefined;
  const filters = [q ? or(ilike(usersTable.name, `%${q}%`), ilike(usersTable.phone, `%${q}%`)) : undefined, status ? eq(usersTable.status, status) : undefined].filter(Boolean);
  const where = filters.length ? and(...filters as [ReturnType<typeof eq>, ...ReturnType<typeof eq>[]]) : undefined;
  const users = await db.select({ user: usersTable, listings: count(listingsTable.id) }).from(usersTable).leftJoin(listingsTable, eq(usersTable.id, listingsTable.sellerId)).where(where).groupBy(usersTable.id).orderBy(desc(usersTable.createdAt));
  res.json({ items: users.map(({ user, listings }) => ({ ...user, listingCount: numeric(listings) })) });
});

router.patch("/admin/users/:id/status", async (req, res): Promise<void> => {
  const id = numeric(req.params.id);
  const status = req.body?.status === "resolved" ? "resolved" : "open";
  const [user] = await db.update(usersTable).set({ status }).where(eq(usersTable.id, id)).returning();
  if (!user) {
    res.status(404).json({ error: "User not found" });
    return;
  }
  await audit(req, `user.${status}`, "user", id);
  res.json(user);
});

router.get("/admin/payments", async (req, res): Promise<void> => {
  const requestedStatus = typeof req.query.status === "string" ? req.query.status : "";
  const status = ["pending", "confirmed", "rejected"].includes(requestedStatus)
    ? requestedStatus
    : undefined;
  const payments = await db.select({ payment: paymentsTable, user: usersTable, listing: listingsTable, package: paymentPackagesTable, method: paymentMethodsTable }).from(paymentsTable).innerJoin(usersTable, eq(paymentsTable.userId, usersTable.id)).leftJoin(listingsTable, eq(paymentsTable.listingId, listingsTable.id)).leftJoin(paymentPackagesTable, eq(paymentsTable.packageId, paymentPackagesTable.id)).leftJoin(paymentMethodsTable, eq(paymentsTable.paymentMethodId, paymentMethodsTable.id)).where(status ? eq(paymentsTable.status, status) : undefined).orderBy(desc(paymentsTable.createdAt));
  res.json({ items: payments.map(({ payment, user, listing, package: pkg, method }) => ({
    ...payment,
    user: { id: user.id, name: user.name, email: user.email, phone: user.phone },
     listing: listing ? { id: listing.id, title: listing.title, status: listing.status, createdAt: listing.createdAt } : null,
    package: pkg,
    method,
     proofImageUrl: payment.proofImageUrl?.startsWith("/objects/")
       ? `/api/admin/payments/${payment.id}/proof`
       : null,
  })) });
});

router.get("/admin/payments/:id/proof", async (req, res): Promise<void> => {
  const id = numeric(req.params.id);
  const [payment] = await db.select({ proofImageUrl: paymentsTable.proofImageUrl }).from(paymentsTable).where(eq(paymentsTable.id, id));
  if (!payment?.proofImageUrl?.startsWith("/objects/")) {
    res.status(404).json({ error: "Payment proof not found" });
    return;
  }

  const localProof = getLocalPaymentProof(payment.proofImageUrl);
  if (localProof) {
    await audit(req, "payment.proof_viewed", "payment", id);
    res.setHeader("Content-Type", localProof.contentType);
    res.setHeader("Content-Length", String(localProof.data.length));
    res.setHeader("Cache-Control", "private, no-store");
    res.send(localProof.data);
    return;
  }

  let response: globalThis.Response;
  try {
    response = await loadPaymentProofResponse({
      objectPath: payment.proofImageUrl,
      localProof,
      storage: objectStorageService,
    });
  } catch (error) {
    if (error instanceof ObjectNotFoundError) {
      res.status(404).json({ error: "Payment proof not found" });
      return;
    }
    req.log.error({ err: error }, "Failed to serve payment proof");
    res.status(503).json({ error: "Payment proof storage is unavailable" });
    return;
  }

  if (response.ok) {
    await audit(req, "payment.proof_viewed", "payment", id);
  }
  res.status(response.status);
  response.headers.forEach((value, key) => res.setHeader(key, value));
  if (response.body) {
    Readable.fromWeb(response.body as ReadableStream<Uint8Array>).pipe(res);
  } else {
    res.end();
  }
});

router.patch("/admin/payments/:id/status", async (req, res): Promise<void> => {
  const id = numeric(req.params.id);
  const status = typeof req.body?.status === "string" ? req.body.status : "";
  if (!id || !["confirmed", "rejected"].includes(status)) {
    res.status(400).json({ error: "Invalid payment status" });
    return;
  }
  const [existing] = await db.select().from(paymentsTable).where(eq(paymentsTable.id, id));
  if (!existing) {
    res.status(404).json({ error: "Payment not found" });
    return;
  }
  if (existing.status !== "pending") {
    res.status(409).json({ error: "Payment has already been reviewed" });
    return;
  }

  try {
    const actor = resActor(req);
    const payment = await db.transaction(async (tx) => {
      const [updated] = await tx.update(paymentsTable).set({
        status,
        rejectionReason: status === "rejected" ? String(req.body.reason || "") : null,
        reviewedBy: actor?.id ?? null,
        reviewedAt: new Date(),
      }).where(and(eq(paymentsTable.id, id), eq(paymentsTable.status, "pending"))).returning();
      if (!updated) throw new Error("PAYMENT_ALREADY_REVIEWED");

       if (status === "confirmed") {
        if (!updated.listingId || !updated.packageId) throw new Error("PAYMENT_MISSING_ENTITLEMENT");
        const [paymentPackage] = await tx.select().from(paymentPackagesTable).where(eq(paymentPackagesTable.id, updated.packageId));
        if (!paymentPackage) throw new Error("PAYMENT_PACKAGE_NOT_FOUND");
       } else if (updated.listingId) {
         const [listing] = await tx
           .select({ status: listingsTable.status })
           .from(listingsTable)
           .where(eq(listingsTable.id, updated.listingId))
           .limit(1);
         if (listing && listing.status !== "active") {
           await tx
             .update(listingsTable)
             .set({
               status: "rejected",
               moderationReason: String(req.body.reason || "تم رفض إثبات الدفع"),
               moderatedBy: actor?.id ?? null,
               moderatedAt: new Date(),
             })
             .where(eq(listingsTable.id, updated.listingId));
         }
      }

      await tx.insert(notificationsTable).values({
        userId: updated.userId,
        title: status === "confirmed" ? "تم تأكيد الدفع" : "تم رفض الدفع",
        body: status === "rejected" && req.body.reason ? String(req.body.reason) : `تم تحديث طلب الدفع رقم ${updated.id}.`,
        type: "payment_status",
      });
      await tx.insert(auditLogsTable).values({
        actorId: actor?.id ?? null,
        actorClerkUserId: actor?.clerkUserId ?? null,
        action: `payment.${status}`,
        resourceType: "payment",
        resourceId: id,
        details: { reason: req.body.reason || null },
      });
      return updated;
    });
    res.json(payment);
  } catch (error) {
    if (error instanceof Error && error.message === "PAYMENT_ALREADY_REVIEWED") {
      res.status(409).json({ error: "Payment has already been reviewed" });
      return;
    }
    if (error instanceof Error && ["PAYMENT_MISSING_ENTITLEMENT", "PAYMENT_PACKAGE_NOT_FOUND"].includes(error.message)) {
      res.status(422).json({ error: "Payment is missing a valid listing or package" });
      return;
    }
    throw error;
  }
});

router.get("/admin/packages", async (_req, res): Promise<void> => {
  res.json({ items: await db.select().from(paymentPackagesTable).orderBy(asc(paymentPackagesTable.createdAt)) });
});

router.post("/admin/packages", async (req, res): Promise<void> => {
  const [pkg] = await db.insert(paymentPackagesTable).values({ ...req.body, price: String(req.body.price) }).returning();
  await audit(req, "package.create", "package", pkg.id);
  res.status(201).json(pkg);
});

router.patch("/admin/packages/:id", async (req, res): Promise<void> => {
  const [pkg] = await db.update(paymentPackagesTable).set({ ...req.body, price: req.body.price == null ? undefined : String(req.body.price) }).where(eq(paymentPackagesTable.id, numeric(req.params.id))).returning();
  if (!pkg) {
    res.status(404).json({ error: "Package not found" });
    return;
  }
  await audit(req, "package.update", "package", pkg.id);
  res.json(pkg);
});

router.delete("/admin/packages/:id", async (req, res): Promise<void> => {
  const [pkg] = await db.update(paymentPackagesTable).set({ active: false }).where(eq(paymentPackagesTable.id, numeric(req.params.id))).returning();
  if (!pkg) {
    res.status(404).json({ error: "Package not found" });
    return;
  }
  await audit(req, "package.delete", "package", pkg.id);
  res.sendStatus(204);
});

router.get("/admin/payment-methods", async (_req, res): Promise<void> => {
  res.json({ items: await db.select().from(paymentMethodsTable).orderBy(asc(paymentMethodsTable.createdAt)) });
});

router.post("/admin/payment-methods", async (req, res): Promise<void> => {
  const [method] = await db.insert(paymentMethodsTable).values(req.body).returning();
  await audit(req, "payment_method.create", "payment_method", method.id);
  res.status(201).json(method);
});

router.patch("/admin/payment-methods/:id", async (req, res): Promise<void> => {
  const [method] = await db.update(paymentMethodsTable).set(req.body).where(eq(paymentMethodsTable.id, numeric(req.params.id))).returning();
  if (!method) {
    res.status(404).json({ error: "Payment method not found" });
    return;
  }
  await audit(req, "payment_method.update", "payment_method", method.id);
  res.json(method);
});

router.delete("/admin/payment-methods/:id", async (req, res): Promise<void> => {
  const [method] = await db.update(paymentMethodsTable).set({ active: false }).where(eq(paymentMethodsTable.id, numeric(req.params.id))).returning();
  if (!method) {
    res.status(404).json({ error: "Payment method not found" });
    return;
  }
  await audit(req, "payment_method.delete", "payment_method", method.id);
  res.sendStatus(204);
});

router.get("/admin/reports", async (_req, res): Promise<void> => {
  const reports = await db.select({ report: reportsTable, reporter: usersTable, listing: listingsTable }).from(reportsTable).innerJoin(usersTable, eq(reportsTable.reporterId, usersTable.id)).leftJoin(listingsTable, eq(reportsTable.listingId, listingsTable.id)).orderBy(desc(reportsTable.createdAt));
  res.json({ items: reports.map(({ report, reporter, listing }) => ({ ...report, reporter: { id: reporter.id, name: reporter.name }, listing: listing ? { id: listing.id, title: listing.title } : null })) });
});

router.patch("/admin/reports/:id", async (req, res): Promise<void> => {
  const status = req.body?.status === "resolved" ? "resolved" : "open";
  const [report] = await db.update(reportsTable).set({ status, action: req.body.action || null, resolvedBy: status === "resolved" ? resActor(req)?.id ?? null : null, resolvedAt: status === "resolved" ? new Date() : null }).where(eq(reportsTable.id, numeric(req.params.id))).returning();
  if (!report) {
    res.status(404).json({ error: "Report not found" });
    return;
  }
  await audit(req, `report.${status}`, "report", report.id, { action: report.action });
  res.json(report);
});

router.get("/admin/audit-logs", async (_req, res): Promise<void> => {
  res.json({ items: await db.select().from(auditLogsTable).orderBy(desc(auditLogsTable.createdAt)).limit(200) });
});

export default router;
