import express, { Router, type IRouter, type Request, type Response } from "express";
import { randomUUID } from "node:crypto";
import { mkdir, readFile, rename, writeFile } from "node:fs/promises";
import path from "node:path";
import { Readable } from "node:stream";
import { getAuth } from "@clerk/express";
import { and, asc, count, desc, eq, gt, gte, ilike, isNotNull, isNull, lte, ne, or, sql, type SQL } from "drizzle-orm";
import type { Logger } from "pino";
import {
  db,
  categoriesTable,
  listingsTable,
  messagesTable,
  notificationsTable,
  paymentMethodsTable,
  paymentPackagesTable,
  paymentsTable,
  savedListingsTable,
  subcategoriesTable,
  usersTable,
  auditLogsTable,
} from "@workspace/db";
import {
  CreateCategoryBody,
  CreateCategoryResponse,
  CreateListingBody,
  CreateListingResponse,
  CreateSubcategoryBody,
  CreateSubcategoryParams,
  CreateSubcategoryResponse,
  DeleteCategoryParams,
  DeleteSubcategoryParams,
  DeleteListingParams,
  GetDashboardSummaryResponse,
  GetListingParams,
  GetListingResponse,
  ListAdminCategoriesResponse,
  ListCategoriesResponse,
  ListListingsQueryParams,
  ListListingsResponse,
  ListLocationsResponse,
  ListMessagesResponse,
  ListSavedListingsResponse,
  ListSubcategoriesParams,
  ListSubcategoriesResponse,
  SendMessageBody,
  SendMessageResponse,
  ToggleFavoriteParams,
  ToggleFavoriteResponse,
  UpdateCategoryBody,
  UpdateCategoryParams,
  UpdateCategoryResponse,
  UpdateListingBody,
  UpdateListingParams,
  UpdateListingResponse,
  UpdateSubcategoryBody,
  UpdateSubcategoryParams,
  UpdateSubcategoryResponse,
} from "@workspace/api-zod";
import { ObjectNotFoundError, ObjectStorageService } from "../lib/objectStorage";
import {
  createPaymentProofUploadId,
  isPaymentProofObjectPath,
  isPaymentProofOwnedByUser,
  maxPaymentProofBytes,
  paymentProofContentTypes,
  validatePaymentProofMetadata,
} from "../lib/paymentProof";

const router: IRouter = Router();
const objectStorageService = new ObjectStorageService();
const localPaymentProofs = new Map<
  string,
  { data: Buffer; contentType: string; userId: string; createdAt: number }
>();
const localListingImages = new Map<
  string,
  { data: Buffer; contentType: string; userId: string; createdAt: number }
>();
const localListingImageStorageDir = path.resolve(process.cwd(), ".data", "listing-images");

const authenticatedMarketplaceUser = async (req: Request, res: Response) => {
  const auth = getAuth(req);
  if (!auth.userId) {
    res.status(401).json({ error: "Authentication required" });
    return null;
  }
  const [existing] = await db.select().from(usersTable).where(eq(usersTable.clerkUserId, auth.userId));
  if (existing) {
    if (existing.status !== "active") {
      res.status(403).json({ error: "Account is suspended" });
      return null;
    }
    return existing;
  }
  const claims = (auth.sessionClaims || {}) as Record<string, unknown>;
  const displayName = typeof claims.name === "string"
    ? claims.name
    : typeof claims.first_name === "string"
      ? String(claims.first_name)
      : "مستخدم";
  const initials = displayName.trim().split(/\s+/).slice(0, 2).map((part) => part[0] || "").join("") || "م";
  const email = typeof claims.email === "string" ? claims.email : null;
  const [created] = await db.insert(usersTable).values({ clerkUserId: auth.userId, name: displayName, email, initials, role: "user", status: "active" }).returning();
  return created;
};

const marketplaceUserForRequest = async (req: Request) => {
  const { userId } = getAuth(req);
  if (!userId) return null;
  const [user] = await db.select().from(usersTable).where(eq(usersTable.clerkUserId, userId));
  return user ?? null;
};

const parsePaymentId = (value: unknown) => {
  const parsed = Number(value);
  return Number.isInteger(parsed) && parsed > 0 ? parsed : null;
};

const listingImageMaxBytes = 8_000_000;
const listingImageContentTypes = new Set(["image/png", "image/jpeg", "image/webp"]);
const listingImageObjectPath = /^\/objects\/listing-images\/[0-9a-f-]{36}$/i;
// Uploaded proofs are retained for one day after upload before an unreferenced
// object becomes eligible for cleanup, allowing a user to finish the form.
const paymentProofCleanupGracePeriodMs = 24 * 60 * 60 * 1000;
const paymentProofCleanupMinIntervalMs = 60 * 60 * 1000;
const localPaymentProofStorageEnabled =
  process.env.NODE_ENV === "development" && !process.env.PRIVATE_OBJECT_DIR;
const localListingImageStorageEnabled =
  process.env.NODE_ENV === "development" && !process.env.PRIVATE_OBJECT_DIR;

type LocalListingImage = {
  data: Buffer;
  contentType: string;
  userId: string;
  createdAt: number;
};

const localListingImageFilePath = (id: string) =>
  path.join(localListingImageStorageDir, `${id}.bin`);

const localListingImageMetadataPath = (id: string) =>
  path.join(localListingImageStorageDir, `${id}.json`);

const readLocalListingImage = async (id: string): Promise<LocalListingImage | null> => {
  const cached = localListingImages.get(id);
  if (cached) return cached;

  try {
    const [data, metadata] = await Promise.all([
      readFile(localListingImageFilePath(id)),
      readFile(localListingImageMetadataPath(id), "utf8"),
    ]);
    const parsed = JSON.parse(metadata) as Partial<Pick<LocalListingImage, "contentType" | "userId" | "createdAt">>;
    if (
      typeof parsed.contentType !== "string" ||
      typeof parsed.userId !== "string" ||
      typeof parsed.createdAt !== "number"
    ) {
      return null;
    }
    const image = { data, contentType: parsed.contentType, userId: parsed.userId, createdAt: parsed.createdAt };
    localListingImages.set(id, image);
    return image;
  } catch {
    return null;
  }
};

const persistLocalListingImage = async (id: string, image: LocalListingImage) => {
  await mkdir(localListingImageStorageDir, { recursive: true });
  const dataPath = localListingImageFilePath(id);
  const metadataPath = localListingImageMetadataPath(id);
  const tempSuffix = `.tmp-${process.pid}-${Date.now()}`;
  await writeFile(`${dataPath}${tempSuffix}`, image.data);
  await writeFile(`${metadataPath}${tempSuffix}`, JSON.stringify({
    contentType: image.contentType,
    userId: image.userId,
    createdAt: image.createdAt,
  }));
  await rename(`${dataPath}${tempSuffix}`, dataPath);
  await rename(`${metadataPath}${tempSuffix}`, metadataPath);
};

export const getLocalPaymentProof = (objectPath: string) => {
  if (!localPaymentProofStorageEnabled || !objectPath.startsWith("/objects/uploads/")) {
    return null;
  }
  const id = objectPath.slice("/objects/uploads/".length);
  return localPaymentProofs.get(id) ?? null;
};

const validatePaymentProofObjectPath = (value: unknown) =>
  isPaymentProofObjectPath(value) ? value : null;

const paymentProofIsAvailable = async (objectPath: string | null): Promise<boolean> => {
  if (!isPaymentProofObjectPath(objectPath)) return false;
  if (getLocalPaymentProof(objectPath)) return true;
  try {
    await objectStorageService.getObjectEntityFile(objectPath);
    return true;
  } catch {
    return false;
  }
};

const validateListingImageMetadata = (body: unknown) => {
  if (!body || typeof body !== "object") return false;
  const input = body as Record<string, unknown>;
  return (
    typeof input.name === "string" &&
    input.name.trim().length > 0 &&
    typeof input.size === "number" &&
    Number.isInteger(input.size) &&
    input.size > 0 &&
    input.size <= listingImageMaxBytes &&
    typeof input.contentType === "string" &&
    listingImageContentTypes.has(input.contentType)
  );
};

const validateListingImageObjectPath = (value: unknown) =>
  typeof value === "string" && listingImageObjectPath.test(value) ? value : null;

const imageUrlForClient = (value: string) =>
  value.startsWith("/objects/listing-images/") ? `/api/listing-images/${value.split("/").pop()}` : value;

const secureListingImageObjects = async (paths: string[], owner: string) => {
  if (paths.length > 8) throw new Error("A listing can contain at most 8 images");
  for (const path of paths) {
    const objectPath = validateListingImageObjectPath(path);
    if (!objectPath) continue;
    const localId = objectPath.split("/").pop() || "";
    const localImage = localListingImageStorageEnabled
      ? await readLocalListingImage(localId)
      : null;
    if (localListingImageStorageEnabled && localImage) {
      if (localImage.userId !== owner) throw new Error("Listing image does not belong to this user");
      if (!listingImageContentTypes.has(localImage.contentType) || localImage.data.length === 0 || localImage.data.length > listingImageMaxBytes) {
        throw new Error("Invalid listing image file");
      }
      continue;
    }
    const objectFile = await objectStorageService.getObjectEntityFile(objectPath);
    const [metadata] = await objectFile.getMetadata();
    const contentType = typeof metadata.contentType === "string" ? metadata.contentType : "";
    const size = Number(metadata.size);
    if (!listingImageContentTypes.has(contentType) || !Number.isFinite(size) || size <= 0 || size > listingImageMaxBytes) {
      throw new Error("Invalid listing image file");
    }
    await objectStorageService.markObjectPrivate(objectPath, owner);
  }
};

let paymentProofCleanupLastStartedAt = 0;
let paymentProofCleanupPromise: Promise<void> | undefined;

export const cleanupAbandonedPaymentProofs = (log: Pick<Logger, "error" | "info">): void => {
  const now = Date.now();
  if (
    paymentProofCleanupPromise ||
    now - paymentProofCleanupLastStartedAt < paymentProofCleanupMinIntervalMs
  ) {
    return;
  }

  paymentProofCleanupLastStartedAt = now;
  paymentProofCleanupPromise = (async () => {
    const referencedProofs = await db
      .select({ objectPath: paymentsTable.proofImageUrl })
      .from(paymentsTable)
      .where(isNotNull(paymentsTable.proofImageUrl));
    const result = await objectStorageService.cleanupUnreferencedPaymentProofs({
      referencedObjectPaths: new Set(
        referencedProofs.flatMap(({ objectPath }) =>
          objectPath ? [objectPath] : [],
        ),
      ),
      olderThan: new Date(now - paymentProofCleanupGracePeriodMs),
    });

    if (result.failedObjectPaths.length > 0) {
      log.error(
        {
          scanned: result.scanned,
          deleted: result.deleted,
          failedObjectPaths: result.failedObjectPaths,
        },
        "Failed to remove abandoned payment proof objects",
      );
    } else if (result.deleted > 0) {
      log.info(
        { scanned: result.scanned, deleted: result.deleted },
        "Removed abandoned payment proof objects",
      );
    }
  })()
    .catch((error) => {
      log.error({ err: error }, "Failed to clean up abandoned payment proofs");
    })
    .finally(() => {
      paymentProofCleanupPromise = undefined;
    });
};

let seedPromise: Promise<void> | undefined;

const categoryCatalog = [
  { name: "الأراضي الزراعية", nameFr: "Terrains agricoles", nameEn: "Agricultural land", slug: "land", icon: "land", subcategories: [{ name: "للبيع", nameFr: "À vendre", nameEn: "For sale", slug: "land-sale" }, { name: "للإيجار", nameFr: "À louer", nameEn: "For rent", slug: "land-rent" }] },
  { name: "الآليات الزراعية", nameFr: "Machines agricoles", nameEn: "Agricultural machinery", slug: "tractors", icon: "tractor", subcategories: [{ name: "جرار", nameFr: "Tracteur", nameEn: "Tractor", slug: "tractor" }, { name: "حاصدة", nameFr: "Moissonneuse", nameEn: "Harvester", slug: "harvester" }, { name: "محراث", nameFr: "Offset", nameEn: "Plough", slug: "plough" }, { name: "بذارة", nameFr: "Semoir", nameEn: "Seeder", slug: "seeder" }, { name: "مقطورة", nameFr: "Remorque", nameEn: "Trailer", slug: "trailer" }, { name: "آخر", nameFr: "Autre", nameEn: "Other", slug: "machinery-other" }] },
  { name: "البذور", nameFr: "Semences", nameEn: "Seeds", slug: "seeds", icon: "wheat", subcategories: [{ name: "أرز — فئة ثلاثة أشهر", nameFr: "Riz — trois mois", nameEn: "Rice — three months", slug: "rice-three-months" }, { name: "أرز — فئة أربعة أشهر", nameFr: "Riz — quatre mois", nameEn: "Rice — four months", slug: "rice-four-months" }, { name: "الخضروات", nameFr: "Légumes", nameEn: "Vegetables", slug: "vegetable-seeds" }, { name: "بذور الأعلاف", nameFr: "Fourrage", nameEn: "Feed seeds", slug: "feed-seeds" }] },
  { name: "الأسمدة", nameFr: "Engrais", nameEn: "Fertilizers", slug: "fertilizers", icon: "flask", subcategories: [{ name: "أسمدة عناصر كبرى NPK", nameFr: "Engrais NPK", nameEn: "NPK fertilizers", slug: "npk" }, { name: "أسمدة عناصر صغرى", nameFr: "Oligo-éléments", nameEn: "Micronutrients", slug: "micronutrients" }, { name: "أسمدة ورقية", nameFr: "Engrais foliaires", nameEn: "Foliar fertilizers", slug: "foliar" }] },
  { name: "قطع غيار الآليات الزراعية", nameFr: "Pièces détachées", nameEn: "Agricultural spare parts", slug: "parts", icon: "wrench", subcategories: [{ name: "قطع جرارات", nameFr: "Pièces de tracteurs", nameEn: "Tractor parts", slug: "tractor-parts" }, { name: "قطع مضخات", nameFr: "Pièces de pompes", nameEn: "Pump parts", slug: "pump-parts" }, { name: "آخر", nameFr: "Autre", nameEn: "Other", slug: "parts-other" }] },
  { name: "تسويق المنتجات الزراعية", nameFr: "Produits agricoles", nameEn: "Agricultural products", slug: "products", icon: "basket", subcategories: [{ name: "الأرز", nameFr: "Riz", nameEn: "Rice", slug: "rice" }, { name: "الخضروات", nameFr: "Légumes", nameEn: "Vegetables", slug: "vegetables" }, { name: "الأعلاف", nameFr: "Fourrage", nameEn: "Feed", slug: "feed" }] },
  { name: "الموارد البشرية الزراعية", nameFr: "Ressources humaines agricoles", nameEn: "Agricultural human resources", slug: "services", icon: "users", subcategories: [{ name: "مكتب دراسات", nameFr: "Bureau d'études", nameEn: "Consulting office", slug: "study-office" }, { name: "خبير", nameFr: "Expert", nameEn: "Expert", slug: "expert" }, { name: "مهندس", nameFr: "Ingénieur", nameEn: "Engineer", slug: "engineer" }, { name: "فني", nameFr: "Technicien", nameEn: "Technician", slug: "technician" }, { name: "عامل", nameFr: "Ouvrier", nameEn: "Worker", slug: "worker" }] },
] as const;

const seedDatabase = async (): Promise<void> => {
  const [{ total: userTotal }] = await db.select({ total: count() }).from(usersTable);
  if (Number(userTotal) === 0) {
    await db.insert(usersTable).values([
      { name: "مزرعة الخير", initials: "م خ", phone: "+222 36 12 45 67", verified: true },
      { name: "أحمد ولد محمد", initials: "أ م", phone: "+222 41 22 33 44", verified: true },
    ]);
  }

  for (const [sortOrder, item] of categoryCatalog.entries()) {
    const [category] = await db.insert(categoriesTable).values({
      name: item.name,
      nameFr: item.nameFr,
      nameEn: item.nameEn,
      slug: item.slug,
      icon: item.icon,
      sortOrder,
      active: true,
    }).onConflictDoUpdate({
      target: categoriesTable.slug,
      set: { name: item.name, nameFr: item.nameFr, nameEn: item.nameEn, icon: item.icon, sortOrder, active: true },
    }).returning();
    for (const [subcategoryOrder, subcategory] of item.subcategories.entries()) {
      await db.insert(subcategoriesTable).values({
        categoryId: category.id,
        name: subcategory.name,
        nameFr: subcategory.nameFr,
        nameEn: subcategory.nameEn,
        slug: subcategory.slug,
        sortOrder: subcategoryOrder,
        active: true,
      }).onConflictDoUpdate({
        target: subcategoriesTable.slug,
        set: { categoryId: category.id, name: subcategory.name, nameFr: subcategory.nameFr, nameEn: subcategory.nameEn, sortOrder: subcategoryOrder, active: true },
      });
    }
  }

  await db.update(categoriesTable).set({ active: false }).where(or(eq(categoriesTable.slug, "machines"), eq(categoriesTable.slug, "irrigation"), eq(categoriesTable.slug, "equipment")));

  const [{ total: packageTotal }] = await db.select({ total: count() }).from(paymentPackagesTable);
  if (Number(packageTotal) === 0) {
    await db.insert(paymentPackagesTable).values([
      { name: "إعلان عادي", description: "إعلان أساسي لمدة 30 يوماً", price: "500", currency: "MRU", durationDays: 30, listingType: "standard", features: ["ظهور في السوق"], featured: false, pinned: false, active: true },
      { name: "إعلان مميز", description: "ظهور أعلى وانتشار أفضل", price: "1500", currency: "MRU", durationDays: 30, listingType: "featured", features: ["ظهور مميز", "أولوية في القوائم"], featured: true, pinned: false, active: true },
      { name: "إعلان VIP", description: "تثبيت الإعلان في مقدمة السوق", price: "3000", currency: "MRU", durationDays: 45, listingType: "vip", features: ["ظهور مميز", "تثبيت الإعلان", "أولوية قصوى"], featured: true, pinned: true, active: true },
    ]);
  }
  const defaultPaymentMethods = [
    {
      name: "Bankily",
      accountNumber: "يحدده المشرف",
      accountName: "حساب السوق",
      instructions: "أرسل المبلغ ثم احتفظ برقم العملية لإرفاقه في طلب التأكيد.",
      currency: "MRU",
      active: true,
    },
    {
      name: "سداد",
      accountNumber: "يحدده المشرف",
      accountName: "حساب السوق",
      instructions: "حوّل المبلغ عبر سداد، ثم احتفظ برقم العملية لإرفاقه في طلب التأكيد.",
      currency: "MRU",
      active: true,
    },
    {
      name: "مصرفي",
      accountNumber: "يحدده المشرف",
      accountName: "حساب السوق",
      instructions: "حوّل المبلغ عبر مصرفي، ثم احتفظ برقم العملية لإرفاقه في طلب التأكيد.",
      currency: "MRU",
      active: true,
    },
  ];
  for (const defaultMethod of defaultPaymentMethods) {
    const [existingMethod] = await db.select({ id: paymentMethodsTable.id })
      .from(paymentMethodsTable)
      .where(eq(paymentMethodsTable.name, defaultMethod.name))
      .limit(1);
    if (!existingMethod) {
      await db.insert(paymentMethodsTable).values(defaultMethod);
    }
  }

  const categories = await db.select().from(categoriesTable);
  const categoryBySlug = new Map(categories.map((category) => [category.slug, category.id]));
  const subcategories = await db.select().from(subcategoriesTable);
  const subcategoryBySlug = new Map(subcategories.map((subcategory) => [subcategory.slug, subcategory.id]));
  await db.update(listingsTable).set({ subcategoryId: subcategoryBySlug.get("tractor") ?? null }).where(and(eq(listingsTable.categoryId, categoryBySlug.get("tractors")!), isNull(listingsTable.subcategoryId)));
  await db.update(listingsTable).set({ subcategoryId: subcategoryBySlug.get("land-sale") ?? null }).where(and(eq(listingsTable.categoryId, categoryBySlug.get("land")!), isNull(listingsTable.subcategoryId)));

  const [{ total: listingTotal }] = await db.select({ total: count() }).from(listingsTable);
  if (Number(listingTotal) > 0) return;
  const [seller, buyer] = await db.select().from(usersTable).orderBy(asc(usersTable.id)).limit(2);
  await db.insert(listingsTable).values([
    {
      sellerId: seller.id,
      contactPhone: "+222 36 12 45 67",
      title: "جرار Massey Ferguson 4708",
      categoryId: categoryBySlug.get("tractors")!,
      subcategoryId: subcategoryBySlug.get("tractor")!,
      price: "485000",
      currency: "MRU",
      location: "روصو، موريتانيا",
      condition: "used",
      year: 2021,
      manufacturer: "Massey Ferguson",
      model: "4708",
      hours: 1840,
      description: "جرار بحالة ممتازة، تمت صيانته بالكامل وجاهز للعمل في الحقول.",
      imageUrl: "https://images.unsplash.com/photo-1530267981375-f0de937f5f13?auto=format&fit=crop&w=1200&q=85",
      images: ["https://images.unsplash.com/photo-1530267981375-f0de937f5f13?auto=format&fit=crop&w=1200&q=85"],
      featured: true,
    },
    {
      sellerId: buyer.id,
      contactPhone: "+222 41 22 33 44",
      title: "أرض زراعية خصبة قرب نهر السنغال",
      categoryId: categoryBySlug.get("land")!,
      subcategoryId: subcategoryBySlug.get("land-sale")!,
      price: "1250000",
      currency: "MRU",
      location: "بوغي، موريتانيا",
      condition: "new",
      area: "18",
      waterAvailable: true,
      description: "أرض زراعية مساحتها 18 هكتارًا، قريبة من مصدر المياه ومناسبة للزراعة المروية.",
      imageUrl: "https://images.unsplash.com/photo-1500382017468-9049fed747ef?auto=format&fit=crop&w=1200&q=85",
      images: ["https://images.unsplash.com/photo-1500382017468-9049fed747ef?auto=format&fit=crop&w=1200&q=85"],
      featured: true,
    },
    {
      sellerId: seller.id,
      contactPhone: "+222 36 12 45 67",
      title: "مضخة مياه زراعية عالية الكفاءة",
      categoryId: categoryBySlug.get("irrigation")!,
      subcategoryId: null,
      price: "78000",
      currency: "MRU",
      location: "نواكشوط، موريتانيا",
      condition: "new",
      manufacturer: "Honda",
      model: "WB30XT",
      description: "مضخة مياه للاستخدام الزراعي، موفرة للوقود وسهلة النقل.",
      imageUrl: "https://images.unsplash.com/photo-1625246333195-78d9c38ad449?auto=format&fit=crop&w=1200&q=85",
      images: ["https://images.unsplash.com/photo-1625246333195-78d9c38ad449?auto=format&fit=crop&w=1200&q=85"],
      featured: false,
    },
  ]);
};

const ensureSeed = (): Promise<void> => {
  seedPromise ??= seedDatabase();
  return seedPromise;
};

const parseNumeric = (value: string | number | null | undefined): number | null => {
  if (value == null) return null;
  const parsed = Number(value);
  return Number.isFinite(parsed) ? parsed : null;
};

const formatListing = (row: {
  listing: typeof listingsTable.$inferSelect;
  category: typeof categoriesTable.$inferSelect;
  subcategory?: typeof subcategoriesTable.$inferSelect | null;
  seller: typeof usersTable.$inferSelect;
  isSaved?: boolean;
}) => ({
  id: row.listing.id,
  title: row.listing.title,
  category: row.category.name,
  categorySlug: row.category.slug,
  subcategory: row.subcategory?.name ?? null,
  subcategorySlug: row.subcategory?.slug ?? null,
  price: Number(row.listing.price),
  currency: row.listing.currency,
  location: row.listing.location,
  condition: row.listing.condition as "new" | "used",
  year: row.listing.year,
  manufacturer: row.listing.manufacturer,
  model: row.listing.model,
  hours: row.listing.hours,
  area: parseNumeric(row.listing.area),
  waterAvailable: row.listing.waterAvailable,
  electricityAvailable: row.listing.electricityAvailable,
  ownershipType: row.listing.ownershipType,
  contactPhone: row.listing.contactPhone,
  attributes: row.listing.attributes ?? {},
  description: row.listing.description,
  imageUrl: imageUrlForClient(row.listing.imageUrl),
  images: row.listing.images.map(imageUrlForClient),
  seller: {
    id: row.seller.id,
    name: row.seller.name,
    initials: row.seller.initials,
    verified: row.seller.verified,
    phone: row.listing.contactPhone,
  },
  createdAt: row.listing.createdAt,
  expiresAt: row.listing.expiresAt,
  featured: row.listing.featured,
  isSaved: row.isSaved ?? false,
});

const activeListingWhere = () =>
  and(
    eq(listingsTable.status, "active"),
    or(isNull(listingsTable.expiresAt), gt(listingsTable.expiresAt, new Date())),
  );

const getRows = async (where?: ReturnType<typeof and>) => {
  return db
    .select({ listing: listingsTable, category: categoriesTable, subcategory: subcategoriesTable, seller: usersTable })
    .from(listingsTable)
    .innerJoin(categoriesTable, eq(listingsTable.categoryId, categoriesTable.id))
    .leftJoin(subcategoriesTable, eq(listingsTable.subcategoryId, subcategoriesTable.id))
    .innerJoin(usersTable, eq(listingsTable.sellerId, usersTable.id))
    .where(where);
};

const getSavedIds = async (listingIds: number[], userId?: number) => {
  if (listingIds.length === 0 || !userId) return new Set<number>();
  const saved = await db
    .select({ listingId: savedListingsTable.listingId })
    .from(savedListingsTable)
    .where(and(eq(savedListingsTable.userId, userId), or(...listingIds.map((id) => eq(savedListingsTable.listingId, id)))));
  return new Set(saved.map((item) => item.listingId));
};

const getCategoryCatalog = async (activeOnly = true) => {
  const categories = activeOnly
    ? await db.select().from(categoriesTable).where(eq(categoriesTable.active, true)).orderBy(asc(categoriesTable.sortOrder), asc(categoriesTable.id))
    : await db.select().from(categoriesTable).orderBy(asc(categoriesTable.sortOrder), asc(categoriesTable.id));
  const subcategories = activeOnly
    ? await db.select().from(subcategoriesTable).where(eq(subcategoriesTable.active, true)).orderBy(asc(subcategoriesTable.sortOrder), asc(subcategoriesTable.id))
    : await db.select().from(subcategoriesTable).orderBy(asc(subcategoriesTable.sortOrder), asc(subcategoriesTable.id));
  const counts = await db
    .select({ categoryId: listingsTable.categoryId, total: count(listingsTable.id) })
    .from(listingsTable)
    .where(activeListingWhere())
    .groupBy(listingsTable.categoryId);
  const countByCategory = new Map(counts.map((item) => [item.categoryId, Number(item.total)]));
  return categories.map((category) => ({
    ...category,
    count: countByCategory.get(category.id) ?? 0,
    subcategories: subcategories.filter((subcategory) => subcategory.categoryId === category.id),
  }));
};

router.get("/categories", async (_req, res): Promise<void> => {
  await ensureSeed();
  res.json(ListCategoriesResponse.parse(await getCategoryCatalog()));
});

router.get("/categories/:slug/subcategories", async (req, res): Promise<void> => {
  await ensureSeed();
  const parsed = ListSubcategoriesParams.safeParse(req.params);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }
  const [category] = await db.select({ id: categoriesTable.id }).from(categoriesTable).where(eq(categoriesTable.slug, parsed.data.slug));
  if (!category) {
    res.status(404).json({ error: "Category not found" });
    return;
  }
  const rows = await db.select().from(subcategoriesTable).where(and(eq(subcategoriesTable.categoryId, category.id), eq(subcategoriesTable.active, true))).orderBy(asc(subcategoriesTable.sortOrder));
  res.json(ListSubcategoriesResponse.parse(rows));
});

router.get("/admin/categories", async (_req, res): Promise<void> => {
  await ensureSeed();
  res.json(ListAdminCategoriesResponse.parse(await getCategoryCatalog(false)));
});

router.post("/admin/categories", async (req, res): Promise<void> => {
  await ensureSeed();
  const parsed = CreateCategoryBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }
  const [category] = await db.insert(categoriesTable).values(parsed.data).returning();
  const result = (await getCategoryCatalog(false)).find((item) => item.id === category.id);
  res.status(201).json(CreateCategoryResponse.parse(result));
});

router.patch("/admin/categories/:id", async (req, res): Promise<void> => {
  await ensureSeed();
  const params = UpdateCategoryParams.safeParse(req.params);
  const parsed = UpdateCategoryBody.safeParse(req.body);
  if (!params.success || !parsed.success) {
    res.status(400).json({ error: "Invalid category payload" });
    return;
  }
  const [category] = await db.update(categoriesTable).set(parsed.data).where(eq(categoriesTable.id, params.data.id)).returning();
  if (!category) {
    res.status(404).json({ error: "Category not found" });
    return;
  }
  const result = (await getCategoryCatalog(false)).find((item) => item.id === category.id);
  res.json(UpdateCategoryResponse.parse(result));
});

router.delete("/admin/categories/:id", async (req, res): Promise<void> => {
  await ensureSeed();
  const params = DeleteCategoryParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }
  const [category] = await db.update(categoriesTable).set({ active: false }).where(eq(categoriesTable.id, params.data.id)).returning();
  if (!category) {
    res.status(404).json({ error: "Category not found" });
    return;
  }
  res.sendStatus(204);
});

router.post("/admin/categories/:id/subcategories", async (req, res): Promise<void> => {
  await ensureSeed();
  const params = CreateSubcategoryParams.safeParse(req.params);
  const parsed = CreateSubcategoryBody.safeParse(req.body);
  if (!params.success || !parsed.success) {
    res.status(400).json({ error: "Invalid subcategory payload" });
    return;
  }
  const [subcategory] = await db.insert(subcategoriesTable).values({ ...parsed.data, categoryId: params.data.id }).returning();
  res.status(201).json(CreateSubcategoryResponse.parse(subcategory));
});

router.patch("/admin/subcategories/:id", async (req, res): Promise<void> => {
  await ensureSeed();
  const params = UpdateSubcategoryParams.safeParse(req.params);
  const parsed = UpdateSubcategoryBody.safeParse(req.body);
  if (!params.success || !parsed.success) {
    res.status(400).json({ error: "Invalid subcategory payload" });
    return;
  }
  const [subcategory] = await db.update(subcategoriesTable).set(parsed.data).where(eq(subcategoriesTable.id, params.data.id)).returning();
  if (!subcategory) {
    res.status(404).json({ error: "Subcategory not found" });
    return;
  }
  res.json(UpdateSubcategoryResponse.parse(subcategory));
});

router.delete("/admin/subcategories/:id", async (req, res): Promise<void> => {
  await ensureSeed();
  const params = DeleteSubcategoryParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }
  const [subcategory] = await db.update(subcategoriesTable).set({ active: false }).where(eq(subcategoriesTable.id, params.data.id)).returning();
  if (!subcategory) {
    res.status(404).json({ error: "Subcategory not found" });
    return;
  }
  res.sendStatus(204);
});

router.get("/locations", async (_req, res): Promise<void> => {
  await ensureSeed();
  const locations = await db
    .select({ name: listingsTable.location, listingCount: count(listingsTable.id) })
    .from(listingsTable)
    .where(activeListingWhere())
    .groupBy(listingsTable.location)
    .orderBy(desc(count(listingsTable.id)));
  res.json(ListLocationsResponse.parse(locations.map((item, index) => ({
    id: index + 1,
    name: item.name,
    country: "موريتانيا",
    listingCount: Number(item.listingCount),
  }))));
});

router.get("/listings", async (req, res): Promise<void> => {
  try {
    await ensureSeed();
    const actor = await marketplaceUserForRequest(req);
    const featuredQuery = req.query.featured;
    const normalizedQuery =
      featuredQuery === "true" || featuredQuery === "false"
        ? { ...req.query, featured: featuredQuery === "true" }
        : req.query;
    const parsed = ListListingsQueryParams.safeParse(normalizedQuery);
    if (!parsed.success) {
      res.status(400).json({ error: parsed.error.message });
      return;
    }
    const params = parsed.data;
    const activeWhere = activeListingWhere();
    const clauses: SQL[] = activeWhere ? [activeWhere] : [];
    if (params.q) {
      const search = or(ilike(listingsTable.title, `%${params.q}%`), ilike(listingsTable.description, `%${params.q}%`));
      if (search) clauses.push(search);
    }
    if (params.category) clauses.push(eq(categoriesTable.slug, params.category));
    if (params.subcategory) clauses.push(eq(subcategoriesTable.slug, params.subcategory));
    if (params.location) clauses.push(ilike(listingsTable.location, `%${params.location}%`));
    const attributeFilter = (key: string, value: string) => sql`${listingsTable.attributes}->>${key} ILIKE ${`%${value}%`}`;
    if (params.saleType) clauses.push(attributeFilter("saleType", params.saleType));
    if (params.reference) clauses.push(attributeFilter("reference", params.reference));
    if (params.brand) clauses.push(attributeFilter("brand", params.brand));
    if (params.productType) clauses.push(attributeFilter("productType", params.productType));
    if (params.minPrice != null) clauses.push(gte(listingsTable.price, String(params.minPrice)));
    if (params.maxPrice != null) clauses.push(lte(listingsTable.price, String(params.maxPrice)));
    if (params.condition) clauses.push(eq(listingsTable.condition, params.condition));
    if (params.manufacturer) clauses.push(ilike(listingsTable.manufacturer, `%${params.manufacturer}%`));
    if (params.model) clauses.push(ilike(listingsTable.model, `%${params.model}%`));
    if (params.year) clauses.push(eq(listingsTable.year, params.year));
     if (params.featured != null) {
       clauses.push(eq(listingsTable.featured, params.featured));
       if (params.featured) {
         clauses.push(sql`EXISTS (
           SELECT 1
           FROM ${paymentsTable}
           INNER JOIN ${paymentPackagesTable}
             ON ${paymentsTable.packageId} = ${paymentPackagesTable.id}
           WHERE ${paymentsTable.listingId} = ${listingsTable.id}
             AND ${paymentsTable.status} = 'confirmed'
             AND ${paymentPackagesTable.featured} = true
         )`);
       }
     }
    const where = clauses.length ? and(...clauses) : undefined;
    const orderBy = params.sort === "price_asc" ? asc(listingsTable.price) : params.sort === "price_desc" ? desc(listingsTable.price) : desc(listingsTable.createdAt);
    const [rows, [{ total }]] = await Promise.all([
      db.select({ listing: listingsTable, category: categoriesTable, subcategory: subcategoriesTable, seller: usersTable })
        .from(listingsTable)
        .innerJoin(categoriesTable, eq(listingsTable.categoryId, categoriesTable.id))
        .leftJoin(subcategoriesTable, eq(listingsTable.subcategoryId, subcategoriesTable.id))
        .innerJoin(usersTable, eq(listingsTable.sellerId, usersTable.id))
        .where(where)
        .orderBy(orderBy)
        .limit(params.limit)
        .offset((params.page - 1) * params.limit),
      db.select({ total: count(listingsTable.id) })
        .from(listingsTable)
        .innerJoin(categoriesTable, eq(listingsTable.categoryId, categoriesTable.id))
        .leftJoin(subcategoriesTable, eq(listingsTable.subcategoryId, subcategoriesTable.id))
        .where(where),
    ]);
    const savedIds = await getSavedIds(rows.map((row) => row.listing.id), actor?.id);
    const response = {
      items: rows.map((row) => formatListing({ ...row, isSaved: savedIds.has(row.listing.id) })),
      total: Number(total),
      page: params.page,
      limit: params.limit,
    };
    res.json(ListListingsResponse.parse(response));
  } catch (error) {
    req.log.error({ err: error, query: req.query }, "Failed to load marketplace listings");
    const details = process.env.NODE_ENV === "development" && error instanceof Error
      ? error.message
      : undefined;
    res.status(500).json({
      error: "Failed to load marketplace listings",
      ...(details ? { detail: details } : {}),
    });
  }
});

router.get("/listings/:id", async (req, res): Promise<void> => {
  await ensureSeed();
  const actor = await marketplaceUserForRequest(req);
  const parsed = GetListingParams.safeParse(req.params);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }
  const [row] = await getRows(and(eq(listingsTable.id, parsed.data.id), activeListingWhere()));
  if (!row) {
    res.status(404).json({ error: "Listing not found" });
    return;
  }
  const savedIds = await getSavedIds([row.listing.id], actor?.id);
  res.json(GetListingResponse.parse(formatListing({ ...row, isSaved: savedIds.has(row.listing.id) })));
});

const findCategory = async (slug: string) => {
  const [category] = await db.select().from(categoriesTable).where(eq(categoriesTable.slug, slug));
  return category;
};

const findSubcategory = async (slug: string | null | undefined, categoryId: number) => {
  if (!slug) return null;
  const [subcategory] = await db.select().from(subcategoriesTable).where(and(eq(subcategoriesTable.slug, slug), eq(subcategoriesTable.categoryId, categoryId)));
  return subcategory ?? null;
};

const listingFromBody = (body: typeof CreateListingBody._output, sellerId: number, categoryId: number, subcategoryId: number | null) => ({
  sellerId,
  contactPhone: body.contactPhone,
  title: body.title,
  categoryId,
  subcategoryId,
  price: String(body.price),
  currency: body.currency,
  location: body.location,
  condition: body.condition,
  year: body.year ?? null,
  manufacturer: body.manufacturer ?? null,
  model: body.model ?? null,
  hours: body.hours ?? null,
  area: body.area == null ? null : String(body.area),
  waterAvailable: body.waterAvailable ?? null,
  electricityAvailable: body.electricityAvailable ?? null,
  ownershipType: body.ownershipType ?? null,
  attributes: body.attributes ?? {},
  description: body.description,
  expiresAt: body.expiresAt,
  imageUrl: body.images?.[0] ?? body.imageUrl ?? "",
  images: body.images?.length ? body.images : body.imageUrl ? [body.imageUrl] : [],
});

router.post("/listing-image/uploads/request-url", async (req, res): Promise<void> => {
  const actor = await authenticatedMarketplaceUser(req, res);
  if (!actor) return;
  if (!validateListingImageMetadata(req.body)) {
    res.status(400).json({ error: "Invalid listing image file" });
    return;
  }

  if (localListingImageStorageEnabled) {
    const id = randomUUID();
    res.json({
      uploadURL: `/api/listing-image/uploads/local/${id}`,
      objectPath: `/objects/listing-images/${id}`,
    });
    return;
  }

  try {
    const uploadURL = await objectStorageService.getObjectEntityUploadURL("listing-images");
    const objectPath = objectStorageService.normalizeObjectEntityPath(uploadURL);
    if (!listingImageObjectPath.test(objectPath)) {
      res.status(500).json({ error: "Invalid listing image object path" });
      return;
    }
    res.json({ uploadURL, objectPath });
  } catch (error) {
    req.log.error({ err: error }, "Failed to create listing image upload URL");
    if (localListingImageStorageEnabled) {
      const id = randomUUID();
      res.json({
        uploadURL: `/api/listing-image/uploads/local/${id}`,
        objectPath: `/objects/listing-images/${id}`,
      });
      return;
    }
    res.status(503).json({ error: "Listing image storage is unavailable" });
  }
});

router.put(
  "/listing-image/uploads/local/:id",
  express.raw({
    type: ["image/png", "image/jpeg", "image/webp"],
    limit: listingImageMaxBytes,
  }),
  async (req, res): Promise<void> => {
    if (!localListingImageStorageEnabled) {
      res.sendStatus(404);
      return;
    }
    const actor = await authenticatedMarketplaceUser(req, res);
    if (!actor) return;
    const id = typeof req.params.id === "string" ? req.params.id : "";
    const contentType = req.headers["content-type"];
    const data = req.body;
    if (
      !/^[0-9a-f-]{36}$/i.test(id) ||
      typeof contentType !== "string" ||
      !listingImageContentTypes.has(contentType) ||
      !Buffer.isBuffer(data) ||
      data.length === 0 ||
      data.length > listingImageMaxBytes
    ) {
      res.status(400).json({ error: "Invalid listing image upload" });
      return;
    }
    while (localListingImages.size >= 200) {
      const oldest = localListingImages.keys().next().value;
      if (!oldest) break;
      localListingImages.delete(oldest);
    }
    const image = {
      data,
      contentType,
      userId: getAuth(req).userId!,
      createdAt: Date.now(),
    };
    try {
      await persistLocalListingImage(id, image);
      localListingImages.set(id, image);
    } catch (error) {
      req.log.error({ err: error }, "Failed to persist local listing image");
      res.status(503).json({ error: "Listing image storage is unavailable" });
      return;
    }
    res.sendStatus(204);
  },
);

router.get("/listing-images/:id", async (req, res): Promise<void> => {
  const objectId = typeof req.params.id === "string" ? req.params.id : "";
  if (!/^[0-9a-f-]{36}$/i.test(objectId)) {
    res.status(404).json({ error: "Listing image not found" });
    return;
  }
  const actor = await marketplaceUserForRequest(req);
  const objectPath = `/objects/listing-images/${objectId}`;
  const imageMatch = or(
    eq(listingsTable.imageUrl, objectPath),
    sql`${listingsTable.images} @> ARRAY[${objectPath}]::text[]`,
  );
  const visibility = actor
    ? or(activeListingWhere(), eq(listingsTable.sellerId, actor.id))
    : activeListingWhere();
  const [listing] = await db.select({ id: listingsTable.id }).from(listingsTable).where(and(imageMatch, visibility)).limit(1);
  if (!listing) {
    res.status(404).json({ error: "Listing image not found" });
    return;
  }

  const localImage = localListingImageStorageEnabled
    ? await readLocalListingImage(objectId)
    : null;
  if (localListingImageStorageEnabled && localImage) {
    res.status(200);
    res.setHeader("Content-Type", localImage.contentType);
    res.setHeader("Cache-Control", "private, no-store");
    res.setHeader("Content-Disposition", "inline");
    res.send(localImage.data);
    return;
  }

  try {
    const objectFile = await objectStorageService.getObjectEntityFile(objectPath);
    const response = await objectStorageService.downloadObject(objectFile);
    res.status(response.status);
    response.headers.forEach((value, key) => res.setHeader(key, value));
    if (response.body) {
      Readable.fromWeb(response.body as ReadableStream<Uint8Array>).pipe(res);
    } else {
      res.end();
    }
  } catch (error) {
    if (error instanceof ObjectNotFoundError) {
      res.status(404).json({ error: "Listing image not found" });
      return;
    }
    req.log.error({ err: error }, "Failed to serve listing image");
    res.status(503).json({ error: "Listing image storage is unavailable" });
  }
});

router.post("/listings", async (req, res): Promise<void> => {
  await ensureSeed();
  const actor = await authenticatedMarketplaceUser(req, res);
  if (!actor) return;
  const parsed = CreateListingBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }
  if (parsed.data.expiresAt.getTime() <= Date.now()) {
    res.status(400).json({ error: "Listing expiration must be in the future" });
    return;
  }
  const category = await findCategory(parsed.data.category);
  if (!category) {
    res.status(400).json({ error: "Category not found" });
    return;
  }
  const subcategory = await findSubcategory(parsed.data.subcategory, category.id);
  if (parsed.data.subcategory && !subcategory) {
    res.status(400).json({ error: "Subcategory not found for category" });
    return;
  }
  try {
    await secureListingImageObjects(parsed.data.images ?? (parsed.data.imageUrl ? [parsed.data.imageUrl] : []), getAuth(req).userId!);
  } catch (error) {
    if (error instanceof ObjectNotFoundError) {
      res.status(400).json({ error: "One or more listing images were not uploaded" });
      return;
    }
    res.status(400).json({ error: error instanceof Error ? error.message : "Invalid listing images" });
    return;
  }
  const listing = await db.transaction(async (tx) => {
    const [createdListing] = await tx.insert(listingsTable).values({
      ...listingFromBody(parsed.data, actor.id, category.id, subcategory?.id ?? null),
       status: "pending_payment",
    }).returning();

    const admins = await tx
      .select({ id: usersTable.id })
      .from(usersTable)
      .where(or(eq(usersTable.role, "admin"), eq(usersTable.role, "moderator")));

    if (admins.length) {
      await tx.insert(notificationsTable).values(admins.map((admin) => ({
        userId: admin.id,
        listingId: createdListing.id,
        title: "إعلان جديد بانتظار المراجعة",
        body: `تم إنشاء الإعلان «${createdListing.title}» وهو بانتظار مراجعة الإدارة وتأكيد الدفع.`,
        type: "admin_new_listing",
        read: false,
      })));
    }

    return createdListing;
  });
  const [row] = await getRows(eq(listingsTable.id, listing.id));
  res.status(201).json(CreateListingResponse.parse(formatListing(row)));
});

router.patch("/listings/:id", async (req, res): Promise<void> => {
  await ensureSeed();
  const actor = await authenticatedMarketplaceUser(req, res);
  if (!actor) return;
  const params = UpdateListingParams.safeParse(req.params);
  const parsed = UpdateListingBody.safeParse(req.body);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }
  if (parsed.data.expiresAt.getTime() <= Date.now()) {
    res.status(400).json({ error: "Listing expiration must be in the future" });
    return;
  }
  const category = await findCategory(parsed.data.category);
  if (!category) {
    res.status(400).json({ error: "Category not found" });
    return;
  }
  const subcategory = await findSubcategory(parsed.data.subcategory, category.id);
  if (parsed.data.subcategory && !subcategory) {
    res.status(400).json({ error: "Subcategory not found for category" });
    return;
  }
  try {
    await secureListingImageObjects(parsed.data.images ?? (parsed.data.imageUrl ? [parsed.data.imageUrl] : []), getAuth(req).userId!);
  } catch (error) {
    if (error instanceof ObjectNotFoundError) {
      res.status(400).json({ error: "One or more listing images were not uploaded" });
      return;
    }
    res.status(400).json({ error: error instanceof Error ? error.message : "Invalid listing images" });
    return;
  }
  const listingValues = listingFromBody(
    { ...parsed.data, contactPhone: parsed.data.contactPhone ?? "" },
    actor.id,
    category.id,
    subcategory?.id ?? null,
  );
  const { contactPhone, ...listingValuesWithoutContactPhone } = listingValues;
  const [listing] = await db.update(listingsTable).set({
    ...listingValuesWithoutContactPhone,
    ...(parsed.data.contactPhone === undefined ? {} : { contactPhone }),
    status: "pending_payment",
  }).where(and(eq(listingsTable.id, params.data.id), eq(listingsTable.sellerId, actor.id))).returning();
  if (!listing) {
    res.status(404).json({ error: "Listing not found" });
    return;
  }
  const [row] = await getRows(eq(listingsTable.id, listing.id));
  res.json(UpdateListingResponse.parse(formatListing(row)));
});

router.get("/payment-options", async (req, res): Promise<void> => {
  await ensureSeed();
  const actor = await authenticatedMarketplaceUser(req, res);
  if (!actor) return;
  const [packages, methods] = await Promise.all([
    db.select().from(paymentPackagesTable).where(eq(paymentPackagesTable.active, true)).orderBy(asc(paymentPackagesTable.price)),
    db.select().from(paymentMethodsTable).where(eq(paymentMethodsTable.active, true)).orderBy(asc(paymentMethodsTable.createdAt)),
  ]);
  res.json({ packages, methods });
});

router.put(
  "/payment-proof/uploads/local/:id",
  express.raw({
    type: ["image/png", "image/jpeg", "image/webp"],
    limit: maxPaymentProofBytes,
  }),
  async (req, res): Promise<void> => {
    if (!localPaymentProofStorageEnabled) {
      res.sendStatus(404);
      return;
    }
    const actor = await authenticatedMarketplaceUser(req, res);
    if (!actor) return;
    const id = typeof req.params.id === "string" ? req.params.id : "";
    const contentType = req.headers["content-type"];
    const data = req.body;
    if (
      !isPaymentProofObjectPath(`/objects/uploads/${id}`) ||
      !isPaymentProofOwnedByUser(`/objects/uploads/${id}`, getAuth(req).userId!) ||
      typeof contentType !== "string" ||
      !paymentProofContentTypes.has(contentType) ||
      !Buffer.isBuffer(data) ||
      data.length === 0 ||
      data.length > maxPaymentProofBytes
    ) {
      res.status(400).json({ error: "Invalid payment proof upload" });
      return;
    }
    while (localPaymentProofs.size >= 100) {
      const oldest = localPaymentProofs.keys().next().value;
      if (!oldest) break;
      localPaymentProofs.delete(oldest);
    }
    localPaymentProofs.set(id, {
      data,
      contentType,
      userId: getAuth(req).userId!,
      createdAt: Date.now(),
    });
    res.sendStatus(204);
  },
);

router.post("/payment-proof/uploads/request-url", async (req, res): Promise<void> => {
  const actor = await authenticatedMarketplaceUser(req, res);
  if (!actor) return;
  if (!validatePaymentProofMetadata(req.body)) {
    res.status(400).json({ error: "Invalid payment proof file" });
    return;
  }
  const userId = getAuth(req).userId!;

  if (localPaymentProofStorageEnabled) {
    const id = randomUUID();
    const uploadId = createPaymentProofUploadId(userId, id);
    res.json({
      uploadURL: `/api/payment-proof/uploads/local/${uploadId}`,
      objectPath: `/objects/uploads/${uploadId}`,
    });
    return;
  }

  try {
    const id = randomUUID();
    const uploadId = createPaymentProofUploadId(userId, id);
    const uploadURL = await objectStorageService.getObjectEntityUploadURL(
      "uploads",
      uploadId,
    );
    const objectPath = objectStorageService.normalizeObjectEntityPath(uploadURL);
    if (!isPaymentProofObjectPath(objectPath)) {
      res.status(500).json({ error: "Invalid private object path" });
      return;
    }
    res.json({ uploadURL, objectPath });
    cleanupAbandonedPaymentProofs(req.log);
  } catch (error) {
    req.log.error({ err: error }, "Failed to create payment proof upload URL");
    res.status(503).json({ error: "Payment proof storage is unavailable" });
  }
});

router.get("/payments/mine", async (req, res): Promise<void> => {
  const actor = await authenticatedMarketplaceUser(req, res);
  if (!actor) return;
  const rows = await db.select({
    payment: paymentsTable,
    listing: listingsTable,
    package: paymentPackagesTable,
    method: paymentMethodsTable,
  })
    .from(paymentsTable)
    .leftJoin(listingsTable, eq(paymentsTable.listingId, listingsTable.id))
    .leftJoin(paymentPackagesTable, eq(paymentsTable.packageId, paymentPackagesTable.id))
    .leftJoin(paymentMethodsTable, eq(paymentsTable.paymentMethodId, paymentMethodsTable.id))
    .where(eq(paymentsTable.userId, actor.id))
    .orderBy(desc(paymentsTable.createdAt));
  const items = await Promise.all(rows.map(async ({ payment, listing, package: pkg, method }) => ({
    ...payment,
    proofAvailable: await paymentProofIsAvailable(payment.proofImageUrl),
    listing,
    package: pkg,
    method,
  })));
  res.json({ items });
});

router.post("/payments", async (req, res): Promise<void> => {
  const actor = await authenticatedMarketplaceUser(req, res);
  if (!actor) return;
  const listingId = parsePaymentId(req.body?.listingId);
  const packageId = parsePaymentId(req.body?.packageId);
  const paymentMethodId = parsePaymentId(req.body?.paymentMethodId);
  const transactionReference = typeof req.body?.transactionReference === "string" ? req.body.transactionReference.trim() : "";
  const accountHolderName = typeof req.body?.accountHolderName === "string" ? req.body.accountHolderName.trim() : "";
  const paymentDate = typeof req.body?.transactionDate === "string" ? new Date(req.body.transactionDate) : null;
  const proofObjectPath = validatePaymentProofObjectPath(req.body?.proofObjectPath);
  if (!listingId || !packageId || !paymentMethodId || !transactionReference || !accountHolderName || !paymentDate || Number.isNaN(paymentDate.getTime()) || !proofObjectPath) {
    res.status(400).json({ error: "All payment confirmation fields are required" });
    return;
  }
  if (!isPaymentProofOwnedByUser(proofObjectPath, getAuth(req).userId!)) {
    res.status(403).json({ error: "Payment proof upload does not belong to this user" });
    return;
  }
  const [listing] = await db.select().from(listingsTable).where(and(eq(listingsTable.id, listingId), eq(listingsTable.sellerId, actor.id)));
  const [paymentPackage] = await db.select().from(paymentPackagesTable).where(and(eq(paymentPackagesTable.id, packageId), eq(paymentPackagesTable.active, true)));
  const [paymentMethod] = await db.select().from(paymentMethodsTable).where(and(eq(paymentMethodsTable.id, paymentMethodId), eq(paymentMethodsTable.active, true)));
  if (!listing || !paymentPackage || !paymentMethod) {
    res.status(404).json({ error: "Listing, package, or payment method not found" });
    return;
  }
  if (Number(req.body?.amount) !== Number(paymentPackage.price)) {
    res.status(400).json({ error: "Payment amount does not match the selected package" });
    return;
  }
  const [existingPending] = await db.select().from(paymentsTable).where(and(eq(paymentsTable.listingId, listingId), eq(paymentsTable.status, "pending")));
  if (existingPending) {
    res.status(409).json({ error: "A payment confirmation is already pending" });
    return;
  }
  const localProofId = proofObjectPath.slice("/objects/uploads/".length);
  const localProof = localPaymentProofs.get(localProofId);
  if (localPaymentProofStorageEnabled && localProof) {
    if (localProof.userId !== getAuth(req).userId) {
      res.status(403).json({ error: "Payment proof upload does not belong to this user" });
      return;
    }
  } else {
    try {
      await objectStorageService.getObjectEntityFile(proofObjectPath);
      await objectStorageService.markObjectPrivate(proofObjectPath, getAuth(req).userId!);
    } catch (error) {
      if (error instanceof ObjectNotFoundError) {
        res.status(400).json({ error: "Payment proof upload was not completed" });
        return;
      }
      req.log.error({ err: error }, "Failed to secure payment proof");
      res.status(503).json({ error: "Payment proof storage is unavailable" });
      return;
    }
  }
  const payment = await db.transaction(async (tx) => {
    const [created] = await tx.insert(paymentsTable).values({
      userId: actor.id,
      listingId,
      packageId,
      paymentMethodId,
      amount: String(paymentPackage.price),
      currency: paymentPackage.currency,
      transactionReference,
      transactionDate: paymentDate,
      accountHolderName,
      proofImageUrl: proofObjectPath,
      status: "pending",
    }).returning();
       await tx.update(listingsTable).set({ status: "pending_payment" }).where(eq(listingsTable.id, listingId));
    await tx.insert(notificationsTable).values({
      userId: actor.id,
      title: "تم إرسال طلب الدفع",
      body: `تم استلام طلب تأكيد الدفع للإعلان «${listing.title}» وسيتم مراجعته من الإدارة.`,
      type: "payment_pending",
    });
    return created;
  });
  res.status(201).json(payment);
});

router.get("/notifications", async (req, res): Promise<void> => {
  const actor = await authenticatedMarketplaceUser(req, res);
  if (!actor) return;
  res.json({
    items: await db.select()
      .from(notificationsTable)
      .where(and(eq(notificationsTable.userId, actor.id), ne(notificationsTable.type, "admin_new_listing")))
      .orderBy(desc(notificationsTable.createdAt))
      .limit(50),
  });
});

router.patch("/notifications/:id/read", async (req, res): Promise<void> => {
  const actor = await authenticatedMarketplaceUser(req, res);
  if (!actor) return;
  const id = parsePaymentId(req.params.id);
  if (!id) {
    res.status(400).json({ error: "Invalid notification id" });
    return;
  }
  const [notification] = await db.update(notificationsTable)
    .set({ read: true })
    .where(and(
      eq(notificationsTable.id, id),
      eq(notificationsTable.userId, actor.id),
      ne(notificationsTable.type, "admin_new_listing"),
    ))
    .returning();
  if (!notification) {
    res.status(404).json({ error: "Notification not found" });
    return;
  }
  res.json(notification);
});

router.delete("/listings/:id", async (req, res): Promise<void> => {
  await ensureSeed();
  const actor = await authenticatedMarketplaceUser(req, res);
  if (!actor) return;
  const parsed = DeleteListingParams.safeParse(req.params);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }
  const [deleted] = await db.update(listingsTable).set({ status: "suspended" }).where(and(eq(listingsTable.id, parsed.data.id), eq(listingsTable.sellerId, actor.id))).returning();
  if (!deleted) {
    res.status(404).json({ error: "Listing not found" });
    return;
  }
  res.sendStatus(204);
});

router.post("/listings/:id/favorite", async (req, res): Promise<void> => {
  await ensureSeed();
  const actor = await authenticatedMarketplaceUser(req, res);
  if (!actor) return;
  const parsed = ToggleFavoriteParams.safeParse(req.params);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }
  const [existing] = await db.select().from(savedListingsTable).where(and(eq(savedListingsTable.userId, actor.id), eq(savedListingsTable.listingId, parsed.data.id)));
  if (existing) {
    await db.delete(savedListingsTable).where(eq(savedListingsTable.id, existing.id));
    res.json(ToggleFavoriteResponse.parse({ saved: false }));
    return;
  }
  await db.insert(savedListingsTable).values({ userId: actor.id, listingId: parsed.data.id });
  res.json(ToggleFavoriteResponse.parse({ saved: true }));
});

router.get("/saved-listings", async (req, res): Promise<void> => {
  await ensureSeed();
  const actor = await authenticatedMarketplaceUser(req, res);
  if (!actor) return;
  const rows = await db.select({ listing: listingsTable, category: categoriesTable, seller: usersTable })
    .from(savedListingsTable)
    .innerJoin(listingsTable, eq(savedListingsTable.listingId, listingsTable.id))
    .innerJoin(categoriesTable, eq(listingsTable.categoryId, categoriesTable.id))
    .innerJoin(usersTable, eq(listingsTable.sellerId, usersTable.id))
    .where(and(eq(savedListingsTable.userId, actor.id), activeListingWhere()))
    .orderBy(desc(savedListingsTable.createdAt));
  res.json(ListSavedListingsResponse.parse(rows.map((row) => formatListing({ ...row, isSaved: true }))));
});

router.get("/messages", async (req, res): Promise<void> => {
  await ensureSeed();
  const actor = await authenticatedMarketplaceUser(req, res);
  if (!actor) return;
  const rows = await db.select({ message: messagesTable, listing: listingsTable, sender: usersTable })
    .from(messagesTable)
    .innerJoin(listingsTable, eq(messagesTable.listingId, listingsTable.id))
    .innerJoin(usersTable, eq(messagesTable.senderId, usersTable.id))
    .where(eq(messagesTable.recipientId, actor.id))
    .orderBy(desc(messagesTable.createdAt));
  res.json(ListMessagesResponse.parse(rows.map((row) => ({
    id: row.message.id,
    listingId: row.message.listingId,
    listingTitle: row.listing.title,
    senderName: row.sender.name,
    preview: row.message.body,
    createdAt: row.message.createdAt,
    unread: row.message.unread,
  }))));
});

router.post("/messages", async (req, res): Promise<void> => {
  await ensureSeed();
  const actor = await authenticatedMarketplaceUser(req, res);
  if (!actor) return;
  const parsed = SendMessageBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }
  const [listing] = await db.select().from(listingsTable).where(eq(listingsTable.id, parsed.data.listingId));
  if (!listing) {
    res.status(404).json({ error: "Listing not found" });
    return;
  }
  if (
    listing.status !== "active" ||
    (listing.expiresAt !== null && listing.expiresAt <= new Date())
  ) {
    res.status(404).json({ error: "Listing not found" });
    return;
  }
  const [message] = await db.insert(messagesTable).values({
    listingId: listing.id,
    senderId: actor.id,
    recipientId: listing.sellerId,
    body: parsed.data.body,
  }).returning();
  res.status(201).json(SendMessageResponse.parse({
    id: message.id,
    listingId: message.listingId,
    listingTitle: listing.title,
    senderName: actor.name,
    preview: message.body,
    createdAt: message.createdAt,
    unread: message.unread,
  }));
});

router.get("/dashboard/summary", async (req, res): Promise<void> => {
  await ensureSeed();
  const actor = await authenticatedMarketplaceUser(req, res);
  if (!actor) return;
  const [[listingCount], [userCount], [messageCount], [savedCount], categories, recentRows] = await Promise.all([
    db.select({ total: count() }).from(listingsTable).where(and(eq(listingsTable.sellerId, actor.id), activeListingWhere())),
    db.select({ total: count() }).from(usersTable).where(eq(usersTable.id, actor.id)),
    db.select({ total: count() }).from(messagesTable).where(or(eq(messagesTable.senderId, actor.id), eq(messagesTable.recipientId, actor.id))),
    db.select({ total: count() }).from(savedListingsTable).where(eq(savedListingsTable.userId, actor.id)),
    db.select({ category: categoriesTable.name, count: count(listingsTable.id) })
      .from(categoriesTable)
       .leftJoin(listingsTable, and(eq(categoriesTable.id, listingsTable.categoryId), eq(listingsTable.sellerId, actor.id), activeListingWhere()))
      .groupBy(categoriesTable.id)
      .orderBy(desc(count(listingsTable.id))),
    db.select({ listing: listingsTable, category: categoriesTable, seller: usersTable })
      .from(listingsTable)
      .innerJoin(categoriesTable, eq(listingsTable.categoryId, categoriesTable.id))
      .innerJoin(usersTable, eq(listingsTable.sellerId, usersTable.id))
       .where(and(eq(listingsTable.sellerId, actor.id), activeListingWhere()))
      .orderBy(desc(listingsTable.createdAt))
      .limit(5),
  ]);
  const response = {
    listingCount: Number(listingCount.total),
    userCount: Number(userCount.total),
    messageCount: Number(messageCount.total),
    savedCount: Number(savedCount.total),
    categoryCounts: categories.map((item) => ({ category: item.category, count: Number(item.count) })),
    recentListings: recentRows.map((row) => formatListing(row)),
  };
  res.json(GetDashboardSummaryResponse.parse(response));
});

export default router;