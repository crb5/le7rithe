import { Router, type IRouter } from "express";
import { getAuth } from "@clerk/express";
import healthRouter from "./health";
import marketplaceRouter from "./marketplace";
import adminRouter from "./admin";

const router: IRouter = Router();

router.use((req, res, next) => {
  const { userId } = getAuth(req);
  if (!userId) {
    res.status(401).json({ error: "Authentication required" });
    return;
  }
  next();
});

router.use(healthRouter);
router.use(adminRouter);
router.use(marketplaceRouter);

export default router;
