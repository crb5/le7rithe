import { useEffect, useMemo, useState } from 'react';
import { useUser } from '@clerk/react';
import { Link, useLocation, useParams } from 'wouter';
import {
  ArrowRight,
  BarChart3,
  Bookmark,
  CheckCircle2,
  ChevronDown,
  Clock3,
  Droplets,
  Edit3,
  FileText,
  Filter,
  Info,
  LandPlot,
  LoaderCircle,
  Mail,
  MapPin,
  MessageCircle,
  MoreHorizontal,
  Package,
  Phone,
  Plus,
  Send,
  Search,
  Settings,
  ShieldCheck,
  SlidersHorizontal,
  Sparkles,
  Star,
  Store,
  Trash2,
  Tractor,
  UserRound,
  Users,
  WalletCards,
  X,
} from 'lucide-react';
import {
  getGetDashboardSummaryQueryKey,
  getGetListingQueryKey,
  getListCategoriesQueryKey,
  getListAdminCategoriesQueryKey,
  getListSubcategoriesQueryKey,
  getListListingsQueryKey,
  getListLocationsQueryKey,
  getListMessagesQueryKey,
  getListSavedListingsQueryKey,
  useDeleteListing,
  useGetDashboardSummary,
  useGetListing,
  useListCategories,
  useListAdminCategories,
  useListSubcategories,
  useListListings,
  useListLocations,
  useListMessages,
  useListSavedListings,
  useSendMessage,
  useToggleFavorite,
  useUpdateListing,
  type Listing,
  type Category,
} from '@workspace/api-client-react';
import { useQueryClient } from '@tanstack/react-query';
import {
  AppShell,
  EmptyState,
  ErrorState,
  ListingCard,
  ListingSkeleton,
  PageHeading,
  SearchBar,
  SectionLink,
  StatCard,
  formatPrice,
  iconForCategory,
  relativeDate,
} from '@/components/marketplace-ui';
import { dynamicFiltersForCategory } from '@/lib/category-catalog';
import { translatedName, useLanguage } from '@/lib/language';
import { useToast } from '@/hooks/use-toast';
import { AddListing } from './add-listing';

const categoriesFallback = [
  { id: 1, name: 'الآليات الزراعية', nameFr: 'Machines agricoles', nameEn: 'Agricultural machinery', slug: 'tractors', icon: 'tractor', sortOrder: 1, active: true, count: 0, subcategories: [] },
  { id: 2, name: 'الأراضي الزراعية', nameFr: 'Terrains agricoles', nameEn: 'Agricultural land', slug: 'land', icon: 'land', sortOrder: 0, active: true, count: 0, subcategories: [] },
  { id: 3, name: 'البذور', nameFr: 'Semences', nameEn: 'Seeds', slug: 'seeds', icon: 'wheat', sortOrder: 2, active: true, count: 0, subcategories: [] },
  { id: 4, name: 'الأسمدة', nameFr: 'Engrais', nameEn: 'Fertilizers', slug: 'fertilizers', icon: 'flask', sortOrder: 3, active: true, count: 0, subcategories: [] },
  { id: 5, name: 'قطع الغيار', nameFr: 'Pièces détachées', nameEn: 'Spare parts', slug: 'parts', icon: 'wrench', sortOrder: 4, active: true, count: 0, subcategories: [] },
  { id: 6, name: 'المنتجات الزراعية', nameFr: 'Produits agricoles', nameEn: 'Agricultural products', slug: 'products', icon: 'basket', sortOrder: 5, active: true, count: 0, subcategories: [] },
  { id: 7, name: 'الموارد البشرية', nameFr: 'Ressources humaines', nameEn: 'Human resources', slug: 'services', icon: 'users', sortOrder: 6, active: true, count: 0, subcategories: [] },
];

function Home() {
  const [, setLocation] = useLocation();
  const { language, t, formatDate } = useLanguage();
  const [search, setSearch] = useState('');
  const categoriesQuery = useListCategories({ query: { queryKey: getListCategoriesQueryKey() } });
  const locationsQuery = useListLocations({ query: { queryKey: getListLocationsQueryKey() } });
  const listingsQuery = useListListings({ featured: true, sort: 'newest', limit: 8 });
  const latestQuery = useListListings({ featured: false, sort: 'newest', limit: 4 });
  const toggleFavorite = useToggleFavorite();
  const categories = categoriesQuery.data?.length ? categoriesQuery.data : categoriesFallback;
  const featured = listingsQuery.data?.items ?? [];
  const latest = latestQuery.data?.items ?? [];
  const submitSearch = () => setLocation(`/listings${search ? `?q=${encodeURIComponent(search)}` : ''}`);

  return <AppShell>
    <section className="animate-rise overflow-hidden rounded-[26px] bg-[hsl(var(--primary))] px-6 py-8 text-[hsl(var(--primary-foreground))] sm:px-10 sm:py-11 lg:px-14 lg:py-14">
      <div className="relative z-10 max-w-2xl">
        <div className="mb-5 inline-flex items-center gap-2 rounded-full border border-white/15 bg-white/[.07] px-3 py-1.5 text-[11px] font-semibold text-white/75"><Sparkles size={13} className="text-[hsl(var(--accent))]" />{t('seasonalMarket')}</div>
        <h1 className="max-w-xl text-[clamp(2rem,5vw,4.2rem)] font-bold leading-[1.13] tracking-tight">{t('everythingForYourLand')}</h1>
        <p className="mt-5 max-w-lg text-sm leading-7 text-white/60 sm:text-base">{t('homeIntro')}</p>
        <div className="mt-8 max-w-xl"><SearchBar value={search} onChange={setSearch} onSubmit={submitSearch} /></div>
        <div className="mt-4 flex flex-wrap gap-x-5 gap-y-2 text-[11px] text-white/45"><span>{t('mostSearched')}</span><button type="button" onClick={() => { setSearch('جرار'); setLocation('/listings?q=جرار'); }} className="text-white/75 hover:text-[hsl(var(--accent))]" data-testid="button-trend-tractor">{t('tractors')}</button><button type="button" onClick={() => { setSearch('أرض'); setLocation('/listings?q=أرض'); }} className="text-white/75 hover:text-[hsl(var(--accent))]" data-testid="button-trend-land">{t('agriculturalLand')}</button><button type="button" onClick={() => setLocation('/listings?category=spare-parts')} className="text-white/75 hover:text-[hsl(var(--accent))]" data-testid="button-trend-parts">{t('spareParts')}</button></div>
      </div>
      <div className="pointer-events-none absolute -left-8 -top-20 h-[420px] w-[420px] rounded-full border-[46px] border-[hsl(var(--accent)/.1)] sm:left-[45%] sm:top-[-150px]" /><div className="pointer-events-none absolute -bottom-36 left-[43%] h-[360px] w-[360px] rounded-full border-[1px] border-[hsl(var(--accent)/.2)]" />
      <div className="pointer-events-none absolute bottom-0 left-10 hidden opacity-40 lg:block"><LandPlot size={160} strokeWidth={.5} /></div>
    </section>

    <section className="animate-rise stagger-1 mt-10">
      <div className="mb-5 flex items-end justify-between"><div><span className="mb-2 block text-[10px] font-bold tracking-[.18em] text-[hsl(var(--muted-foreground))]">{t('browseByNeed')}</span><h2 className="text-xl font-bold text-[hsl(var(--primary))]">{t('whereToStart')}</h2></div><SectionLink href="/listings">{t('viewAllCategories')}</SectionLink></div>
      <div className="grid grid-cols-2 gap-3 sm:grid-cols-3 lg:grid-cols-5">
         {categories.map((category, index) => { const Icon = iconForCategory(category); return <Link key={category.id} href={`/listings?category=${category.slug}`} className={`group rounded-2xl border border-[hsl(var(--border))] bg-[hsl(var(--card))] p-4 transition-all hover:-translate-y-1 hover:border-[hsl(var(--accent))] hover:shadow-[0_10px_20px_hsl(155_20%_18%/.08)] ${index === 0 ? 'bg-[hsl(var(--secondary)/.65)]' : ''}`} data-testid={`link-category-${category.slug}`}><span className="mb-5 flex h-10 w-10 items-center justify-center rounded-xl bg-[hsl(var(--primary))] text-[hsl(var(--accent))] transition-transform group-hover:rotate-6"><Icon size={19} /></span><strong className="block text-sm text-[hsl(var(--primary))]">{translatedName(category, language)}</strong><span className="mt-1 block text-[11px] text-[hsl(var(--muted-foreground))]">{t('listingCount', { count: category.count || 0 })}</span></Link>; })}
      </div>
    </section>

    <section className="animate-rise stagger-2 mt-12 grid gap-8 lg:grid-cols-[1fr_280px]" data-testid="section-featured-listings">
      <div><div className="mb-5 flex items-end justify-between"><div><span className="mb-2 block text-[10px] font-bold tracking-[.18em] text-[hsl(var(--muted-foreground))]">{t('handpicked')}</span><h2 className="text-xl font-bold text-[hsl(var(--primary))]">{t('featuredListings')}</h2></div><SectionLink href="/listings?featured=true">{t('viewMore')}</SectionLink></div>{listingsQuery.isLoading ? <ListingSkeleton count={4} /> : listingsQuery.isError ? <ErrorState onRetry={() => listingsQuery.refetch()} /> : featured.length ? <div className="grid grid-cols-1 gap-5 sm:grid-cols-2 xl:grid-cols-4">{featured.slice(0, 4).map((listing) => <ListingCard key={listing.id} listing={listing} featured onSave={(item) => toggleFavorite.mutate({ id: item.id })} />)}</div> : <EmptyState title={t('noFeaturedListings')} description={t('noFeaturedListingsDescription')} />}</div>
      <aside className="rounded-2xl border border-[hsl(var(--border))] bg-[hsl(var(--secondary)/.45)] p-5"><div className="mb-6 flex items-center justify-between"><div><span className="mb-1 block text-[10px] font-bold tracking-[.14em] text-[hsl(var(--muted-foreground))]">{t('marketDistribution')}</span><h3 className="font-bold text-[hsl(var(--primary))]">{t('byRegion')}</h3></div><MapPin size={18} className="text-[hsl(var(--primary))]" /></div>{locationsQuery.isLoading ? <div className="space-y-4">{[1,2,3,4].map((i) => <div key={i} className="h-8 animate-pulse rounded bg-[hsl(var(--muted))]" />)}</div> : <div className="space-y-4">{(locationsQuery.data ?? []).slice(0, 5).map((location) => <Link key={location.id} href={`/listings?location=${encodeURIComponent(location.name)}`} className="group flex items-center justify-between text-xs" data-testid={`link-location-${location.id}`}><span className="flex items-center gap-2 font-semibold text-[hsl(var(--foreground))]"><span className="h-1.5 w-1.5 rounded-full bg-[hsl(var(--accent-foreground))] transition-transform group-hover:scale-150" />{location.name}</span><span className="font-numeric text-[10px] text-[hsl(var(--muted-foreground))]" dir="ltr">{location.listingCount}</span></Link>)}</div>}</aside>
    </section>

     <section className="mt-12 border-t border-[hsl(var(--border))] pt-9"><div className="mb-5 flex items-end justify-between"><div><span className="mb-2 block text-[10px] font-bold tracking-[.18em] text-[hsl(var(--muted-foreground))]">{t('newlyArrived')}</span><h2 className="text-xl font-bold text-[hsl(var(--primary))]">{t('marketPulse')}</h2></div><span className="text-[11px] text-[hsl(var(--muted-foreground))]">{formatDate(new Date(), { dateStyle: 'long' })}</span></div>{latestQuery.isLoading ? <ListingSkeleton count={4} /> : <div className="grid grid-cols-1 gap-5 sm:grid-cols-2 xl:grid-cols-4">{latest.map((listing) => <ListingCard key={listing.id} listing={listing} iconSize={24} onSave={(item) => toggleFavorite.mutate({ id: item.id })} />)}</div>}</section>
  </AppShell>;
}

function Listings() {
  const [, setLocation] = useLocation();
  const { language, t } = useLanguage();
  const queryParams = new URLSearchParams(window.location.search);
  const featuredOnly = queryParams.get('featured') === 'true';
  const [q, setQ] = useState(queryParams.get('q') ?? '');
  const [category, setCategory] = useState(queryParams.get('category') ?? '');
  const [subcategory, setSubcategory] = useState(queryParams.get('subcategory') ?? '');
  const [location, setFilterLocation] = useState(queryParams.get('location') ?? '');
  const [condition, setCondition] = useState('');
  const [sort, setSort] = useState('newest');
  const [dynamicValues, setDynamicValues] = useState<Record<string, string>>({});
  const [filtersOpen, setFiltersOpen] = useState(false);
  const categoriesQuery = useListCategories({ query: { queryKey: getListCategoriesQueryKey() } });
  const locationsQuery = useListLocations({ query: { queryKey: getListLocationsQueryKey() } });
  const categories = categoriesQuery.data ?? categoriesFallback;
  const selectedCategory = categories.find((item) => item.slug === category);
  const dynamicFilters = dynamicFiltersForCategory(category);
  const params = useMemo(() => ({ q: q || undefined, category: category || undefined, subcategory: subcategory || undefined, location: location || undefined, saleType: dynamicValues.saleType || undefined, reference: dynamicValues.reference || undefined, brand: dynamicValues.brand || undefined, productType: dynamicValues.productType || undefined, condition: (dynamicValues.condition || condition || undefined) as 'new' | 'used' | undefined, manufacturer: dynamicValues.manufacturer || undefined, model: dynamicValues.model || undefined, year: dynamicValues.year ? Number(dynamicValues.year) : undefined, sort: sort as 'newest' | 'price_asc' | 'price_desc', featured: featuredOnly ? true : undefined, page: 1, limit: 12 }), [q, category, subcategory, location, dynamicValues, condition, sort, featuredOnly]);
  const listingsQuery = useListListings(params, { query: { queryKey: getListListingsQueryKey(params) } });
  const toggleFavorite = useToggleFavorite();
  const clearFilters = () => { setQ(''); setCategory(''); setSubcategory(''); setFilterLocation(''); setCondition(''); setDynamicValues({}); setSort('newest'); setLocation('/listings'); };
  const items = listingsQuery.data?.items ?? [];
  const listingErrorMessage = import.meta.env.DEV && listingsQuery.error instanceof Error ? listingsQuery.error.message : undefined;
   return <AppShell><PageHeading eyebrow={t('openMarket')} title={featuredOnly ? t('featuredListings') : t('allListings')} description={t('browseListingsDescription')} action={<button type="button" onClick={() => setFiltersOpen(!filtersOpen)} className="flex items-center gap-2 rounded-xl border border-[hsl(var(--border))] bg-[hsl(var(--card))] px-4 py-2.5 text-xs font-bold text-[hsl(var(--primary))] lg:hidden" data-testid="button-toggle-filters"><SlidersHorizontal size={16} />{t('filters')}</button>} />
    <div className="mb-6"><SearchBar value={q} onChange={setQ} onSubmit={() => setLocation(`/listings${q ? `?q=${encodeURIComponent(q)}` : ''}`)} /></div>
    <div className="grid gap-7 lg:grid-cols-[238px_1fr]">
       <aside className={`${filtersOpen ? 'block' : 'hidden'} rounded-2xl border border-[hsl(var(--border))] bg-[hsl(var(--card))] p-5 lg:block`}><div className="mb-5 flex items-center justify-between"><h3 className="font-bold text-[hsl(var(--primary))]">{t('filterResults')}</h3><button type="button" onClick={clearFilters} className="text-[10px] font-bold text-[hsl(var(--muted-foreground))] hover:text-[hsl(var(--destructive))]" data-testid="button-clear-filters">{t('clearAll')}</button></div><FilterGroup title={t('mainCategory')}><select value={category} onChange={(e) => { setCategory(e.target.value); setSubcategory(''); setDynamicValues({}); }} className="filter-select" data-testid="select-category"><option value="">{t('allCategories')}</option>{categories.map((item) => <option key={item.id} value={item.slug}>{translatedName(item, language)}</option>)}</select></FilterGroup>{selectedCategory?.subcategories?.length ? <FilterGroup title={t('subcategory')}><select value={subcategory} onChange={(e) => setSubcategory(e.target.value)} className="filter-select" data-testid="select-subcategory"><option value="">{t('allSubcategories')}</option>{selectedCategory.subcategories.filter((item) => item.active).map((item) => <option key={item.id} value={item.slug}>{translatedName(item, language)}</option>)}</select></FilterGroup> : null}<FilterGroup title={t('location')}><select value={location} onChange={(e) => setFilterLocation(e.target.value)} className="filter-select" data-testid="select-location"><option value="">{t('allRegions')}</option>{(locationsQuery.data ?? []).map((item) => <option key={item.id} value={item.name}>{item.name}</option>)}</select></FilterGroup>{dynamicFilters.map((field) => <DynamicFilterControl key={field.key} field={field} value={dynamicValues[field.key] ?? ''} onChange={(value) => setDynamicValues((current) => ({ ...current, [field.key]: value }))} />)}{!dynamicFilters.some((field) => field.key === 'condition') && <FilterGroup title={t('condition')}><div className="space-y-2">{[['', t('all')], ['new', t('new')], ['used', t('used')]].map(([value, label]) => <label key={value} className="flex cursor-pointer items-center gap-2 text-xs text-[hsl(var(--foreground))]"><input type="radio" name="condition" value={value} checked={condition === value} onChange={() => setCondition(value)} className="accent-[hsl(var(--primary))]" data-testid={`radio-condition-${value || 'all'}`} />{label}</label>)}</div></FilterGroup>}</aside>
       <div><div className="mb-5 flex items-center justify-between"><p className="text-xs text-[hsl(var(--muted-foreground))]"><strong className="text-[hsl(var(--primary))]">{t('availableListings', { count: listingsQuery.data?.total ?? 0 })}</strong></p><select value={sort} onChange={(e) => setSort(e.target.value)} className="filter-select w-auto py-2" data-testid="select-sort"><option value="newest">{t('newestFirst')}</option><option value="price_asc">{t('lowestPrice')}</option><option value="price_desc">{t('highestPrice')}</option></select></div>{listingsQuery.isLoading ? <ListingSkeleton count={8} /> : listingsQuery.isError ? <ErrorState message={listingErrorMessage} onRetry={() => listingsQuery.refetch()} /> : items.length ? <div className="grid grid-cols-1 gap-5 sm:grid-cols-2 xl:grid-cols-3">{items.map((listing) => <ListingCard key={listing.id} listing={listing} onSave={(item) => toggleFavorite.mutate({ id: item.id })} />)}</div> : <EmptyState icon={featuredOnly ? Star : Search} title={featuredOnly ? t('noFeaturedListings') : t('noResults')} description={featuredOnly ? t('noFeaturedListingsDescription') : t('noResultsDescription')} action={<button type="button" onClick={clearFilters} className="rounded-xl bg-[hsl(var(--primary))] px-4 py-2.5 text-xs font-bold text-[hsl(var(--primary-foreground))]" data-testid="button-empty-clear">{t('showAllListings')}</button>} />}</div>
    </div>
  </AppShell>;
}

function FilterGroup({ title, children }: { title: string; children: React.ReactNode }) {
  return <div className="border-t border-[hsl(var(--border))] py-5 first:border-0 first:pt-0"><label className="mb-3 block text-xs font-bold text-[hsl(var(--primary))]">{title}</label>{children}</div>;
}

function DynamicFilterControl({ field, value, onChange }: { field: ReturnType<typeof dynamicFiltersForCategory>[number]; value: string; onChange: (value: string) => void }) {
  const { t } = useLanguage();
  const labelKeys: Record<string, keyof typeof import('@/locales/en').default> = { saleType: 'fieldSaleType', landCondition: 'fieldLandCondition', region: 'fieldRegion', reference: 'fieldReference', brand: 'fieldBrand', productType: 'fieldProductType', condition: 'condition', manufacturer: 'manufacturer', model: 'model', year: 'fieldYear' };
  const optionKeys: Record<string, keyof typeof import('@/locales/en').default> = { sale: 'forSale', rent: 'forRent', new: 'new', used: 'used', reclaimed: 'reclaimed', unreclaimed: 'unreclaimed', روصو: 'regionRosso', كرمسين: 'regionKermassene', اركيز: 'regionRkiz', انتيكان: 'regionMbagne', بوگي: 'regionBoghé', لكصيب: 'regionLexeiba', آخر: 'other' };
  const placeholderKeys: Record<string, keyof typeof import('@/locales/en').default> = { customRegion: 'fieldCustomRegion', ownershipType: 'fieldOwnershipType' };
  return <FilterGroup title={t(labelKeys[field.key] ?? 'fieldProductName')}>{field.type === 'select' ? <select value={value} onChange={(event) => onChange(event.target.value)} className="filter-select"><option value="">{t('all')}</option>{field.options?.map((option) => <option key={option.value} value={option.value}>{optionKeys[option.value] ? t(optionKeys[option.value]) : option.label}</option>)}</select> : <input type={field.type} value={value} onChange={(event) => onChange(event.target.value)} placeholder={placeholderKeys[field.key] ? t(placeholderKeys[field.key]) : undefined} className="field-input" />}</FilterGroup>;
}

 function ListingDetail() {
  const { language, t, formatDate } = useLanguage();
  const params = useParams<{ id: string }>();
  const id = Number(params.id);
  const [, setLocation] = useLocation();
  const queryClient = useQueryClient();
  const listingQuery = useGetListing(id, { query: { queryKey: getGetListingQueryKey(id), enabled: Number.isFinite(id) } });
  const toggleFavorite = useToggleFavorite();
  const sendMessage = useSendMessage();
  const [message, setMessage] = useState('');
  const [activeImage, setActiveImage] = useState(0);
  const listing = listingQuery.data;
  if (listingQuery.isLoading) return <AppShell><div className="space-y-6"><div className="h-8 w-1/3 animate-pulse rounded bg-[hsl(var(--muted))]" /><div className="h-[420px] animate-pulse rounded-3xl bg-[hsl(var(--muted))]" /></div></AppShell>;
  if (listingQuery.isError || !listing) return <AppShell><ErrorState onRetry={() => listingQuery.refetch()} message={t('listingUnavailable')} /></AppShell>;
  const gallery = listing.images?.length ? listing.images : [listing.imageUrl];
  const submitMessage = () => { if (!message.trim()) return; sendMessage.mutate({ data: { listingId: listing.id, body: message.trim() } }, { onSuccess: () => { setMessage(''); queryClient.invalidateQueries({ queryKey: getListMessagesQueryKey() }); } }); };
  return <AppShell><div className="mb-6 flex items-center gap-2 text-xs text-[hsl(var(--muted-foreground))]"><Link href="/listings" className="hover:text-[hsl(var(--primary))]" data-testid="link-back-listings">{t('allListings')}</Link><ChevronDown size={13} className="rotate-90" /><span>{listing.category}</span></div><div className="grid gap-8 xl:grid-cols-[minmax(0,1fr)_370px]"><div><div className="overflow-hidden rounded-3xl bg-[hsl(var(--primary))]"><div className="relative aspect-[1.65] sm:aspect-[1.9]">{gallery[activeImage] ? <img src={gallery[activeImage]} alt={listing.title} className="h-full w-full object-cover" data-testid="img-detail-main" /> : <div className="flex h-full items-center justify-center text-[hsl(var(--accent))]"><Tractor size={100} strokeWidth={.7} /></div>}<span className="absolute right-4 top-4 rounded-lg bg-[hsl(var(--accent))] px-3 py-1.5 text-[11px] font-bold text-[hsl(var(--primary))]">{listing.condition === 'new' ? t('new') : t('used')}</span></div>{gallery.length > 1 && <div className="flex gap-2 overflow-x-auto p-3">{gallery.map((image, index) => <button type="button" key={image + index} onClick={() => setActiveImage(index)} className={`h-16 w-20 shrink-0 overflow-hidden rounded-lg border-2 ${activeImage === index ? 'border-[hsl(var(--accent))]' : 'border-white/10'}`} data-testid={`button-gallery-${index}`}><img src={image} alt="" className="h-full w-full object-cover" /></button>)}</div>}</div><div className="mt-7"><div className="flex items-start justify-between gap-4"><div><span className="mb-2 block text-xs text-[hsl(var(--muted-foreground))]">{listing.category} · {relativeDate(listing.createdAt, language)}</span><h1 className="text-2xl font-bold leading-9 text-[hsl(var(--primary))] sm:text-3xl">{listing.title}</h1></div><button type="button" onClick={() => toggleFavorite.mutate({ id: listing.id }, { onSuccess: (result) => queryClient.setQueryData(getGetListingQueryKey(id), (old: Listing | undefined) => old ? { ...old, isSaved: result.saved } : old) })} className="rounded-xl border border-[hsl(var(--border))] p-3 text-[hsl(var(--primary))] hover:bg-[hsl(var(--secondary))]" aria-label={t('saveListing')} data-testid="button-detail-save"><Bookmark size={20} fill={listing.isSaved ? 'currentColor' : 'none'} /></button></div><p className="mt-5 whitespace-pre-line text-sm leading-8 text-[hsl(var(--muted-foreground))]">{listing.description}</p></div></div><aside className="space-y-4"><div className="rounded-2xl border border-[hsl(var(--border))] bg-[hsl(var(--card))] p-5"><span className="text-[11px] text-[hsl(var(--muted-foreground))]">{t('requestedPrice')}</span><strong className="mt-1 block font-numeric text-2xl font-extrabold text-[hsl(var(--primary))]" dir="ltr">{formatPrice(listing.price, listing.currency, language)}</strong><div className="mt-3 rounded-xl bg-[hsl(var(--secondary)/.5)] p-3 text-xs"><span className="block text-[hsl(var(--muted-foreground))]">{t('listingExpiresAt')}</span><strong className="mt-1 block" dir="ltr">{listing.expiresAt ? formatDate(listing.expiresAt, { dateStyle: 'medium', timeStyle: 'short' }) : t('notAvailable')}</strong></div><div className="mt-5 border-t border-[hsl(var(--border))] pt-4"><h3 className="mb-3 text-xs font-bold text-[hsl(var(--primary))]">{t('sellerContactInfo')}</h3><div className="flex items-center gap-3"><span className="flex h-10 w-10 items-center justify-center rounded-full bg-[hsl(var(--accent))] text-xs font-bold text-[hsl(var(--primary))]">{listing.seller.initials}</span><div className="min-w-0 flex-1"><strong className="block text-sm">{listing.seller.name}</strong><span className="flex items-center gap-1 text-[10px] text-[hsl(var(--muted-foreground))]">{listing.seller.verified && <CheckCircle2 size={12} className="text-[hsl(var(--primary))]"/>} {t('verifiedSeller')}</span></div></div>{listing.contactPhone && <a href={`tel:${listing.contactPhone}`} className="mt-4 flex items-center justify-center gap-2 rounded-xl bg-[hsl(var(--primary))] py-3 text-xs font-bold text-[hsl(var(--primary-foreground))]" data-testid="link-call-seller"><Phone size={16} />{t('callSeller')} <span dir="ltr">{listing.contactPhone}</span></a>}</div><div className="mt-3 rounded-xl border border-[hsl(var(--border))] p-3"><div className="mb-2 flex items-center gap-2 text-xs font-bold"><MessageCircle size={15} />{t('sendInquiry')}</div><textarea value={message} onChange={(e) => setMessage(e.target.value)} placeholder={t('messagePlaceholder')} className="min-h-[78px] w-full resize-none bg-transparent text-xs leading-6 outline-none placeholder:text-[hsl(var(--muted-foreground))]" data-testid="textarea-message" /><button type="button" onClick={submitMessage} disabled={sendMessage.isPending || !message.trim()} className="flex w-full items-center justify-center gap-2 rounded-lg bg-[hsl(var(--accent))] py-2.5 text-xs font-bold text-[hsl(var(--primary))] disabled:cursor-not-allowed disabled:opacity-50" data-testid="button-send-message">{sendMessage.isPending ? <LoaderCircle size={15} className="animate-spin" /> : <Send size={15} />}{t('sendMessage')}</button></div></div><div className="rounded-2xl border border-[hsl(var(--border))] bg-[hsl(var(--secondary)/.35)] p-5"><div className="flex gap-3"><ShieldCheck size={18} className="shrink-0 text-[hsl(var(--primary))]" /><p className="text-[11px] leading-6 text-[hsl(var(--muted-foreground))]}">{t('safeCommunication')}</p></div></div></aside></div></AppShell>;
}

function Saved() {
  const { t } = useLanguage();
  const queryClient = useQueryClient();
  const savedQuery = useListSavedListings({ query: { queryKey: getListSavedListingsQueryKey() } });
  const toggleFavorite = useToggleFavorite();
  const remove = (listing: Listing) => toggleFavorite.mutate({ id: listing.id }, { onSuccess: () => queryClient.invalidateQueries({ queryKey: getListSavedListingsQueryKey() }) });
  return <AppShell><PageHeading eyebrow={t('savedArea')} title={t('saved')} description={t('savedDescription')} />{savedQuery.isLoading ? <ListingSkeleton count={4} /> : savedQuery.isError ? <ErrorState onRetry={() => savedQuery.refetch()} /> : savedQuery.data?.length ? <div className="grid grid-cols-1 gap-5 sm:grid-cols-2 xl:grid-cols-4">{savedQuery.data.map((listing) => <ListingCard key={listing.id} listing={{ ...listing, isSaved: true }} onSave={remove} />)}</div> : <EmptyState icon={Bookmark} title={t('savedEmpty')} description={t('savedEmptyDescription')} action={<Link href="/listings" className="inline-flex items-center gap-2 rounded-xl bg-[hsl(var(--primary))] px-4 py-2.5 text-xs font-bold text-[hsl(var(--primary-foreground))]" data-testid="link-empty-saved">{t('browseListings')} <ArrowRight size={15} /></Link>} />}</AppShell>;
}

function Messages() {
  const { language, t } = useLanguage();
  const messagesQuery = useListMessages({ query: { queryKey: getListMessagesQueryKey() } });
  const [selected, setSelected] = useState<number | null>(null);
  const messages = messagesQuery.data ?? [];
  const active = messages.find((item) => item.id === selected) ?? messages[0];
  return <AppShell><PageHeading eyebrow={t('directContact')} title={t('messages')} description={t('messagesDescription')} />{messagesQuery.isLoading ? <div className="grid gap-4 lg:grid-cols-[330px_1fr]"><div className="h-[520px] animate-pulse rounded-2xl bg-[hsl(var(--muted))]" /><div className="hidden h-[520px] animate-pulse rounded-2xl bg-[hsl(var(--muted))] lg:block" /></div> : messagesQuery.isError ? <ErrorState onRetry={() => messagesQuery.refetch()} /> : messages.length ? <div className="grid overflow-hidden rounded-2xl border border-[hsl(var(--border))] bg-[hsl(var(--card))] lg:grid-cols-[330px_1fr]"><div className="border-l border-[hsl(var(--border))]"><div className="border-b border-[hsl(var(--border))] p-4"><div className="relative"><SearchIcon /><input placeholder={t('searchConversations')} className="w-full rounded-xl bg-[hsl(var(--secondary))] py-2.5 pl-3 pr-9 text-xs outline-none" data-testid="input-message-search" /></div></div><div>{messages.map((message) => <button type="button" key={message.id} onClick={() => setSelected(message.id)} className={`w-full border-b border-[hsl(var(--border))] p-4 text-right transition-colors hover:bg-[hsl(var(--secondary)/.5)] ${active?.id === message.id ? 'bg-[hsl(var(--secondary)/.8)]' : ''}`} data-testid={`button-message-${message.id}`}><div className="flex items-start gap-3"><span className="flex h-9 w-9 shrink-0 items-center justify-center rounded-full bg-[hsl(var(--accent))] text-xs font-bold text-[hsl(var(--primary))]">{message.senderName.slice(0, 1)}</span><span className="min-w-0 flex-1"><span className="flex items-center justify-between gap-2"><strong className="truncate text-xs">{message.senderName}</strong><small className="text-[10px] text-[hsl(var(--muted-foreground))]">{relativeDate(message.createdAt, language)}</small></span><span className="mt-1 block truncate text-[11px] text-[hsl(var(--muted-foreground))]">{message.listingTitle}</span><span className="mt-1 block truncate text-[11px]">{message.preview}</span></span>{message.unread && <span className="mt-1 h-2 w-2 rounded-full bg-[hsl(var(--accent-foreground))]" />}</div></button>)}</div></div><div className="hidden min-h-[520px] flex-col lg:flex">{active ? <><div className="border-b border-[hsl(var(--border))] p-5"><span className="text-[10px] text-[hsl(var(--muted-foreground))]">{t('aboutListing')}</span><h2 className="mt-1 font-bold text-[hsl(var(--primary))]">{active.listingTitle}</h2></div><div className="flex flex-1 flex-col justify-end bg-[hsl(var(--background)/.5)] p-6"><div className="max-w-sm self-start rounded-2xl rounded-tr-sm bg-[hsl(var(--secondary))] p-4 text-sm leading-7">{active.preview}<span className="mt-2 block text-[10px] text-[hsl(var(--muted-foreground))]">{relativeDate(active.createdAt, language)}</span></div></div><div className="border-t border-[hsl(var(--border))] p-4"><div className="flex items-center gap-2 rounded-xl border border-[hsl(var(--border))] p-2"><input placeholder={t('replyPlaceholder')} className="flex-1 bg-transparent px-2 text-xs outline-none" data-testid="input-message-reply" /><button type="button" className="rounded-lg bg-[hsl(var(--primary))] p-2 text-[hsl(var(--primary-foreground))]" aria-label={t('sendReply')} data-testid="button-message-reply"><Send size={15} /></button></div></div></> : <EmptyState icon={Mail} title={t('selectConversation')} description={t('selectConversationDescription')} />}</div></div> : <EmptyState icon={Mail} title={t('noMessages')} description={t('noMessagesDescription')} action={<Link href="/listings" className="inline-flex rounded-xl bg-[hsl(var(--primary))] px-4 py-2.5 text-xs font-bold text-[hsl(var(--primary-foreground))]" data-testid="link-empty-messages">{t('browseListings')}</Link>} />}</AppShell>;
}

function SearchIcon() { return <span className="pointer-events-none absolute right-3 top-2.5 text-[hsl(var(--muted-foreground))]"><Filter size={14} /></span>; }

function Dashboard() {
  const { language, t, formatDate } = useLanguage();
  const queryClient = useQueryClient();
  const summaryQuery = useGetDashboardSummary({ query: { queryKey: getGetDashboardSummaryQueryKey() } });
  const deleteListing = useDeleteListing();
  const updateListing = useUpdateListing();
  const [editing, setEditing] = useState<Listing | null>(null);
  const summary = summaryQuery.data;
  const confirmDelete = (listing: Listing) => { if (window.confirm(t('deleteListingConfirm', { title: listing.title }))) deleteListing.mutate({ id: listing.id }, { onSuccess: () => queryClient.invalidateQueries({ queryKey: getGetDashboardSummaryQueryKey() }) }); };
   return <AppShell><PageHeading eyebrow={t('sellerSpace')} title={t('dashboardTitle')} description={t('dashboardDescription')} action={<Link href="/add-listing" className="inline-flex items-center gap-2 rounded-xl bg-[hsl(var(--primary))] px-4 py-2.5 text-xs font-bold text-[hsl(var(--primary-foreground))]" data-testid="link-dashboard-add"><Plus size={16} />{t('newListing')}</Link>} />{summaryQuery.isLoading ? <div className="grid grid-cols-2 gap-4 lg:grid-cols-4">{[1,2,3,4].map((i) => <div key={i} className="h-36 animate-pulse rounded-2xl bg-[hsl(var(--muted))]" />)}</div> : summaryQuery.isError || !summary ? <ErrorState onRetry={() => summaryQuery.refetch()} /> : <><div className="grid grid-cols-2 gap-4 lg:grid-cols-4"><StatCard label={t('activeListings')} value={summary.listingCount} icon={Store} accent /><StatCard label={t('newMessages')} value={summary.messageCount} icon={MessageCircle} /><StatCard label={t('saved')} value={summary.savedCount} icon={Bookmark} /><StatCard label={t('marketMembers')} value={summary.userCount} icon={Users} /></div><div className="mt-7 grid gap-7 xl:grid-cols-[1fr_330px]"><section className="rounded-2xl border border-[hsl(var(--border))] bg-[hsl(var(--card))]"><div className="flex items-center justify-between border-b border-[hsl(var(--border))] p-5"><div><h2 className="font-bold text-[hsl(var(--primary))]">{t('recentListings')}</h2><p className="mt-1 text-[11px] text-[hsl(var(--muted-foreground))]">{t('recentListingsDescription')}</p></div><MoreHorizontal size={18} className="text-[hsl(var(--muted-foreground))]" /></div><div>{summary.recentListings?.length ? summary.recentListings.map((listing) => <div key={listing.id} className="flex items-center gap-3 border-b border-[hsl(var(--border))] p-4 last:border-0"><div className="h-14 w-16 shrink-0 overflow-hidden rounded-lg bg-[hsl(var(--secondary))]">{listing.imageUrl ? <img src={listing.imageUrl} alt="" className="h-full w-full object-cover" /> : <div className="flex h-full items-center justify-center text-[hsl(var(--primary))]"><Tractor size={22} /></div>}</div><div className="min-w-0 flex-1"><h3 className="truncate text-xs font-bold">{listing.title}</h3><p className="mt-1 text-[10px] text-[hsl(var(--muted-foreground))]">{formatPrice(listing.price, listing.currency, language)} · {relativeDate(listing.createdAt, language)}{listing.expiresAt ? <> · {t('listingExpiresAtShort')}: <span dir="ltr">{formatDate(listing.expiresAt, { dateStyle: 'medium', timeStyle: 'short' })}</span></> : null}</p></div><div className="flex gap-1"><button type="button" onClick={() => setEditing(listing)} className="rounded-lg p-2 text-[hsl(var(--muted-foreground))] hover:bg-[hsl(var(--secondary))] hover:text-[hsl(var(--primary))]" aria-label={t('editListing')} data-testid={`button-edit-listing-${listing.id}`}><Edit3 size={15} /></button><button type="button" onClick={() => confirmDelete(listing)} className="rounded-lg p-2 text-[hsl(var(--muted-foreground))] hover:bg-[hsl(var(--destructive)/.08)] hover:text-[hsl(var(--destructive))]" aria-label={t('deleteListing')} data-testid={`button-delete-listing-${listing.id}`}><Trash2 size={15} /></button></div></div>) : <div className="p-8"><EmptyState title={t('noListingsYet')} description={t('noListingsYetDescription')} /></div>}</div></section><section className="rounded-2xl border border-[hsl(var(--border))] bg-[hsl(var(--card))] p-5"><div className="mb-6 flex items-center justify-between"><div><h2 className="font-bold text-[hsl(var(--primary))]">{t('categoryDistribution')}</h2><p className="mt-1 text-[11px] text-[hsl(var(--muted-foreground))]">{t('categoryDistributionDescription')}</p></div><BarChart3 size={18} className="text-[hsl(var(--primary))]" /></div><div className="space-y-5">{summary.categoryCounts?.map((item, index) => <div key={item.category}><div className="mb-2 flex justify-between text-xs"><span>{item.category}</span><strong className="font-numeric" dir="ltr">{item.count}</strong></div><div className="h-2 overflow-hidden rounded-full bg-[hsl(var(--muted))]"><div className={`h-full rounded-full ${index === 0 ? 'bg-[hsl(var(--primary))]' : index === 1 ? 'bg-[hsl(var(--accent-foreground))]' : 'bg-[hsl(var(--chart-4))]'}`} style={{ width: `${Math.min(100, Math.max(8, item.count / Math.max(1, summary.listingCount) * 100))}%` }} /></div></div>)}</div></section></div></>}{editing && <EditListingDialog listing={editing} onClose={() => setEditing(null)} onSaved={() => { setEditing(null); queryClient.invalidateQueries({ queryKey: getGetDashboardSummaryQueryKey() }); }} mutation={updateListing} />}</AppShell>;
}

function EditListingDialog({ listing, onClose, onSaved, mutation }: { listing: Listing; onClose: () => void; onSaved: () => void; mutation: ReturnType<typeof useUpdateListing> }) {
  const { t } = useLanguage();
  const [title, setTitle] = useState(listing.title);
  const [price, setPrice] = useState(String(listing.price));
  const [contactPhone, setContactPhone] = useState(listing.contactPhone ?? '');
  const initialContactPhone = listing.contactPhone?.trim() ?? '';
  const submit = () => {
    const nextContactPhone = contactPhone.trim();
    mutation.mutate({
      id: listing.id,
      data: {
        title, price: Number(price), category: listing.categorySlug, subcategory: listing.subcategorySlug ?? null,
        currency: listing.currency as 'MRU' | 'USD' | 'EUR', location: listing.location, condition: listing.condition,
        year: listing.year, manufacturer: listing.manufacturer, model: listing.model, hours: listing.hours, area: listing.area,
        waterAvailable: listing.waterAvailable, electricityAvailable: listing.electricityAvailable, ownershipType: listing.ownershipType,
        attributes: listing.attributes, description: listing.description || title,
        ...(nextContactPhone !== initialContactPhone ? { contactPhone: nextContactPhone } : {}),
        expiresAt: listing.expiresAt ?? new Date(Date.now() + 30 * 24 * 60 * 60 * 1000).toISOString(),
        imageUrl: listing.imageUrl, images: listing.images,
      },
    }, { onSuccess: onSaved });
  };
  const contactPhoneChanged = contactPhone.trim() !== initialContactPhone;
  return <div className="fixed inset-0 z-50 flex items-center justify-center bg-[hsl(var(--primary)/.45)] p-4 backdrop-blur-sm"><div className="w-full max-w-md rounded-2xl bg-[hsl(var(--card))] p-6 shadow-2xl"><div className="mb-5 flex items-center justify-between"><h2 className="font-bold text-[hsl(var(--primary))]">{t('editListing')}</h2><button type="button" onClick={onClose} className="rounded-lg p-2 hover:bg-[hsl(var(--secondary))]" aria-label={t('close')} data-testid="button-close-edit"><X size={18} /></button></div><div className="space-y-4"><label className="field-label">{t('listingTitle')}<input value={title} onChange={(e) => setTitle(e.target.value)} className="field-input" data-testid="input-edit-title" /></label><label className="field-label">{t('price')}<input type="number" value={price} onChange={(e) => setPrice(e.target.value)} className="field-input" data-testid="input-edit-price" /></label><label className="field-label">{t('listingContactPhone')}<input minLength={5} value={contactPhone} onChange={(e) => setContactPhone(e.target.value)} type="tel" dir="ltr" className="field-input text-right" autoComplete="tel" data-testid="input-edit-contact-phone" /></label></div><button type="button" onClick={submit} disabled={mutation.isPending || (contactPhoneChanged && contactPhone.trim().length < 5)} className="mt-6 flex w-full items-center justify-center gap-2 rounded-xl bg-[hsl(var(--primary))] py-3 text-xs font-bold text-[hsl(var(--primary-foreground))]" data-testid="button-save-edit">{mutation.isPending && <LoaderCircle size={15} className="animate-spin" />}{mutation.isPending ? t('saving') : t('saveChanges')}</button></div></div>;
}

type PendingPhoneVerification = {
  attemptVerification: (params: { code: string }) => Promise<unknown>;
};

function Account() {
  const { user } = useUser();
  const { t } = useLanguage();
  const { toast } = useToast();
  const [firstName, setFirstName] = useState('');
  const [lastName, setLastName] = useState('');
  const [phone, setPhone] = useState('');
  const [verificationCode, setVerificationCode] = useState('');
  const [pendingPhone, setPendingPhone] = useState<PendingPhoneVerification | null>(null);
  const [isSaving, setIsSaving] = useState(false);

  const currentPhone = user?.primaryPhoneNumber?.phoneNumber || '';
  const email = user?.primaryEmailAddress?.emailAddress || '';

  useEffect(() => {
    if (!user) return;
    setFirstName(user.firstName || (typeof user.unsafeMetadata?.firstName === 'string' ? user.unsafeMetadata.firstName : ''));
    setLastName(user.lastName || (typeof user.unsafeMetadata?.lastName === 'string' ? user.unsafeMetadata.lastName : ''));
    setPhone(currentPhone);
  }, [currentPhone, user]);

  const displayName = `${firstName} ${lastName}`.trim() || user?.fullName || t('user');

  const saveChanges = async (event: React.FormEvent) => {
    event.preventDefault();
    if (!user) return;
    if (!firstName.trim() || !lastName.trim()) {
      toast({ title: t('accountUpdateError'), description: t('signUpNameRequired'), variant: 'destructive' });
      return;
    }
    if (!pendingPhone && phone.trim() !== currentPhone && !phone.trim()) {
      toast({ title: t('accountUpdateError'), description: t('phoneRequired'), variant: 'destructive' });
      return;
    }
    setIsSaving(true);
    try {
      await user.update({ firstName: firstName.trim(), lastName: lastName.trim() });
      if (pendingPhone) {
        if (!verificationCode.trim()) {
          toast({ title: t('phoneVerification'), description: t('verificationCodeRequired'), variant: 'destructive' });
          return;
        }
        await pendingPhone.attemptVerification({ code: verificationCode.trim() });
        await user.reload();
        setPendingPhone(null);
        setVerificationCode('');
        setPhone(user.primaryPhoneNumber?.phoneNumber || phone);
        toast({ title: t('accountUpdated'), description: t('phoneVerified') });
        return;
      }
      if (phone.trim() !== currentPhone) {
        const createdPhone = await user.createPhoneNumber({ phoneNumber: phone.trim() });
        await createdPhone.prepareVerification();
        setPendingPhone(createdPhone);
        toast({ title: t('phoneVerification'), description: t('phoneVerificationSent') });
        return;
      }
      await user.reload();
      toast({ title: t('accountUpdated'), description: t('accountUpdatedDescription') });
    } catch (caught) {
      toast({
        title: t('accountUpdateError'),
        description: caught instanceof Error ? caught.message : t('tryAgain'),
        variant: 'destructive',
      });
    } finally {
      setIsSaving(false);
    }
  };

  return <AppShell>
    <PageHeading eyebrow={t('accountProfile')} title={t('account')} description={t('accountDescription')} />
    <div className="grid gap-7 lg:grid-cols-[320px_1fr]">
      <section className="rounded-2xl border border-[hsl(var(--border))] bg-[hsl(var(--primary))] p-6 text-[hsl(var(--primary-foreground))]">
        <div className="flex h-16 w-16 items-center justify-center rounded-full bg-[hsl(var(--accent))] text-xl font-bold text-[hsl(var(--primary))]">{displayName.charAt(0)}</div>
        <h2 className="mt-5 text-xl font-bold">{displayName}</h2>
        <p className="mt-1 text-xs text-white/55">{email}</p>
        <div className="mt-7 flex items-center gap-2 text-xs text-white/65"><CheckCircle2 size={16} className="text-[hsl(var(--accent))]" />{t('clerkSession')}</div>
      </section>
      <form onSubmit={saveChanges} className="space-y-4 rounded-2xl border border-[hsl(var(--border))] bg-[hsl(var(--card))] p-6">
        <div className="flex items-center gap-3 border-b border-[hsl(var(--border))] pb-5"><UserRound size={18} className="text-[hsl(var(--primary))]" /><div><h3 className="text-sm font-bold">{t('personalInformation')}</h3><p className="mt-1 text-[11px] text-[hsl(var(--muted-foreground))]">{t('personalInformationHelp')}</p></div></div>
        <div className="grid gap-4 sm:grid-cols-2">
          <label className="field-label">{t('firstName')}<input value={firstName} onChange={(event) => setFirstName(event.target.value)} required className="field-input" autoComplete="given-name" data-testid="input-account-first-name" /></label>
          <label className="field-label">{t('lastName')}<input value={lastName} onChange={(event) => setLastName(event.target.value)} required className="field-input" autoComplete="family-name" data-testid="input-account-last-name" /></label>
          <label className="field-label">{t('phoneNumber')}<input value={phone} onChange={(event) => setPhone(event.target.value)} type="tel" dir="ltr" className="field-input text-right" autoComplete="tel" placeholder="+222..." data-testid="input-account-phone" /></label>
          <label className="field-label">{t('email')}<input value={email} readOnly dir="ltr" className="field-input cursor-not-allowed bg-[hsl(var(--muted)/.45)] text-right" data-testid="input-account-email" /></label>
        </div>
        {pendingPhone && <label className="field-label rounded-xl border border-[hsl(var(--accent)/.5)] bg-[hsl(var(--accent)/.1)] p-4">{t('verificationCode')}<span className="mt-1 block text-[11px] font-normal text-[hsl(var(--muted-foreground))]">{t('phoneVerificationSent')}</span><input value={verificationCode} onChange={(event) => setVerificationCode(event.target.value)} required inputMode="numeric" autoComplete="one-time-code" className="field-input mt-3" dir="ltr" data-testid="input-account-phone-code" /></label>}
        <div className="flex justify-end border-t border-[hsl(var(--border))] pt-5"><button type="submit" disabled={isSaving} className="flex items-center gap-2 rounded-xl bg-[hsl(var(--primary))] px-5 py-3 text-xs font-bold text-[hsl(var(--primary-foreground))] disabled:cursor-not-allowed disabled:opacity-60" data-testid="button-save-account">{isSaving && <LoaderCircle size={15} className="animate-spin" />}{isSaving ? t('saving') : pendingPhone ? t('verifyAndContinue') : t('saveChanges')}</button></div>
      </form>
    </div>
  </AppShell>;
}

export { Home, Listings, ListingDetail, Saved, Messages, Dashboard, Account, AddListing };
