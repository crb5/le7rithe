import { useQuery, useQueryClient } from '@tanstack/react-query';
import { Bell, CheckCircle2, Clock3, XCircle } from 'lucide-react';
import { AppShell, EmptyState, PageHeading } from '@/components/marketplace-ui';
import { useLanguage } from '@/lib/language';

type NotificationItem = { id: number; title: string; body: string; type: string; read: boolean; createdAt: string };

export function Notifications() {
  const { t, meta, language } = useLanguage();
  const queryClient = useQueryClient();
  const query = useQuery<{ items: NotificationItem[] }>({
    queryKey: ['notifications'],
    queryFn: async () => {
      const response = await fetch('/api/notifications', { credentials: 'same-origin' });
      if (!response.ok) throw new Error(t('dataLoadError'));
      return response.json();
    },
  });
  const markRead = async (id: number) => {
    await fetch(`/api/notifications/${id}/read`, { method: 'PATCH', credentials: 'same-origin' });
    queryClient.invalidateQueries({ queryKey: ['notifications'] });
  };
  const Icon = (type: string) => type === 'payment_status' ? CheckCircle2 : type === 'payment_pending' ? Clock3 : Bell;
  return <AppShell><div dir={meta[language].dir} className="mx-auto max-w-4xl">
    <PageHeading eyebrow={t('notifications')} title={t('notifications')} description={t('notificationsDescription')} />
    {query.isLoading ? <div className="py-16 text-center text-sm">{t('loading')}</div> : !query.data?.items.length ? <EmptyState icon={Bell} title={t('noNotifications')} description={t('noNotificationsDescription')} /> : <div className="space-y-3">{query.data.items.map((item) => { const NotificationIcon = Icon(item.type); return <article key={item.id} className={`flex items-start gap-4 rounded-2xl border p-4 ${item.read ? 'border-[hsl(var(--border))] bg-[hsl(var(--card))]' : 'border-[hsl(var(--accent)/.55)] bg-[hsl(var(--accent)/.08)]'}`}><span className="mt-0.5 rounded-xl bg-[hsl(var(--secondary))] p-2 text-[hsl(var(--primary))]"><NotificationIcon size={18} /></span><div className="min-w-0 flex-1"><h2 className="font-bold text-[hsl(var(--primary))]">{item.title}</h2><p className="mt-1 text-sm leading-6 text-[hsl(var(--muted-foreground))]">{item.body}</p><time className="mt-2 block text-[11px] text-[hsl(var(--muted-foreground))]">{new Intl.DateTimeFormat(language === 'ar' ? 'ar-MR' : language === 'fr' ? 'fr-MR' : 'en-MR', { dateStyle: 'medium', timeStyle: 'short' }).format(new Date(item.createdAt))}</time></div>{!item.read && <button type="button" onClick={() => markRead(item.id)} className="shrink-0 rounded-lg px-2 py-1 text-[11px] font-bold text-[hsl(var(--primary))] hover:bg-[hsl(var(--secondary))]">{t('markAsRead')}</button>}</article>; })}</div>}
  </div></AppShell>;
}