import { useState, type FormEvent } from 'react';
import { LoaderCircle, ShieldCheck } from 'lucide-react';
import {
  getListCategoriesQueryKey,
  getListLocationsQueryKey,
  useCreateListing,
  useListCategories,
  useListLocations,
  type ListingInput,
} from '@workspace/api-client-react';
import { useLocation } from 'wouter';
import { AppShell, PageHeading } from '@/components/marketplace-ui';
import { dynamicFieldsForCategory, regions } from '@/lib/category-catalog';
import { translatedName, useLanguage } from '@/lib/language';
import { PaymentConfirmationPanel } from '@/components/payment-confirmation-panel';
import { ListingImageUploader } from '@/components/listing-image-uploader';

const toDateTimeLocal = (date: Date) => {
  const offset = date.getTimezoneOffset();
  return new Date(date.getTime() - offset * 60 * 1000).toISOString().slice(0, 16);
};

const categoriesFallback = [
  { id: 1, name: 'الآليات الزراعية', nameFr: 'Machines agricoles', nameEn: 'Agricultural machinery', slug: 'tractors', icon: 'tractor', sortOrder: 1, active: true, count: 0, subcategories: [] },
  { id: 2, name: 'الأراضي الزراعية', nameFr: 'Terrains agricoles', nameEn: 'Agricultural land', slug: 'land', icon: 'land', sortOrder: 0, active: true, count: 0, subcategories: [] },
  { id: 3, name: 'البذور', nameFr: 'Semences', nameEn: 'Seeds', slug: 'seeds', icon: 'wheat', sortOrder: 2, active: true, count: 0, subcategories: [] },
  { id: 4, name: 'الأسمدة', nameFr: 'Engrais', nameEn: 'Fertilizers', slug: 'fertilizers', icon: 'flask', sortOrder: 3, active: true, count: 0, subcategories: [] },
  { id: 5, name: 'قطع الغيار', nameFr: 'Pièces détachées', nameEn: 'Spare parts', slug: 'parts', icon: 'wrench', sortOrder: 4, active: true, count: 0, subcategories: [] },
  { id: 6, name: 'المنتجات الزراعية', nameFr: 'Produits agricoles', nameEn: 'Agricultural products', slug: 'products', icon: 'basket', sortOrder: 5, active: true, count: 0, subcategories: [] },
  { id: 7, name: 'الموارد البشرية', nameFr: 'Ressources humaines', nameEn: 'Human resources', slug: 'services', icon: 'users', sortOrder: 6, active: true, count: 0, subcategories: [] },
];

const fieldLabels = {
  saleType: 'fieldSaleType', landCondition: 'fieldLandCondition', region: 'fieldRegion',
  customRegion: 'fieldCustomRegion', ownershipType: 'fieldOwnershipType', area: 'fieldArea',
  waterAvailable: 'fieldWaterAvailable', electricityAvailable: 'fieldElectricityAvailable',
  manufacturer: 'manufacturer', model: 'model', year: 'fieldYear', condition: 'condition',
  hours: 'fieldHours', productName: 'fieldProductName', reference: 'fieldReference',
  brand: 'fieldBrand', quantity: 'fieldQuantity', productionDate: 'fieldProductionDate',
  expiryDate: 'fieldExpiryDate', productType: 'fieldProductType', composition: 'fieldComposition',
  packageSize: 'fieldPackageSize', partName: 'fieldPartName', compatibleMachine: 'fieldCompatibleMachine',
  unit: 'fieldUnit', quality: 'fieldQuality', serviceName: 'fieldServiceName',
  specialization: 'fieldSpecialization', experience: 'fieldExperience', contactPhone: 'fieldContactPhone',
  servicePrice: 'fieldServicePrice',
} as const;

const optionLabels = {
  sale: 'forSale', rent: 'forRent', new: 'new', used: 'used', reclaimed: 'reclaimed',
  unreclaimed: 'unreclaimed', yes: 'available', no: 'unavailable', other: 'other',
  kg: 'unitKilogram', ton: 'unitTon',
} as const;

const regionLabels = {
  روصو: 'regionRosso', كرمسين: 'regionKermassene', اركيز: 'regionRkiz',
  انتيكان: 'regionMbagne', بوگي: 'regionBoghé', لكصيب: 'regionLexeiba', آخر: 'other',
} as const;

export function AddListing() {
  const [, setLocation] = useLocation();
  const { language, t } = useLanguage();
  const categoriesQuery = useListCategories({ query: { queryKey: getListCategoriesQueryKey() } });
  const locationsQuery = useListLocations({ query: { queryKey: getListLocationsQueryKey() } });
  const createListing = useCreateListing();
  const [form, setForm] = useState({
    title: '', category: '', subcategory: '', price: '', currency: 'MRU', location: '',
    condition: 'used', year: '', manufacturer: '', model: '', hours: '', area: '',
    waterAvailable: false, electricityAvailable: false, ownershipType: '', contactPhone: '', description: '',
    imageUrl: '', expiresAt: toDateTimeLocal(new Date(Date.now() + 30 * 24 * 60 * 60 * 1000)), attributes: {} as Record<string, unknown>,
  });
  const [imagePaths, setImagePaths] = useState<string[]>([]);
  const [imageUploadBlocked, setImageUploadBlocked] = useState(false);
  const [createdListing, setCreatedListing] = useState<{ id: number } | null>(null);
  const categories = categoriesQuery.data ?? categoriesFallback;
  const selectedCategory = categories.find((item) => item.slug === form.category);
  const fields = dynamicFieldsForCategory(form.category);
  const update = (key: keyof typeof form, value: string | boolean) =>
    setForm((current) => ({ ...current, [key]: value }));
  const updateDynamic = (key: string, value: string) => {
    if (['condition', 'year', 'manufacturer', 'model', 'hours', 'area', 'ownershipType'].includes(key)) update(key as keyof typeof form, value);
    else if (key === 'waterAvailable' || key === 'electricityAvailable') update(key, value === 'yes');
    else if (key === 'region' && value !== 'آخر') setForm((current) => ({ ...current, location: value, attributes: { ...current.attributes, [key]: value } }));
    else setForm((current) => ({ ...current, attributes: { ...current.attributes, [key]: value } }));
  };
  const dynamicValue = (key: string) =>
    key in form && key !== 'attributes' ? String(form[key as keyof typeof form] ?? '') : String(form.attributes[key] ?? '');
  const submit = (event: FormEvent) => {
    event.preventDefault();
    if (imageUploadBlocked) return;
    const finalLocation = form.attributes.region === 'آخر' ? String(form.attributes.customRegion ?? '') : form.location;
    const data: ListingInput = {
      title: form.title, category: form.category, subcategory: form.subcategory || null,
      price: Number(form.price), currency: form.currency as 'MRU' | 'USD' | 'EUR',
      location: finalLocation, condition: form.condition as 'new' | 'used',
      year: form.year ? Number(form.year) : null, manufacturer: form.manufacturer || null,
      model: form.model || null, hours: form.hours ? Number(form.hours) : null,
      area: form.area ? Number(form.area) : null, waterAvailable: form.waterAvailable,
      electricityAvailable: form.electricityAvailable, ownershipType: form.ownershipType || null,
      attributes: form.attributes, description: form.description, contactPhone: form.contactPhone.trim(),
      imageUrl: imagePaths[0] || form.imageUrl || undefined,
      images: imagePaths.length ? imagePaths : form.imageUrl ? [form.imageUrl] : [],
       expiresAt: new Date(form.expiresAt).toISOString(),
    };
     createListing.mutate({ data }, { onSuccess: (listing) => setCreatedListing({ id: listing.id }) });
  };

  if (createdListing) return <AppShell><PaymentConfirmationPanel listingId={createdListing.id} onDone={() => setLocation('/dashboard')} /></AppShell>;

  return <AppShell><div className="mx-auto max-w-4xl">
    <PageHeading eyebrow={t('startSelling')} title={t('addNewListing')} description={t('addListingDescription')} />
    <form onSubmit={submit} className="overflow-hidden rounded-2xl border border-[hsl(var(--border))] bg-[hsl(var(--card))]">
      <div className="border-b border-[hsl(var(--border))] p-5 sm:p-7">
        <div className="mb-5 flex items-center gap-3"><span className="flex h-8 w-8 items-center justify-center rounded-full bg-[hsl(var(--primary))] text-xs font-bold text-[hsl(var(--accent))]">1</span><div><h2 className="text-sm font-bold">{t('categoryAndBasics')}</h2><p className="text-[11px] text-[hsl(var(--muted-foreground))]">{t('categoryAndBasicsHelp')}</p></div></div>
        <div className="grid gap-4 sm:grid-cols-2">
          <label className="field-label sm:col-span-2">{t('listingTitle')} *<input required minLength={3} value={form.title} onChange={(event) => update('title', event.target.value)} placeholder={t('listingTitlePlaceholder')} className="field-input" data-testid="input-listing-title" /></label>
          <label className="field-label">{t('mainCategory')} *<select required value={form.category} onChange={(event) => setForm((current) => ({ ...current, category: event.target.value, subcategory: '', attributes: {} }))} className="field-input" data-testid="select-listing-category"><option value="">{t('selectCategory')}</option>{categories.map((item) => <option key={item.id} value={item.slug}>{translatedName(item, language)}</option>)}</select></label>
          <label className="field-label">{t('subcategory')}<select value={form.subcategory} onChange={(event) => update('subcategory', event.target.value)} className="field-input" data-testid="select-listing-subcategory"><option value="">{t('chooseSubcategory')}</option>{(selectedCategory?.subcategories ?? []).filter((item) => item.active).map((item) => <option key={item.id} value={item.slug}>{translatedName(item, language)}</option>)}</select></label>
          <label className="field-label">{t('location')} *<select required value={form.location} onChange={(event) => update('location', event.target.value)} className="field-input" data-testid="select-listing-location"><option value="">{t('chooseRegion')}</option>{regions.map((region) => <option key={region} value={region}>{t(regionLabels[region as keyof typeof regionLabels])}</option>)}{(locationsQuery.data ?? []).filter((item) => !regions.includes(item.name)).map((item) => <option key={item.id} value={item.name}>{item.name}</option>)}</select></label>
          <label className="field-label">{t('price')} *<div className="flex"><input required min="0" type="number" value={form.price} onChange={(event) => update('price', event.target.value)} className="field-input rounded-l-none" data-testid="input-listing-price" /><select value={form.currency} onChange={(event) => update('currency', event.target.value)} className="field-input w-24 rounded-r-none border-r-0" data-testid="select-listing-currency"><option value="MRU">{t('currencyMRU')}</option><option value="USD">{t('currencyUSD')}</option><option value="EUR">{t('currencyEUR')}</option></select></div></label>
           <label className="field-label">{t('listingContactPhone')} *<input required minLength={5} value={form.contactPhone} onChange={(event) => update('contactPhone', event.target.value)} type="tel" dir="ltr" className="field-input text-right" autoComplete="tel" placeholder="+222..." data-testid="input-listing-contact-phone" /></label>
           <label className="field-label sm:col-span-2">{t('listingExpiresAt')} *<input required type="datetime-local" min={toDateTimeLocal(new Date())} value={form.expiresAt} onChange={(event) => update('expiresAt', event.target.value)} className="field-input" data-testid="input-listing-expires-at" /><span className="mt-1 block text-[11px] font-normal text-[hsl(var(--muted-foreground))]">{t('listingExpiresAtHelp')}</span></label>
        </div>
      </div>
      <div className="border-b border-[hsl(var(--border))] p-5 sm:p-7">
        <div className="mb-5 flex items-center gap-3"><span className="flex h-8 w-8 items-center justify-center rounded-full bg-[hsl(var(--secondary))] text-xs font-bold text-[hsl(var(--primary))]">2</span><div><h2 className="text-sm font-bold">{t('categorySpecificFields')}</h2><p className="text-[11px] text-[hsl(var(--muted-foreground))]">{t('categorySpecificFieldsHelp')}</p></div></div>
        <div className="grid gap-4 sm:grid-cols-2">{fields.map((field) => field.key === 'customRegion' && dynamicValue('region') !== 'آخر' ? null : <label key={field.key} className="field-label">{t(fieldLabels[field.key as keyof typeof fieldLabels] ?? 'fieldProductName')}{field.type === 'select' ? <select value={dynamicValue(field.key)} onChange={(event) => updateDynamic(field.key, event.target.value)} className="field-input"><option value="">{t('select')}</option>{field.options?.map((option) => <option key={option.value} value={option.value}>{option.value in regionLabels ? t(regionLabels[option.value as keyof typeof regionLabels]) : option.value in optionLabels ? t(optionLabels[option.value as keyof typeof optionLabels]) : option.label}</option>)}</select> : <input type={field.type} value={dynamicValue(field.key)} onChange={(event) => updateDynamic(field.key, event.target.value)} placeholder={field.key === 'customRegion' ? t('fieldCustomRegion') : field.key === 'ownershipType' ? t('fieldOwnershipType') : undefined} className="field-input" />}</label>)}</div>
        <label className="field-label mt-4">{t('description')} *<textarea required minLength={10} value={form.description} onChange={(event) => update('description', event.target.value)} placeholder={t('descriptionPlaceholder')} className="field-input min-h-[125px] resize-y" data-testid="textarea-listing-description" /></label>
        <ListingImageUploader onChange={setImagePaths} onUploadStateChange={setImageUploadBlocked} />
      </div>
       <div className="flex flex-col-reverse justify-between gap-3 bg-[hsl(var(--secondary)/.35)] p-5 sm:flex-row sm:items-center sm:p-7"><p className="flex items-center gap-2 text-[11px] text-[hsl(var(--muted-foreground))]"><ShieldCheck size={16} className="text-[hsl(var(--primary))]" />{t('listingReview')}</p><button type="submit" disabled={createListing.isPending || imageUploadBlocked} className="flex items-center justify-center gap-2 rounded-xl bg-[hsl(var(--primary))] px-6 py-3 text-xs font-bold text-[hsl(var(--primary-foreground))] disabled:opacity-60" data-testid="button-submit-listing">{createListing.isPending && <LoaderCircle size={15} className="animate-spin" />}{t('publishListing')}</button></div>
    </form>
  </div></AppShell>;
}