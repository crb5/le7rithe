import { useAdminAuditLogs } from '@/hooks/use-admin';
import { AdminHeader, AdminTable, AdminTh, AdminTd } from '@/components/admin-ui';
import { useLanguage } from '@/lib/language';
import { Activity } from 'lucide-react';

export function AdminAuditLogs() {
  const { data, isLoading } = useAdminAuditLogs();
  const { t, formatDate, formatNumber } = useLanguage();
  
  const items = data?.items || [];
  const actionLabels: Record<string, string> = {
    'listing.active': t('auditActionListingActive'),
    'listing.rejected': t('auditActionListingRejected'),
    'listing.suspended': t('auditActionListingSuspended'),
    'listing.promote': t('auditActionListingPromoted'),
    'listing.delete': t('auditActionListingDeleted'),
    'user.active': t('auditActionUserActivated'),
    'user.suspended': t('auditActionUserSuspended'),
    'payment.confirmed': t('auditActionPaymentConfirmed'),
    'payment.rejected': t('auditActionPaymentRejected'),
    'package.create': t('auditActionPackageCreated'),
    'package.update': t('auditActionPackageUpdated'),
    'package.delete': t('auditActionPackageDeleted'),
    'payment_method.create': t('auditActionPaymentMethodCreated'),
    'payment_method.update': t('auditActionPaymentMethodUpdated'),
    'payment_method.delete': t('auditActionPaymentMethodDeleted'),
    'report.open': t('auditActionReportOpened'),
    'report.resolved': t('auditActionReportResolved'),
  };
  const resourceTypeLabels: Record<string, string> = {
    listing: t('auditResourceListing'),
    user: t('auditResourceUser'),
    payment: t('auditResourcePayment'),
    package: t('auditResourcePackage'),
    payment_method: t('auditResourcePaymentMethod'),
    report: t('auditResourceReport'),
  };

  return (
    <div className="flex-1 flex flex-col bg-[hsl(42_37%_96%)] h-full">
      <AdminHeader 
        title={t('adminAuditLogsTitle')}
        description={t('adminAuditLogsDescription')}
      />
      
      <div className="p-6 md:p-8 flex-1 flex flex-col min-h-0">
        {isLoading ? (
          <div className="flex-1 flex items-center justify-center"><div className="animate-pulse w-full h-64 bg-white rounded-xl"></div></div>
        ) : (
          <div className="flex-1 flex flex-col overflow-hidden">
            <AdminTable>
              <thead className="sticky top-0 z-10 shadow-sm">
                <tr>
                  <AdminTh>{t('adminIdentifier')}</AdminTh>
                  <AdminTh>{t('auditActionType')}</AdminTh>
                  <AdminTh>{t('auditResource')}</AdminTh>
                  <AdminTh>{t('auditResourceIdentifier')}</AdminTh>
                  <AdminTh>{t('auditAdministratorIdentifier')}</AdminTh>
                  <AdminTh>{t('auditDetails')}</AdminTh>
                  <AdminTh>{t('paymentDate')}</AdminTh>
                </tr>
              </thead>
              <tbody>
                {items.map((log: any) => (
                  <tr key={log.id} className="hover:bg-[hsl(42_37%_97%)] transition-colors">
                    <AdminTd className="font-numeric text-[11px] text-[hsl(153_12%_43%)]">#{formatNumber(Number(log.id))}</AdminTd>
                    <AdminTd>
                      <div className="flex items-center gap-2 font-bold text-[hsl(155_33%_23%)] text-xs">
                        <Activity size={14} className="text-[hsl(42_87%_61%)]" />
                        {actionLabels[log.action] || log.action}
                      </div>
                    </AdminTd>
                    <AdminTd>
                      <span className="text-[11px] font-bold text-[hsl(153_12%_43%)] uppercase tracking-wider font-numeric">{resourceTypeLabels[log.resourceType] || log.resourceType}</span>
                    </AdminTd>
                    <AdminTd>
                      <span className="font-numeric" dir="ltr">{log.resourceId ? formatNumber(Number(log.resourceId)) : t('notAvailable')}</span>
                    </AdminTd>
                    <AdminTd>
                      <div className="text-[11px] truncate max-w-[120px]" title={log.actorClerkUserId || t('system')}>
                        {log.actorClerkUserId || t('system')}
                      </div>
                    </AdminTd>
                    <AdminTd>
                      <div className="text-[10px] font-mono bg-[hsl(42_37%_94%)] border border-[hsl(38_22%_86%)] rounded p-1.5 max-w-[300px] truncate" dir="ltr">
                        {log.details ? JSON.stringify(log.details) : t('auditNoDetails')}
                      </div>
                    </AdminTd>
                    <AdminTd>
                      <div className="flex flex-col gap-0.5">
                        <span className="text-[12px]">{formatDate(log.createdAt, { dateStyle: 'medium' })}</span>
                        <span className="text-[10px] text-[hsl(153_12%_43%)] font-numeric" dir="ltr">{formatDate(log.createdAt, { timeStyle: 'short' })}</span>
                      </div>
                    </AdminTd>
                  </tr>
                ))}
                {items.length === 0 && (
                  <tr>
                    <td colSpan={7} className="px-4 py-12 text-center text-sm text-[hsl(153_12%_43%)]">
                      {t('auditLogsEmpty')}
                    </td>
                  </tr>
                )}
              </tbody>
            </AdminTable>
          </div>
        )}
      </div>
    </div>
  );
}
