import { useState } from 'react';
import { useAdminListings, useUpdateListingStatus, useUpdateListingFeatured, useDeleteListing } from '@/hooks/use-admin';
import { AdminHeader, AdminBadge, AdminActionDialog, AdminTable, AdminTh, AdminTd, Pagination, FilterInput, FilterSelect } from '@/components/admin-ui';
import { formatPrice } from '@/components/marketplace-ui';
import { Link, useLocation } from 'wouter';
import { Star, Pin, Trash2, Edit } from 'lucide-react';
import { useListAdminCategories } from '@workspace/api-client-react';
import { useLanguage } from '@/lib/language';

export function AdminListings() {
  const [location] = useLocation();
  const [page, setPage] = useState(1);
  const [q, setQ] = useState('');
  const [status, setStatus] = useState(() => new URLSearchParams(location.split('?')[1] || '').get('status') || '');
  const [category, setCategory] = useState('');
  
  const categoriesQuery = useListAdminCategories();
  const { data, isLoading } = useAdminListings({ page, limit: 15, q, status, category });
  const updateStatus = useUpdateListingStatus();
  const updateFeatured = useUpdateListingFeatured();
  const deleteListing = useDeleteListing();
  const { language, t, formatNumber, formatDate } = useLanguage();

  const items = data?.items || [];
  const total = data?.total || 0;

  const categoryOptions = [{ label: t('allCategories'), value: '' }].concat(
    (categoriesQuery.data || []).map(c => ({ label: c.name, value: c.slug }))
  );

  return (
    <div className="flex-1 flex flex-col bg-[hsl(42_37%_96%)] h-full">
      <AdminHeader 
        title={t('adminListingsTitle')}
        description={t('adminListingsDescription')}
      />
      
      <div className="p-6 md:p-8 flex-1 flex flex-col min-h-0">
        <div className="flex flex-col sm:flex-row gap-4 mb-6">
          <FilterInput value={q} onChange={(v) => { setQ(v); setPage(1); }} placeholder={t('adminListingsSearchPlaceholder')} />
          <FilterSelect 
            value={status} 
            onChange={(v) => { setStatus(v); setPage(1); }} 
            options={[
              { label: t('allStatuses'), value: '' },
              { label: t('listingStatusActive'), value: 'active' },
              { label: t('listingStatusPendingReview'), value: 'pending_review' },
              { label: t('listingStatusPendingPayment'), value: 'pending_payment' },
              { label: t('listingStatusRejected'), value: 'rejected' },
              { label: t('listingStatusExpired'), value: 'expired' },
              { label: t('listingStatusSuspended'), value: 'suspended' },
            ]} 
          />
          <FilterSelect 
            value={category} 
            onChange={(v) => { setCategory(v); setPage(1); }} 
            options={categoryOptions} 
          />
        </div>

        {isLoading ? (
          <div className="flex-1 flex items-center justify-center"><div className="animate-pulse w-full h-64 bg-white rounded-xl"></div></div>
        ) : (
          <div className="flex-1 flex flex-col overflow-hidden">
            <AdminTable>
              <thead className="sticky top-0 z-10 shadow-sm">
                <tr>
                  <AdminTh>{t('adminIdentifier')}</AdminTh>
                  <AdminTh>{t('adminListing')}</AdminTh>
                  <AdminTh>{t('adminSeller')}</AdminTh>
                  <AdminTh>{t('price')}</AdminTh>
                  <AdminTh>{t('status')}</AdminTh>
                  <AdminTh>{t('adminExpirationDate')}</AdminTh>
                  <AdminTh>{t('adminActions')}</AdminTh>
                </tr>
              </thead>
              <tbody>
                {items.map((listing: any) => (
                  <tr key={listing.id} className={`hover:bg-[hsl(42_37%_97%)] transition-colors ${listing.featured ? 'bg-[hsl(42_87%_61%)/0.03]' : ''}`}>
                    <AdminTd className="font-numeric text-[11px] text-[hsl(153_12%_43%)]">#{formatNumber(Number(listing.id))}</AdminTd>
                    <AdminTd>
                      <div className="flex items-center gap-3">
                        <div className="w-12 h-12 rounded-lg bg-[hsl(38_22%_86%)] overflow-hidden shrink-0 shadow-sm">
                          {listing.imageUrl ? (
                            <img src={listing.imageUrl} alt={listing.title} className="w-full h-full object-cover" />
                          ) : (
                            <div className="w-full h-full flex items-center justify-center text-[hsl(153_12%_43%)] text-xs">{t('noImage')}</div>
                          )}
                        </div>
                        <div>
                          <Link href={`/listings/${listing.id}`} target="_blank" className="font-bold text-[hsl(155_33%_23%)] hover:underline block max-w-[250px] truncate text-sm">
                            {listing.title}
                          </Link>
                          <div className="flex items-center gap-2 mt-1">
                            <span className="text-[11px] text-[hsl(153_12%_43%)]">{listing.category}</span>
                            {listing.featured && <span className="inline-flex items-center text-[10px] font-bold text-[hsl(35_90%_45%)] bg-[hsl(35_90%_50%)/0.15] px-1.5 rounded"><Star size={10} className="mr-0.5 fill-current" /> {t('featured')}</span>}
                            {listing.pinned && <span className="inline-flex items-center text-[10px] font-bold text-[hsl(202_89%_45%)] bg-[hsl(202_89%_53%)/0.15] px-1.5 rounded"><Pin size={10} className="mr-0.5 fill-current" /> {t('pinned')}</span>}
                          </div>
                        </div>
                      </div>
                    </AdminTd>
                    <AdminTd>
                      <div className="font-bold">{listing.seller?.name || t('unknownSeller')}</div>
                      <div className="text-[11px] text-[hsl(153_12%_43%)] font-numeric" dir="ltr">{listing.seller?.phone || '-'}</div>
                    </AdminTd>
                    <AdminTd>
                      <span className="font-numeric font-extrabold text-[hsl(155_33%_23%)]" dir="ltr">
                        {formatPrice(listing.price, listing.currency, language)}
                      </span>
                    </AdminTd>
                    <AdminTd>
                      {listing.status === 'active' && <AdminBadge variant="success">{t('listingStatusActive')}</AdminBadge>}
                      {listing.status === 'pending_review' && <AdminBadge variant="warning">{t('listingStatusPendingReview')}</AdminBadge>}
                      {listing.status === 'draft' && <AdminBadge variant="neutral">{t('listingStatusDraft')}</AdminBadge>}
                      {listing.status === 'pending_payment' && <AdminBadge variant="info">{t('listingStatusPendingPayment')}</AdminBadge>}
                      {listing.status === 'rejected' && <AdminBadge variant="danger">{t('listingStatusRejected')}</AdminBadge>}
                      {listing.status === 'expired' && <AdminBadge variant="neutral">{t('listingStatusExpired')}</AdminBadge>}
                      {listing.status === 'suspended' && <AdminBadge variant="danger">{t('listingStatusSuspended')}</AdminBadge>}
                    </AdminTd>
                    <AdminTd>
                      <span className="text-[12px]">{listing.expiresAt ? formatDate(listing.expiresAt, { dateStyle: 'full', timeStyle: 'short' }) : t('notAvailable')}</span>
                    </AdminTd>
                    <AdminTd>
                      <div className="flex items-center gap-1.5">
                        {listing.status === 'pending_review' && (
                          <span className="max-w-[150px] text-[10px] leading-4 text-[hsl(153_12%_43%)]" title={t('adminActivationRequiresPayment')}>
                            {t('adminActivationRequiresPayment')}
                          </span>
                        )}

                        {listing.status === 'pending_payment' && (
                          <Link
                            href="/admin/payments"
                            className="max-w-[150px] text-[10px] leading-4 font-bold text-[hsl(35_90%_45%)] hover:underline"
                            title={t('adminReviewPaymentToActivate')}
                          >
                            {t('adminReviewPaymentToActivate')}
                          </Link>
                        )}
                        
                        {(listing.status === 'active' || listing.status === 'pending_review') && (
                          <AdminActionDialog
                            title={listing.status === 'active' ? t('adminSuspendListing') : t('adminRejectListing')}
                            description={t(listing.status === 'active' ? 'adminSuspendListingDescription' : 'adminRejectListingReasonDescription')}
                            confirmText={listing.status === 'active' ? t('adminSuspend') : t('adminReject')}
                            confirmVariant="danger"
                            requireReason
                            trigger={<button className="px-3 py-1.5 bg-[hsl(4_62%_48%)/0.1] text-[hsl(4_62%_48%)] text-[11px] font-bold rounded-lg hover:bg-[hsl(4_62%_48%)/0.2] transition-colors">{listing.status === 'active' ? t('adminSuspend') : t('adminReject')}</button>}
                            onConfirm={(reason) => updateStatus.mutateAsync({ id: listing.id, status: listing.status === 'active' ? 'suspended' : 'rejected', reason })}
                          />
                        )}

                        <div className="w-px h-6 bg-[hsl(38_22%_86%)] mx-1" />

                        <AdminActionDialog
                          title={listing.featured ? t('adminUnfeatureListing') : t('adminFeatureListing')}
                          description={t(listing.featured ? 'adminUnfeatureListingDescription' : 'adminFeatureListingDescription', { title: listing.title })}
                          trigger={
                            <button data-testid={`button-featured-listing-${listing.id}`} className={`p-2 rounded-lg transition-colors ${listing.featured ? 'text-[hsl(35_90%_45%)] bg-[hsl(35_90%_50%)/0.15] hover:bg-[hsl(35_90%_50%)/0.25]' : 'text-[hsl(153_12%_43%)] hover:bg-[hsl(42_37%_92%)]'}`} title={listing.featured ? t('adminUnfeatureListing') : t('adminFeatureListing')} aria-label={listing.featured ? t('adminUnfeatureListing') : t('adminFeatureListing')}>
                              <Star size={16} className={listing.featured ? "fill-current" : ""} />
                            </button>
                          }
                          onConfirm={() => updateFeatured.mutateAsync({ id: listing.id, featured: !listing.featured, pinned: listing.pinned })}
                        />

                        <AdminActionDialog
                          title={t('adminDeleteListingPermanently')}
                          description={t('adminDeleteListingDescription', { title: listing.title })}
                          confirmText={t('deleteListing')}
                          confirmVariant="danger"
                          trigger={
                            <button className="p-2 text-[hsl(153_12%_43%)] hover:text-[hsl(4_62%_48%)] hover:bg-[hsl(4_62%_48%)/0.1] rounded-lg transition-colors" title={t('deleteListing')} aria-label={t('deleteListing')}>
                              <Trash2 size={16} />
                            </button>
                          }
                          onConfirm={() => deleteListing.mutateAsync(listing.id)}
                        />
                      </div>
                    </AdminTd>
                  </tr>
                ))}
                {items.length === 0 && (
                  <tr>
                    <td colSpan={7} className="px-4 py-12 text-center text-sm text-[hsl(153_12%_43%)]">
                      {t('adminNoMatchingListings')}
                    </td>
                  </tr>
                )}
              </tbody>
            </AdminTable>
            <Pagination page={page} limit={15} total={total} onPageChange={setPage} />
          </div>
        )}
      </div>
    </div>
  );
}
