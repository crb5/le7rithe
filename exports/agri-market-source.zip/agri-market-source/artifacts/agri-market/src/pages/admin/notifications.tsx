import { Bell, Check, Clock3, ExternalLink, Loader2 } from 'lucide-react';
import { useLocation } from 'wouter';
import {
  useAdminNotifications,
  useMarkAdminNotificationRead,
  type AdminNotification,
} from '@/hooks/use-admin';
import { AdminHeader } from '@/components/admin-ui';
import { useLanguage } from '@/lib/language';

function paymentStatusKey(status: string) {
  if (status === 'confirmed') return 'adminNotificationPaymentConfirmed';
  if (status === 'rejected') return 'adminNotificationPaymentRejected';
  return 'adminNotificationPaymentPending';
}

function listingStatusKey(status: string | null) {
  if (status === 'active') return 'listingStatusActive';
  if (status === 'pending_review') return 'listingStatusPendingReview';
  if (status === 'pending_payment') return 'listingStatusPendingPayment';
  if (status === 'rejected') return 'listingStatusRejected';
  if (status === 'expired') return 'listingStatusExpired';
  if (status === 'suspended') return 'listingStatusSuspended';
  return 'notAvailable';
}

export function AdminNotifications() {
  const [, setLocation] = useLocation();
  const { data, isLoading } = useAdminNotifications();
  const markRead = useMarkAdminNotificationRead();
  const { t, formatDate } = useLanguage();
  const notifications = data?.items ?? [];

  const openNotification = (notification: AdminNotification) => {
    if (!notification.read) {
      markRead.mutate(notification.id);
    }
    const status = notification.listingStatus || 'pending_payment';
    setLocation(`/admin/listings?status=${encodeURIComponent(status)}`);
  };

  return (
    <div className="flex min-h-full flex-1 flex-col bg-[hsl(42_37%_96%)]">
      <AdminHeader
        title={t('adminNotificationsTitle')}
        description={t('adminNotificationsDescription')}
      />

      <div className="flex-1 p-6 md:p-8">
        <div className="mx-auto max-w-4xl space-y-4">
          {isLoading ? (
            <div className="flex items-center justify-center rounded-xl border border-[hsl(38_22%_86%)] bg-white py-20 text-[hsl(153_12%_43%)]">
              <Loader2 className="animate-spin" />
            </div>
          ) : notifications.length === 0 ? (
            <div className="rounded-xl border border-dashed border-[hsl(38_22%_80%)] bg-white px-6 py-20 text-center">
              <Bell className="mx-auto mb-4 text-[hsl(153_12%_55%)]" size={34} />
              <p className="font-semibold text-[hsl(155_33%_23%)]">{t('adminNoNotifications')}</p>
            </div>
          ) : (
            notifications.map((notification) => (
              <button
                key={notification.id}
                type="button"
                onClick={() => openNotification(notification)}
                className={`group w-full rounded-xl border bg-white p-5 text-start shadow-sm transition hover:-translate-y-0.5 hover:shadow-md focus:outline-none focus:ring-2 focus:ring-[hsl(42_87%_61%)] ${
                  notification.read
                    ? 'border-[hsl(38_22%_86%)]'
                    : 'border-[hsl(42_87%_61%)] bg-[hsl(42_87%_61%)/.08]'
                }`}
              >
                <div className="flex items-start gap-4">
                  <span className={`mt-0.5 rounded-full p-2.5 ${
                    notification.read
                      ? 'bg-[hsl(155_33%_16%)/.08] text-[hsl(155_33%_23%)]'
                      : 'bg-[hsl(42_87%_61%)] text-[hsl(155_33%_16%)]'
                  }`}>
                    {notification.read ? <Check size={18} /> : <Bell size={18} />}
                  </span>
                  <span className="min-w-0 flex-1">
                    <span className="flex flex-col justify-between gap-2 sm:flex-row sm:items-center">
                      <span className="font-bold text-[hsl(155_33%_23%)]">
                        {t('adminNotificationNewListing')}
                      </span>
                      <span className={`text-[10px] font-bold uppercase tracking-wide ${
                        notification.read ? 'text-[hsl(153_12%_55%)]' : 'text-[hsl(4_62%_58%)]'
                      }`}>
                        {notification.read ? t('adminNotificationRead') : t('adminNotificationUnread')}
                      </span>
                    </span>
                    <span className="mt-2 block text-sm text-[hsl(153_12%_43%)]">{notification.body}</span>
                    <span className="mt-4 grid gap-3 text-xs text-[hsl(155_33%_23%)] sm:grid-cols-2">
                      <span><strong>{t('adminNotificationSeller')}:</strong> {notification.sellerName || t('unknownSeller')}</span>
                      <span><strong>{t('adminNotificationListing')}:</strong> {notification.listingTitle || t('notAvailable')}</span>
                      <span className="flex items-center gap-1.5">
                        <Clock3 size={14} />
                        <strong>{t('adminNotificationCreatedAt')}:</strong>
                        <span>{formatDate(notification.listingCreatedAt, { dateStyle: 'full', timeStyle: 'short' })}</span>
                      </span>
                      <span><strong>{t('adminNotificationPaymentStatus')}:</strong> {t(paymentStatusKey(notification.paymentStatus) as any)}</span>
                      <span><strong>{t('adminNotificationListingStatus')}:</strong> {t(listingStatusKey(notification.listingStatus) as any)}</span>
                    </span>
                    <span className="mt-4 inline-flex items-center gap-1.5 text-xs font-bold text-[hsl(155_33%_23%)] group-hover:text-[hsl(4_62%_58%)]">
                      {t('adminNotificationOpenListings')} <ExternalLink size={14} />
                    </span>
                  </span>
                </div>
              </button>
            ))
          )}
        </div>
      </div>
    </div>
  );
}