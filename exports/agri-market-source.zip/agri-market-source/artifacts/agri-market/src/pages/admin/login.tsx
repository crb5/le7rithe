import { useEffect } from 'react';
import { SignIn, useUser } from '@clerk/react';
import { useLocation } from 'wouter';
import { Leaf } from 'lucide-react';
import { Logo } from '@/components/marketplace-ui';
import { useLanguage } from '@/lib/language';

export function AdminLogin({ basePath }: { basePath: string }) {
  const { user, isLoaded } = useUser();
  const [, setLocation] = useLocation();
  const { language, meta, t } = useLanguage();

  useEffect(() => {
    if (isLoaded && user) setLocation('/admin');
  }, [isLoaded, user, setLocation]);

  if (isLoaded && user) {
    return null;
  }

  return (
    <div className="min-h-[100dvh] bg-[hsl(42_37%_96%)] flex flex-col items-center justify-center p-4 relative overflow-hidden" dir={meta[language].dir}>
      {/* Decorative background */}
      <div className="absolute top-0 right-0 -mr-32 -mt-32 w-[600px] h-[600px] rounded-full bg-[hsl(155_33%_23%)/0.03] blur-3xl pointer-events-none" />
      <div className="absolute bottom-0 left-0 -ml-32 -mb-32 w-[400px] h-[400px] rounded-full bg-[hsl(42_87%_61%)/0.05] blur-3xl pointer-events-none" />
      
      <div className="mb-10 scale-125">
        <Logo />
      </div>
      
      <div className="w-full max-w-[440px] bg-white border border-[hsl(38_22%_86%)] rounded-3xl shadow-[0_20px_60px_-15px_rgba(0,0,0,0.1)] relative z-10 overflow-hidden">
        <div className="bg-[hsl(155_33%_16%)] p-6 text-center text-white border-b border-[hsl(155_33%_16%)]">
          <h1 className="text-xl font-bold">{t('adminPortal')}</h1>
          <p className="text-xs text-[hsl(42_34%_94%)/0.7] mt-1 font-medium tracking-wide">{t('restrictedAccess')}</p>
        </div>
        
        <div className="p-8 pb-10 flex flex-col items-center">
          <SignIn
            routing="path"
            path={`${basePath}/admin/login`}
            signUpUrl={`${basePath}/sign-up`}
            forceRedirectUrl={`${basePath}/admin`}
          />
        </div>
      </div>
      
      <p className="mt-12 text-xs text-[hsl(153_12%_43%)] font-medium z-10">
        &copy; {new Date().getFullYear()} {t('brand')}. {t('footerRights')}
      </p>
    </div>
  );
}
