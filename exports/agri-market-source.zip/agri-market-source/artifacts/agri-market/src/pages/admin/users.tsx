import { useState } from 'react';
import { useAdminUsers, useUpdateUserStatus } from '@/hooks/use-admin';
import { AdminHeader, AdminBadge, AdminActionDialog, AdminTable, AdminTh, AdminTd, FilterInput, FilterSelect } from '@/components/admin-ui';
import { Shield, ShieldBan, UserCog } from 'lucide-react';
import { useLanguage } from '@/lib/language';

export function AdminUsers() {
  const [q, setQ] = useState('');
  const [status, setStatus] = useState('');
  const { t, formatDate, formatNumber } = useLanguage();
  
  const { data, isLoading } = useAdminUsers({ q, status });
  const updateStatus = useUpdateUserStatus();

  const items = data?.items || [];

  return (
    <div className="flex-1 flex flex-col bg-[hsl(42_37%_96%)] h-full">
      <AdminHeader 
        title={t('adminUsersTitle')}
        description={t('adminUsersDescription')}
      />
      
      <div className="p-6 md:p-8 flex-1 flex flex-col min-h-0">
        <div className="flex flex-col sm:flex-row gap-4 mb-6">
          <FilterInput value={q} onChange={setQ} placeholder={t('adminUsersSearchPlaceholder')} />
          <FilterSelect 
            value={status} 
            onChange={setStatus} 
            options={[
              { label: t('allStatuses'), value: '' },
              { label: t('userStatusActive'), value: 'active' },
              { label: t('userStatusSuspended'), value: 'suspended' },
            ]} 
          />
        </div>

        {isLoading ? (
          <div className="flex-1 flex items-center justify-center"><div className="animate-pulse w-full h-64 bg-white rounded-xl"></div></div>
        ) : (
          <div className="flex-1 flex flex-col overflow-hidden">
            <AdminTable>
              <thead className="sticky top-0 z-10 shadow-sm">
                <tr>
                  <AdminTh>{t('adminIdentifier')}</AdminTh>
                  <AdminTh>{t('adminUser')}</AdminTh>
                  <AdminTh>{t('phoneNumber')}</AdminTh>
                  <AdminTh>{t('adminRole')}</AdminTh>
                  <AdminTh>{t('adminListingCount')}</AdminTh>
                  <AdminTh>{t('adminRegistrationDate')}</AdminTh>
                  <AdminTh>{t('status')}</AdminTh>
                  <AdminTh>{t('adminActions')}</AdminTh>
                </tr>
              </thead>
              <tbody>
                {items.map((user: any) => (
                  <tr key={user.id} className="hover:bg-[hsl(42_37%_97%)] transition-colors">
                    <AdminTd className="font-numeric text-[11px] text-[hsl(153_12%_43%)]">#{formatNumber(Number(user.id))}</AdminTd>
                    <AdminTd>
                      <div className="flex items-center gap-3">
                        <div className="w-10 h-10 rounded-full bg-[hsl(155_33%_23%)/0.1] text-[hsl(155_33%_23%)] flex items-center justify-center font-bold text-lg shrink-0">
                          {user.name ? user.name.charAt(0) : t('adminUnknownUserInitial')}
                        </div>
                        <div>
                          <div className="font-bold text-[hsl(155_33%_23%)]">{user.name || t('unknownUser')}</div>
                          {user.verified && <span className="text-[10px] text-[hsl(42_87%_61%)] font-bold">{t('verified')}</span>}
                        </div>
                      </div>
                    </AdminTd>
                    <AdminTd>
                      <div className="font-numeric" dir="ltr">{user.phone || '—'}</div>
                    </AdminTd>
                    <AdminTd>
                      {user.role === 'admin' ? (
                        <span className="flex items-center gap-1.5 text-[11px] font-bold text-[hsl(202_89%_45%)] bg-[hsl(202_89%_53%)/0.15] px-2 py-1 rounded-md w-fit">
                          <UserCog size={13} /> {t('userRoleAdmin')}
                        </span>
                      ) : user.role === 'moderator' ? (
                        <span className="flex items-center gap-1.5 text-[11px] font-bold text-[hsl(155_33%_23%)] bg-[hsl(155_33%_23%)/0.1] px-2 py-1 rounded-md w-fit">
                          <Shield size={13} /> {t('userRoleModerator')}
                        </span>
                      ) : (
                          <span className="text-[12px] text-[hsl(153_12%_43%)]">{t('userRoleSeller')}</span>
                      )}
                    </AdminTd>
                    <AdminTd>
                        <span className="font-numeric font-bold">{formatNumber(Number(user.listingCount || 0))}</span>
                    </AdminTd>
                    <AdminTd>
                        <span className="text-[12px]">{formatDate(user.createdAt, { dateStyle: 'medium' })}</span>
                    </AdminTd>
                    <AdminTd>
                      {user.status === 'active' ? <AdminBadge variant="success">{t('userStatusActive')}</AdminBadge> : <AdminBadge variant="danger">{t('userStatusSuspended')}</AdminBadge>}
                    </AdminTd>
                    <AdminTd>
                      {user.role !== 'admin' && (
                        <div className="flex items-center gap-1.5">
                          {user.status === 'active' ? (
                            <AdminActionDialog
                              title={t('adminSuspendUser')}
                              description={t('adminSuspendUserDescription', { name: user.name || t('unknownUser') })}
                              confirmText={t('adminSuspend')}
                              confirmVariant="danger"
                              trigger={<button className="flex items-center gap-1.5 px-3 py-1.5 bg-[hsl(4_62%_48%)/0.1] text-[hsl(4_62%_48%)] text-[11px] font-bold rounded-lg hover:bg-[hsl(4_62%_48%)/0.2] transition-colors"><ShieldBan size={14} /> {t('adminSuspend')}</button>}
                              onConfirm={() => updateStatus.mutateAsync({ id: user.id, status: 'suspended' })}
                            />
                          ) : (
                            <AdminActionDialog
                              title={t('adminActivateUser')}
                              description={t('adminActivateUserDescription', { name: user.name || t('unknownUser') })}
                              confirmText={t('adminActivate')}
                              trigger={<button className="flex items-center gap-1.5 px-3 py-1.5 bg-[hsl(155_33%_23%)/0.1] text-[hsl(155_33%_23%)] text-[11px] font-bold rounded-lg hover:bg-[hsl(155_33%_23%)/0.2] transition-colors"><Shield size={14} /> {t('adminActivate')}</button>}
                              onConfirm={() => updateStatus.mutateAsync({ id: user.id, status: 'active' })}
                            />
                          )}
                        </div>
                      )}
                    </AdminTd>
                  </tr>
                ))}
                {items.length === 0 && (
                  <tr>
                    <td colSpan={8} className="px-4 py-12 text-center text-sm text-[hsl(153_12%_43%)]">
                      {t('adminNoUsersFound')}
                    </td>
                  </tr>
                )}
              </tbody>
            </AdminTable>
          </div>
        )}
      </div>
    </div>
  );
}
