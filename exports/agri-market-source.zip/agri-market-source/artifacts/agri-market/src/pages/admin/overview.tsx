import { useAdminOverview, useUpdateListingStatus } from '@/hooks/use-admin';
import { AdminHeader, AdminBadge, AdminActionDialog, AdminTable, AdminTh, AdminTd } from '@/components/admin-ui';
import { StatCard, formatPrice } from '@/components/marketplace-ui';
import { Users, FileText, CheckCircle2, Clock, AlertTriangle, CreditCard, DollarSign, Activity } from 'lucide-react';
import { Link } from 'wouter';
import { useLanguage } from '@/lib/language';

export function AdminOverview() {
  const { data, isLoading } = useAdminOverview();
  const updateStatus = useUpdateListingStatus();
  const { language, t, formatNumber, formatDate } = useLanguage();

  if (isLoading) {
    return <div className="p-8 flex items-center justify-center h-full"><div className="animate-pulse w-full max-w-4xl h-96 bg-[hsl(38_22%_92%)] rounded-2xl"></div></div>;
  }

  const stats = data?.stats || {};
  const recent = data?.recentListings || [];

  return (
    <div className="flex-1 flex flex-col bg-[hsl(42_37%_96%)]">
      <AdminHeader 
        title={t('adminOverviewTitle')}
        description={t('adminOverviewDescription')}
      />
      
      <div className="p-6 md:p-8 flex-1 space-y-8 max-w-[1600px]">
        {/* KPI Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-5">
          <StatCard label={t('adminActiveListingsTotal')} value={formatNumber(stats.activeListings || 0)} icon={CheckCircle2} accent href="/admin/listings" />
          <StatCard label={t('adminPendingPaymentListings')} value={formatNumber(stats.pendingReview || 0)} icon={Clock} href="/admin/payments" />
          <StatCard label={t('adminUsersTotal')} value={formatNumber(stats.users || 0)} icon={Users} href="/admin/users" />
          <StatCard label={t('adminOpenReports')} value={formatNumber(stats.openReports || 0)} icon={AlertTriangle} href="/admin/reports" />
          
          <StatCard label={t('adminPendingPayments')} value={formatNumber(stats.pendingPayments || 0)} icon={CreditCard} href="/admin/payments" />
          <StatCard label={t('adminTotalRevenue')} value={formatNumber(stats.revenue || 0)} icon={DollarSign} href="/admin/payments" />
          <StatCard label={t('adminListingsTotal')} value={formatNumber(stats.listings || 0)} icon={FileText} href="/admin/listings" />
          <StatCard label={t('adminExpiredListings')} value={formatNumber(stats.expiredListings || 0)} icon={Activity} href="/admin/listings" />
        </div>

        {/* Recent Listings */}
        <div className="flex flex-col flex-1">
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-lg font-bold text-[hsl(155_33%_23%)]">{t('adminLatestListings')}</h2>
            <Link href="/admin/listings" className="text-sm font-bold text-[hsl(155_33%_23%)] hover:underline">{t('viewAll')}</Link>
          </div>
          
          <AdminTable>
            <thead>
              <tr>
                <AdminTh>{t('adminListing')}</AdminTh>
                <AdminTh>{t('adminSeller')}</AdminTh>
                <AdminTh>{t('price')}</AdminTh>
                <AdminTh>{t('status')}</AdminTh>
                <AdminTh>{t('adminPublishedDate')}</AdminTh>
                <AdminTh>{t('adminAction')}</AdminTh>
              </tr>
            </thead>
            <tbody>
              {recent.map((listing: any) => (
                <tr key={listing.id} className="hover:bg-[hsl(42_37%_97%)] transition-colors">
                  <AdminTd>
                    <div className="flex items-center gap-3">
                      <div className="w-10 h-10 rounded bg-[hsl(38_22%_86%)] overflow-hidden shrink-0">
                        {listing.imageUrl ? (
                          <img src={listing.imageUrl} alt={listing.title} className="w-full h-full object-cover" />
                        ) : (
                          <div className="w-full h-full flex items-center justify-center text-[hsl(153_12%_43%)] text-xs">{t('noImage')}</div>
                        )}
                      </div>
                      <div>
                        <Link href={`/listings/${listing.id}`} target="_blank" className="font-bold text-[hsl(155_33%_23%)] hover:underline block max-w-[200px] truncate">
                          {listing.title}
                        </Link>
                        <span className="text-[11px] text-[hsl(153_12%_43%)]">{listing.category}</span>
                      </div>
                    </div>
                  </AdminTd>
                  <AdminTd>
                    <div className="font-bold">{listing.seller?.name || t('unknownSeller')}</div>
                    <div className="text-[11px] text-[hsl(153_12%_43%)] font-numeric" dir="ltr">{listing.seller?.phone || '-'}</div>
                  </AdminTd>
                  <AdminTd>
                    <span className="font-numeric font-extrabold text-[hsl(155_33%_23%)]" dir="ltr">
                      {formatPrice(listing.price, listing.currency, language)}
                    </span>
                  </AdminTd>
                  <AdminTd>
                    {listing.status === 'active' && <AdminBadge variant="success">{t('listingStatusActive')}</AdminBadge>}
                    {listing.status === 'pending_review' && <AdminBadge variant="warning">{t('listingStatusPendingReview')}</AdminBadge>}
                    {listing.status === 'draft' && <AdminBadge variant="neutral">{t('listingStatusDraft')}</AdminBadge>}
                    {listing.status === 'pending_payment' && <AdminBadge variant="info">{t('listingStatusPendingPayment')}</AdminBadge>}
                    {listing.status === 'rejected' && <AdminBadge variant="danger">{t('listingStatusRejected')}</AdminBadge>}
                    {listing.status === 'expired' && <AdminBadge variant="neutral">{t('listingStatusExpired')}</AdminBadge>}
                    {listing.status === 'suspended' && <AdminBadge variant="danger">{t('listingStatusSuspended')}</AdminBadge>}
                  </AdminTd>
                  <AdminTd>
                    <span className="text-[12px]">{formatDate(listing.createdAt, { dateStyle: 'full', timeStyle: 'short' })}</span>
                  </AdminTd>
                  <AdminTd>
                    <div className="flex gap-2">
                      {(listing.status === 'pending_review' || listing.status === 'pending_payment') && (
                        <>
                          <Link href="/admin/payments" className="px-3 py-1.5 bg-[hsl(35_90%_50%)/0.15] text-[hsl(35_90%_45%)] text-[11px] font-bold rounded-lg hover:bg-[hsl(35_90%_50%)/0.25]">
                            {t('adminReviewPaymentToActivate')}
                          </Link>
                          {listing.status === 'pending_review' && (
                          <AdminActionDialog
                            title={t('adminRejectListing')}
                            description={t('adminRejectListingDescription', { title: listing.title })}
                            confirmText={t('adminReject')}
                            confirmVariant="danger"
                            requireReason
                            trigger={<button className="px-3 py-1.5 bg-[hsl(4_62%_48%)/0.1] text-[hsl(4_62%_48%)] text-[11px] font-bold rounded-lg hover:bg-[hsl(4_62%_48%)/0.2]">{t('adminReject')}</button>}
                            onConfirm={(reason) => updateStatus.mutateAsync({ id: listing.id, status: 'rejected', reason })}
                          />
                          )}
                        </>
                      )}
                    </div>
                  </AdminTd>
                </tr>
              ))}
              {recent.length === 0 && (
                <tr>
                  <td colSpan={6} className="px-4 py-8 text-center text-sm text-[hsl(153_12%_43%)]">
                    {t('adminNoListingsToShow')}
                  </td>
                </tr>
              )}
            </tbody>
          </AdminTable>
        </div>
      </div>
    </div>
  );
}
