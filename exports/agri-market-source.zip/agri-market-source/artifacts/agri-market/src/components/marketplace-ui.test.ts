import assert from 'node:assert/strict';
import { describe, it } from 'node:test';
import {
  FlaskConical,
  LandPlot,
  Leaf,
  ShoppingBasket,
  Sprout,
  Tractor,
  Users,
  Wrench,
} from 'lucide-react';
import { iconForCategory } from './marketplace-ui';

describe('iconForCategory', () => {
  it('maps every current catalog category to its intended icon family', () => {
    const categories = [
      { slug: 'tractors', expected: Tractor },
      { slug: 'seeds', expected: Sprout },
      { slug: 'land', expected: LandPlot },
      { slug: 'parts', expected: Wrench },
      { slug: 'fertilizers', expected: FlaskConical },
      { slug: 'products', expected: ShoppingBasket },
      { slug: 'services', expected: Users },
    ];

    for (const { slug, expected } of categories) {
      assert.strictEqual(iconForCategory(slug), expected, `expected ${slug} to use ${expected.displayName ?? expected.name}`);
    }
  });

  it('uses translated category titles when the slug is not descriptive', () => {
    const translatedTitles = [
      ['الآليات الزراعية', Tractor],
      ['Machines agricoles', Tractor],
      ['Agricultural machinery', Tractor],
      ['البذور', Sprout],
      ['Semences', Sprout],
      ['Seeds', Sprout],
      ['الأراضي الزراعية', LandPlot],
      ['Terrains agricoles', LandPlot],
      ['Agricultural land', LandPlot],
      ['قطع غيار الآليات الزراعية', Wrench],
      ['Pièces détachées', Wrench],
      ['Agricultural spare parts', Wrench],
      ['الأسمدة', FlaskConical],
      ['Engrais', FlaskConical],
      ['Fertilizers', FlaskConical],
      ['تسويق المنتجات الزراعية', ShoppingBasket],
      ['Produits agricoles', ShoppingBasket],
      ['Agricultural products', ShoppingBasket],
      ['الموارد البشرية الزراعية', Users],
      ['Ressources humaines agricoles', Users],
      ['Agricultural human resources', Users],
    ] as const;

    for (const [title, expected] of translatedTitles) {
      assert.strictEqual(iconForCategory(title), expected, `expected "${title}" to use ${expected.displayName ?? expected.name}`);
    }
  });

  it('falls back to the generic agriculture icon for unknown categories', () => {
    assert.strictEqual(iconForCategory('something new'), Leaf);
  });
});