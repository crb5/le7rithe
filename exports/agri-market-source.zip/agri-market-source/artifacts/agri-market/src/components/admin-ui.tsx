import { useEffect, useState, ReactNode } from 'react';
import { Link, useLocation } from 'wouter';
import { useAuth, useClerk } from '@clerk/react';
import * as DialogPrimitive from '@radix-ui/react-dialog';
import {
  LayoutDashboard,
  Users,
  Search,
  CreditCard,
  Package,
  Flag,
  List,
  History,
  LogOut,
  FolderTree,
  X,
  AlertTriangle,
  Loader2,
  ChevronRight,
  Filter,
  Menu,
  Bell,
} from 'lucide-react';
import { useAdminMe, useAdminNotifications } from '@/hooks/use-admin';
import { useToast } from '@/hooks/use-toast';
import { useLanguage } from '@/lib/language';

const navItems = [
  { href: '/admin', label: 'adminOverviewTitle', icon: LayoutDashboard, exact: true },
  { href: '/admin/listings', label: 'adminListingsTitle', icon: Search },
  { href: '/admin/notifications', label: 'adminNotificationsTitle', icon: Bell },
  { href: '/admin/users', label: 'adminUsersTitle', icon: Users },
  { href: '/admin/payments', label: 'adminPaymentsTitle', icon: CreditCard },
  { href: '/admin/reports', label: 'adminReportsTitle', icon: Flag },
  { href: '/admin/packages', label: 'adminPackagesTitle', icon: Package },
  { href: '/admin/payment-methods', label: 'adminPaymentMethodsTitle', icon: List },
  { href: '/admin/categories', label: 'manageCategories', icon: FolderTree },
  { href: '/admin/audit-logs', label: 'adminAuditLogsTitle', icon: History },
] as const;

export function AdminAppShell({ children }: { children: ReactNode }) {
  const [location] = useLocation();
  const { signOut } = useClerk();
  const { toast } = useToast();
  const [menuOpen, setMenuOpen] = useState(false);
  const [isSigningOut, setIsSigningOut] = useState(false);
  const { language, setLanguage, meta, t, formatNumber } = useLanguage();
  const { data: notifications } = useAdminNotifications();

  const handleSignOut = async () => {
    if (isSigningOut) return;
    setIsSigningOut(true);
    try {
      await signOut({ redirectUrl: `${import.meta.env.BASE_URL.replace(/\/$/, '')}/sign-in` });
    } catch {
      setIsSigningOut(false);
       toast({ title: t('signOutError'), description: t('tryAgain'), variant: 'destructive' });
    }
  };
  
  return (
    <div className="min-h-[100dvh] bg-[hsl(42_37%_94%)] text-[hsl(154_26%_15%)] font-sans selection:bg-[hsl(42_87%_61%)]" dir={meta[language].dir}>
      {menuOpen && <button type="button" aria-label={t('closeMenu')} onClick={() => setMenuOpen(false)} className="fixed inset-0 z-40 bg-black/45 backdrop-blur-sm lg:hidden" />}
      <aside className={`fixed inset-y-0 ${language === 'ar' ? 'right-0 border-l' : 'left-0 border-r'} w-[280px] max-w-[86vw] bg-[hsl(155_33%_16%)] text-white border-[hsl(154_26%_25%)] flex flex-col z-50 transition-transform duration-300 lg:w-[260px] lg:translate-x-0 ${menuOpen ? 'translate-x-0' : language === 'ar' ? 'translate-x-full' : '-translate-x-full'}`}>
        <div className="p-6">
          <Link href="/admin" className="flex items-center gap-3 text-[hsl(42_87%_61%)] transition-transform hover:-translate-y-0.5">
            <LayoutDashboard size={24} strokeWidth={2.5} />
            <span className="font-bold text-lg tracking-tight text-white">{t('admin')}</span>
          </Link>
          <div className="mt-2 text-[10px] text-[hsl(153_12%_63%)] uppercase tracking-wider font-bold">{t('adminSubtitle')}</div>
        </div>
        
        <nav className="flex-1 px-4 space-y-1.5 overflow-y-auto">
          {navItems.map((item) => {
            const active = item.href === '/admin'
              ? location === item.href 
              : location.startsWith(item.href);
              
            return (
              <Link 
                key={item.href} 
                href={item.href} 
                onClick={() => setMenuOpen(false)}
                className={`flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm font-semibold transition-all ${
                  active 
                    ? 'bg-[hsl(42_87%_61%)] text-[hsl(155_33%_16%)]' 
                    : 'text-[hsl(42_34%_94%)] hover:bg-white/10'
                }`}
              >
                <item.icon size={18} strokeWidth={active ? 2.5 : 2} />
                <span className="min-w-0 flex-1">{t(item.label)}</span>
                {item.href === '/admin/notifications' && Boolean(notifications?.unreadCount) && (
                  <span className={`min-w-5 rounded-full px-1.5 py-0.5 text-center text-[10px] font-black ${
                    active
                      ? 'bg-[hsl(155_33%_16%)] text-[hsl(42_87%_61%)]'
                      : 'bg-[hsl(4_62%_58%)] text-white'
                  }`}>
                    {formatNumber(notifications?.unreadCount ?? 0)}
                  </span>
                )}
              </Link>
            );
          })}
        </nav>
        
        <div className="p-4 border-t border-white/10">
          <select value={language} onChange={(event) => setLanguage(event.target.value as typeof language)} aria-label={t('language')} className="mb-3 w-full rounded-lg border border-white/15 bg-transparent px-3 py-2 text-xs font-bold text-white outline-none">
            <option className="bg-white text-[hsl(155_33%_16%)]" value="ar">العربية</option><option className="bg-white text-[hsl(155_33%_16%)]" value="fr">Français</option><option className="bg-white text-[hsl(155_33%_16%)]" value="en">English</option>
          </select>
          <button 
            type="button"
            onClick={handleSignOut}
            disabled={isSigningOut}
            className="flex items-center gap-3 w-full px-3 py-2.5 rounded-lg text-sm font-semibold text-[hsl(4_62%_68%)] hover:bg-[hsl(4_62%_48%)/0.15] transition-colors"
          >
            {isSigningOut ? <Loader2 size={18} className="animate-spin" /> : <LogOut size={18} />}
            {isSigningOut ? t('signingOut') : t('signOut')}
          </button>
        </div>
      </aside>
      
      <main className={`flex min-h-[100dvh] flex-col ${language === 'ar' ? 'lg:mr-[260px]' : 'lg:ml-[260px]'}`}>
        <div className="sticky top-0 z-40 flex items-center justify-between border-b border-[hsl(38_22%_86%)] bg-[hsl(155_33%_16%)] px-4 py-3 text-white shadow-sm lg:hidden">
          <button type="button" onClick={() => setMenuOpen(true)} className="rounded-lg border border-white/15 p-2" aria-label={t('openAdminMenu')}><Menu size={20} /></button>
          <span className="text-sm font-bold">{t('admin')}</span>
          <span className="h-9 w-9" />
        </div>
        {children}
      </main>
    </div>
  );
}

export function AdminHeader({ title, description, action }: { title: string; description?: string; action?: ReactNode }) {
  const { language, setLanguage, t } = useLanguage();
  return (
    <header className="bg-white border-b border-[hsl(38_22%_86%)] px-8 py-6 flex flex-col sm:flex-row sm:items-end justify-between gap-4 sticky top-0 z-30 shadow-sm">
      <div>
        <h1 className="text-2xl font-bold text-[hsl(155_33%_23%)] tracking-tight">{title}</h1>
        {description && <p className="mt-1 text-sm text-[hsl(153_12%_43%)] font-medium">{description}</p>}
      </div>
        <div className="flex items-center gap-3"><select value={language} onChange={(event) => setLanguage(event.target.value as typeof language)} aria-label={t('language')} className="rounded-lg border border-[hsl(38_22%_86%)] bg-white px-2 py-2 text-xs font-bold text-[hsl(155_33%_23%)]"><option className="bg-white text-[hsl(155_33%_23%)]" value="ar">العربية</option><option className="bg-white text-[hsl(155_33%_23%)]" value="fr">FR</option><option className="bg-white text-[hsl(155_33%_23%)]" value="en">EN</option></select>{action && <div>{action}</div>}</div>
    </header>
  );
}

export function AdminTable({ children }: { children: ReactNode }) {
  const { language } = useLanguage();
  return (
    <div className="bg-white border border-[hsl(38_22%_86%)] rounded-xl shadow-sm overflow-hidden flex-1">
      <div className="overflow-x-auto">
        <table className={`w-full text-sm whitespace-nowrap ${language === 'ar' ? 'text-right' : 'text-left'}`}>
          {children}
        </table>
      </div>
    </div>
  );
}

export function AdminTh({ children, className = '' }: { children: ReactNode; className?: string }) {
  return <th className={`px-4 py-3.5 bg-[hsl(42_37%_97%)] border-b border-[hsl(38_22%_86%)] text-[11px] font-bold text-[hsl(153_12%_43%)] uppercase tracking-wider ${className}`}>{children}</th>;
}

export function AdminTd({ children, className = '' }: { children: ReactNode; className?: string }) {
  return <td className={`px-4 py-3.5 border-b border-[hsl(38_22%_92%)] text-[13px] font-medium text-[hsl(154_26%_15%)] ${className}`}>{children}</td>;
}

export function AdminBadge({ children, variant = 'default' }: { children: ReactNode; variant?: 'default' | 'success' | 'warning' | 'danger' | 'info' | 'neutral' }) {
  const styles = {
    default: 'bg-[hsl(42_87%_61%)/0.15] text-[hsl(155_33%_23%)] border-[hsl(42_87%_61%)/0.3]',
    success: 'bg-[hsl(155_33%_23%)/0.1] text-[hsl(155_33%_23%)] border-[hsl(155_33%_23%)/0.2]',
    warning: 'bg-[hsl(35_90%_50%)/0.1] text-[hsl(35_90%_35%)] border-[hsl(35_90%_50%)/0.2]',
    danger: 'bg-[hsl(4_62%_48%)/0.1] text-[hsl(4_62%_48%)] border-[hsl(4_62%_48%)/0.2]',
    info: 'bg-[hsl(202_89%_53%)/0.1] text-[hsl(202_89%_45%)] border-[hsl(202_89%_53%)/0.2]',
    neutral: 'bg-[hsl(153_12%_43%)/0.1] text-[hsl(153_12%_43%)] border-[hsl(153_12%_43%)/0.2]',
  };
  return <span className={`inline-flex items-center px-2 py-0.5 rounded border text-[11px] font-bold ${styles[variant]}`}>{children}</span>;
}

export function AdminActionDialog({
  trigger,
  title,
  description,
  confirmText,
  confirmVariant = 'primary',
  onConfirm,
  requireReason = false,
}: {
  trigger: ReactNode;
  title: string;
  description: string;
  confirmText?: string;
  confirmVariant?: 'primary' | 'danger';
  onConfirm: (reason?: string) => Promise<void> | void;
  requireReason?: boolean;
}) {
  const [open, setOpen] = useState(false);
  const [loading, setLoading] = useState(false);
  const [reason, setReason] = useState('');
  const { toast } = useToast();
  const { language, meta, t } = useLanguage();

  const handleConfirm = async () => {
    if (requireReason && !reason.trim()) {
       toast({ title: t('reasonRequired'), variant: 'destructive' });
      return;
    }
    setLoading(true);
    try {
      await onConfirm(reason);
      setOpen(false);
      setReason('');
    } catch (err: any) {
       toast({ title: t('error'), description: err.message, variant: 'destructive' });
    } finally {
      setLoading(false);
    }
  };

  return (
    <DialogPrimitive.Root open={open} onOpenChange={setOpen}>
      <DialogPrimitive.Trigger asChild>{trigger}</DialogPrimitive.Trigger>
      <DialogPrimitive.Portal>
        <DialogPrimitive.Overlay className="fixed inset-0 z-50 bg-black/60 backdrop-blur-sm transition-opacity" />
        <DialogPrimitive.Content className="fixed left-[50%] top-[50%] z-50 grid w-full max-w-lg translate-x-[-50%] translate-y-[-50%] gap-5 bg-white border border-[hsl(38_22%_86%)] p-6 shadow-2xl sm:rounded-2xl" dir={meta[language].dir}>
          <div>
            <DialogPrimitive.Title className="text-xl font-bold text-[hsl(155_33%_23%)]">{title}</DialogPrimitive.Title>
            <DialogPrimitive.Description className="mt-2 text-sm text-[hsl(153_12%_43%)] leading-relaxed">
              {description}
            </DialogPrimitive.Description>
          </div>
          
          {requireReason && (
            <div className="space-y-2">
               <label className="text-xs font-bold text-[hsl(154_26%_15%)]">{t('reasonLabel')}</label>
              <textarea 
                value={reason} 
                onChange={(e) => setReason(e.target.value)}
                className="w-full p-3 bg-[hsl(42_37%_97%)] border border-[hsl(38_22%_86%)] rounded-xl text-sm focus:border-[hsl(155_33%_23%)] focus:ring-1 focus:ring-[hsl(155_33%_23%)] outline-none min-h-[100px] resize-none"
                 placeholder={t('reasonPlaceholder')}
              />
            </div>
          )}
          
          <div className="flex gap-3 justify-end mt-2">
            <DialogPrimitive.Close asChild>
               <button className="px-5 py-2.5 rounded-xl border border-[hsl(38_22%_86%)] text-sm font-bold text-[hsl(153_12%_43%)] hover:bg-[hsl(42_37%_97%)]">{t('cancel')}</button>
            </DialogPrimitive.Close>
            <button 
              onClick={handleConfirm}
              disabled={loading}
              className={`flex items-center justify-center min-w-[100px] px-5 py-2.5 rounded-xl text-sm font-bold text-white transition-transform active:scale-95 ${
                confirmVariant === 'danger' ? 'bg-[hsl(4_62%_48%)] hover:bg-[hsl(4_62%_42%)]' : 'bg-[hsl(155_33%_23%)] hover:bg-[hsl(155_33%_18%)]'
              } disabled:opacity-50`}
            >
              {loading ? <Loader2 size={18} className="animate-spin" /> : confirmText ?? t('confirm')}
            </button>
          </div>
        </DialogPrimitive.Content>
      </DialogPrimitive.Portal>
    </DialogPrimitive.Root>
  );
}

export function AdminGuard({ children }: { children: ReactNode }) {
  const { isLoaded, userId } = useAuth();
  const [, setLocation] = useLocation();
  const { data: me, isLoading } = useAdminMe();
  const { t } = useLanguage();

  useEffect(() => {
    if (isLoaded && !userId) setLocation('/admin/login');
  }, [isLoaded, userId, setLocation]);

  if (!isLoaded || (isLoaded && userId && isLoading)) {
    return (
      <div className="min-h-screen bg-[hsl(42_37%_96%)] flex items-center justify-center">
        <Loader2 className="animate-spin text-[hsl(155_33%_23%)]" size={32} />
      </div>
    );
  }

  if (isLoaded && !userId) {
    return null;
  }

  if (me && (me.role === 'admin' || me.role === 'moderator')) {
    return <AdminAppShell>{children}</AdminAppShell>;
  }

  return (
    <div className="min-h-screen bg-[hsl(42_37%_96%)] flex items-center justify-center p-4">
      <div className="max-w-md w-full bg-white border border-[hsl(4_62%_48%)/0.3] p-8 rounded-2xl shadow-xl text-center">
        <div className="w-16 h-16 bg-[hsl(4_62%_48%)/0.1] text-[hsl(4_62%_48%)] rounded-full flex items-center justify-center mx-auto mb-5">
          <AlertTriangle size={32} strokeWidth={2.5} />
        </div>
        <h1 className="text-xl font-bold text-[hsl(154_26%_15%)] mb-2">{t('insufficientPermissions')}</h1>
        <p className="text-sm text-[hsl(153_12%_43%)] mb-6 leading-relaxed">
          {t('insufficientPermissionsDescription')}
        </p>
        <Link href="/" className="inline-flex items-center gap-2 px-6 py-3 bg-[hsl(155_33%_23%)] text-white text-sm font-bold rounded-xl hover:bg-[hsl(155_33%_18%)]">
          {t('returnToMarket')} <ChevronRight size={16} />
        </Link>
      </div>
    </div>
  );
}

export function Pagination({ page, limit, total, onPageChange }: { page: number; limit: number; total: number; onPageChange: (p: number) => void }) {
  const { t } = useLanguage();
  const totalPages = Math.ceil(total / limit);
  if (totalPages <= 1) return null;
  
  return (
    <div className="flex items-center justify-between border-t border-[hsl(38_22%_86%)] px-6 py-4 bg-white">
      <p className="text-xs text-[hsl(153_12%_43%)]">
        {t('showing', { from: Math.min((page - 1) * limit + 1, total), to: Math.min(page * limit, total), total })}
      </p>
      <div className="flex gap-1">
        <button 
          onClick={() => onPageChange(page - 1)} 
          disabled={page === 1}
          className="px-3 py-1.5 border border-[hsl(38_22%_86%)] rounded-lg text-xs font-bold disabled:opacity-40 hover:bg-[hsl(42_37%_97%)]"
        >
          {t('previous')}
        </button>
        <button 
          onClick={() => onPageChange(page + 1)} 
          disabled={page === totalPages}
          className="px-3 py-1.5 border border-[hsl(38_22%_86%)] rounded-lg text-xs font-bold disabled:opacity-40 hover:bg-[hsl(42_37%_97%)]"
        >
          {t('next')}
        </button>
      </div>
    </div>
  );
}

export function FilterInput({ value, onChange, placeholder }: { value: string; onChange: (v: string) => void; placeholder: string }) {
  const { language } = useLanguage();
  const isRtl = language === 'ar';
  return (
    <div className="relative">
      <Search size={16} className={`absolute top-1/2 -translate-y-1/2 text-[hsl(153_12%_43%)] ${isRtl ? 'right-3' : 'left-3'}`} />
      <input 
        type="text" 
        value={value}
        onChange={(e) => onChange(e.target.value)}
        placeholder={placeholder}
        className={`w-full md:w-80 py-2 bg-white border border-[hsl(38_22%_86%)] rounded-xl text-sm text-[#000000] focus:text-[#000000] placeholder:text-[#6b7280] focus:border-[hsl(155_33%_23%)] focus:ring-1 focus:ring-[hsl(155_33%_23%)] outline-none ${isRtl ? 'pl-4 pr-10' : 'pl-10 pr-4'}`}
      />
    </div>
  );
}

export function FilterSelect({ value, onChange, options }: { value: string; onChange: (v: string) => void; options: { label: string; value: string }[] }) {
  const { language } = useLanguage();
  const isRtl = language === 'ar';
  return (
    <div className="relative">
      <Filter size={14} className={`absolute top-1/2 -translate-y-1/2 text-[hsl(153_12%_43%)] pointer-events-none ${isRtl ? 'right-3' : 'left-3'}`} />
      <select 
        value={value}
        onChange={(e) => onChange(e.target.value)}
        className={`w-full md:w-48 py-2 bg-white border border-[hsl(38_22%_86%)] rounded-xl text-sm focus:border-[hsl(155_33%_23%)] focus:ring-1 focus:ring-[hsl(155_33%_23%)] outline-none appearance-none ${isRtl ? 'pl-4 pr-9' : 'pl-9 pr-4'}`}
      >
        {options.map((opt) => (
          <option key={opt.value} value={opt.value}>{opt.label}</option>
        ))}
      </select>
    </div>
  );
}
