import { useState, type FormEvent } from 'react';
import { AuthenticateWithRedirectCallback, useSignUp } from '@clerk/react';
import { Eye, EyeOff, Loader2 } from 'lucide-react';
import { Link } from 'wouter';
import { useLanguage } from '@/lib/language';

type ClerkError = { errors?: Array<{ longMessage?: string; message?: string }> };

function errorMessage(error: unknown, fallback: string) {
  const clerkError = error as ClerkError;
  return clerkError.errors?.[0]?.longMessage || clerkError.errors?.[0]?.message || fallback;
}

export function RequiredNameSignUp({ basePath }: { basePath: string }) {
  const { signUp, fetchStatus } = useSignUp();
  const { t } = useLanguage();
  const [firstName, setFirstName] = useState('');
  const [lastName, setLastName] = useState('');
  const [emailAddress, setEmailAddress] = useState('');
  const [password, setPassword] = useState('');
  const [code, setCode] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [isVerifying, setIsVerifying] = useState(false);
  const [error, setError] = useState('');

  if (window.location.pathname.includes('/sign-up/sso-callback')) {
    return <AuthenticateWithRedirectCallback />;
  }

  const validateNames = () => {
    if (!firstName.trim() || !lastName.trim()) {
      setError(t('signUpNameRequired'));
      return false;
    }
    return true;
  };

  const handleEmailSignUp = async (event: FormEvent) => {
    event.preventDefault();
    if (!signUp || !validateNames()) return;
    setError('');
    setIsSubmitting(true);
    try {
      const { error: signUpError } = await signUp.password({
        emailAddress: emailAddress.trim(),
        password,
        unsafeMetadata: {
          firstName: firstName.trim(),
          lastName: lastName.trim(),
        },
      });
      if (signUpError) throw signUpError;
      const { error: verificationError } = await signUp.verifications.sendEmailCode();
      if (verificationError) throw verificationError;
      setIsVerifying(true);
    } catch (caught) {
      setError(errorMessage(caught, t('signUpError')));
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleVerification = async (event: FormEvent) => {
    event.preventDefault();
    if (!signUp) return;
    setError('');
    setIsSubmitting(true);
    try {
      const { error: verificationError } = await signUp.verifications.verifyEmailCode({ code: code.trim() });
      if (verificationError) throw verificationError;
      const { error: finalizeError } = await signUp.finalize();
      if (finalizeError) throw finalizeError;
    } catch (caught) {
      setError(errorMessage(caught, t('signUpVerificationError')));
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleGoogleSignUp = async () => {
    if (!signUp || !validateNames()) return;
    setError('');
    setIsSubmitting(true);
    try {
      const { error: ssoError } = await signUp.sso({
        strategy: 'oauth_google',
        redirectUrl: basePath || '/',
        redirectCallbackUrl: `${basePath}/sign-up/sso-callback`,
        unsafeMetadata: {
          firstName: firstName.trim(),
          lastName: lastName.trim(),
        },
      });
      if (ssoError) throw ssoError;
    } catch (caught) {
      setError(errorMessage(caught, t('signUpError')));
      setIsSubmitting(false);
    }
  };

  const inputClass = 'w-full rounded-xl border border-[#d9dfd7] bg-white px-3.5 py-3 text-sm text-[#173d32] outline-none transition focus:border-[#1f5948] focus:ring-2 focus:ring-[#1f5948]/15';
  const labelClass = 'mb-1.5 block text-xs font-bold text-[#173d32]';

  return (
    <section className="my-20 w-[440px] max-w-full overflow-hidden rounded-2xl bg-[#f8f6ef] p-8" data-testid="custom-sign-up">
      <img src={`${basePath}/logo.svg`} alt={t('brand')} className="mx-auto mb-4 h-12 rounded-xl" />
      <h1 className="text-center text-xl font-bold text-[#173d32]">{isVerifying ? t('verifyEmailTitle') : t('createAccount')}</h1>
      <p className="mt-1 text-center text-sm text-[#6f7f77]">{isVerifying ? t('verifyEmailDescription') : t('createAccountDescription')}</p>

      {error && <div role="alert" className="mt-5 rounded-xl border border-[#f0c6bf] bg-[#fff6f3] px-3 py-2.5 text-xs text-[#b94b3e]">{error}</div>}

      {isVerifying ? (
        <form onSubmit={handleVerification} className="mt-6 space-y-4">
          <label>
            <span className={labelClass}>{t('verificationCode')}</span>
            <input value={code} onChange={(event) => setCode(event.target.value)} className={inputClass} inputMode="numeric" autoComplete="one-time-code" required data-testid="input-verification-code" />
          </label>
          <button type="submit" disabled={isSubmitting} className="flex w-full items-center justify-center gap-2 rounded-xl bg-[#1f5948] px-4 py-3 text-sm font-bold text-white transition hover:bg-[#174536] disabled:opacity-60" data-testid="button-verify-email">
            {isSubmitting && <Loader2 size={16} className="animate-spin" />}{t('verifyAndContinue')}
          </button>
        </form>
      ) : (
        <>
          <form onSubmit={handleEmailSignUp} className="mt-6 space-y-4">
            <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
              <label>
                <span className={labelClass}>{t('firstName')}</span>
                <input value={firstName} onChange={(event) => setFirstName(event.target.value)} className={inputClass} autoComplete="given-name" required data-testid="input-first-name" />
              </label>
              <label>
                <span className={labelClass}>{t('lastName')}</span>
                <input value={lastName} onChange={(event) => setLastName(event.target.value)} className={inputClass} autoComplete="family-name" required data-testid="input-last-name" />
              </label>
            </div>
            <label>
              <span className={labelClass}>{t('emailAddress')}</span>
              <input type="email" value={emailAddress} onChange={(event) => setEmailAddress(event.target.value)} className={inputClass} autoComplete="email" required data-testid="input-sign-up-email" />
            </label>
            <label>
              <span className={labelClass}>{t('password')}</span>
              <span className="relative block">
                <input type={showPassword ? 'text' : 'password'} value={password} onChange={(event) => setPassword(event.target.value)} className={`${inputClass} pe-11`} autoComplete="new-password" required minLength={8} data-testid="input-sign-up-password" />
                <button type="button" onClick={() => setShowPassword((value) => !value)} className="absolute inset-y-0 end-0 flex w-11 items-center justify-center text-[#6f7f77]" aria-label={t(showPassword ? 'hidePassword' : 'showPassword')}>
                  {showPassword ? <EyeOff size={17} /> : <Eye size={17} />}
                </button>
              </span>
            </label>
            <button type="submit" disabled={isSubmitting || fetchStatus === 'fetching'} className="flex w-full items-center justify-center gap-2 rounded-xl bg-[#1f5948] px-4 py-3 text-sm font-bold text-white transition hover:bg-[#174536] disabled:opacity-60" data-testid="button-create-account">
              {isSubmitting && <Loader2 size={16} className="animate-spin" />}{t('continue')}
            </button>
          </form>
          <div className="my-5 flex items-center gap-3 text-xs text-[#6f7f77]"><span className="h-px flex-1 bg-[#d9dfd7]" /><span>{t('or')}</span><span className="h-px flex-1 bg-[#d9dfd7]" /></div>
          <button type="button" onClick={handleGoogleSignUp} disabled={isSubmitting} className="flex w-full items-center justify-center gap-3 rounded-xl border border-[#d9dfd7] bg-white px-4 py-3 text-sm font-semibold text-[#173d32] disabled:opacity-60" data-testid="button-google-sign-up">
            <span className="text-base font-bold text-[#4285f4]">G</span>{t('continueWithGoogle')}
          </button>
        </>
      )}

      <p className="mt-6 text-center text-xs text-[#6f7f77]">{t('alreadyHaveAccount')} <Link href="/sign-in" className="font-bold text-[#1f5948]">{t('signIn')}</Link></p>
    </section>
  );
}