import { useState } from 'react';
import { Show, useClerk, useUser } from '@clerk/react';
import { Link, useLocation } from 'wouter';
import {
  ArrowLeft,
  ArrowUpRight,
  Bell,
  Bookmark,
  Check,
  ChevronLeft,
  ChevronRight,
  CircleUserRound,
  CreditCard,
  FileText,
  Gauge,
  LayoutDashboard,
  Leaf,
  LandPlot,
  Loader2,
  LogOut,
  Mail,
  Menu,
  MapPin,
  MessageCircle,
  Package,
  Plus,
  FlaskConical,
  Search,
  Settings,
  ShieldCheck,
  SlidersHorizontal,
  ShoppingBasket,
  Sprout,
  Tractor,
  UserRound,
  Users,
  Wrench,
  X,
} from 'lucide-react';
import type { Listing } from '@workspace/api-client-react';
import { useLanguage, type MarketplaceLanguage } from '@/lib/language';

export const iconForCategory = (category: string | { slug: string; name?: string; nameFr?: string; nameEn?: string }) => {
  const searchText = (typeof category === 'string'
    ? category
    : [category.slug, category.name, category.nameFr, category.nameEn].filter(Boolean).join(' ')
  ).toLocaleLowerCase();

  if (/part|spare|pi[eè]ce|قطع|غيار/.test(searchText)) return Wrench;
  if (/tractor|machin|معدات|آليات|جرار|حاصدة|محراث|بذارة/.test(searchText)) return Tractor;
  if (/seed|semenc|بذر|بذور/.test(searchText)) return Sprout;
  if (/land|terrain|اراضي|أراضي|ارض|أرض/.test(searchText)) return LandPlot;
  if (/fertili|engrais|سماد|أسمدة/.test(searchText)) return FlaskConical;
  if (/product|produit|منتج|تسويق/.test(searchText)) return ShoppingBasket;
  if (/service|ressource|human|خدم|موارد|بشر/.test(searchText)) return Users;
  if (/farm|مزر/.test(searchText)) return MapPin;
  return Leaf;
};

export const formatPrice = (price: number, currency = 'MRU', language: MarketplaceLanguage = 'ar') =>
  new Intl.NumberFormat(language === 'ar' ? 'ar-MR-u-nu-latn' : language === 'fr' ? 'fr-MR-u-nu-latn' : 'en-MR-u-nu-latn', { style: 'currency', currency, currencyDisplay: 'name', maximumFractionDigits: 0 }).format(price);

export const relativeDate = (value: string, language: MarketplaceLanguage = 'ar') => {
  const locale = language === 'ar' ? 'ar-MR-u-nu-latn' : language === 'fr' ? 'fr-MR-u-nu-latn' : 'en-MR-u-nu-latn';
  const days = Math.max(0, Math.floor((Date.now() - new Date(value).getTime()) / 86400000));
  if (days < 7) return new Intl.RelativeTimeFormat(locale, { numeric: 'auto' }).format(-days, 'day');
  return new Intl.DateTimeFormat(locale, { day: 'numeric', month: 'short' }).format(new Date(value));
};

export function Logo({ compact = false }: { compact?: boolean }) {
  const { t } = useLanguage();
  return (
    <Link href="/" className="flex items-center gap-3 group" data-testid="link-logo">
      <span className="flex h-11 w-11 shrink-0 items-center justify-center rounded-[14px] bg-[hsl(var(--accent))] text-[hsl(var(--primary))] shadow-[0_7px_0_hsl(155_33%_16%/.12)] transition-transform group-hover:-rotate-6">
        <Leaf size={23} strokeWidth={2.2} />
      </span>
      {!compact && (
        <span className="leading-none">
          <strong className="block text-[18px] font-bold tracking-tight text-[hsl(var(--sidebar-foreground))]">{t('brand')}</strong>
          <small className="mt-1 block text-[10px] font-medium tracking-[.08em] text-[hsl(var(--sidebar-foreground)/.55)]">{t('tagline')}</small>
        </span>
      )}
    </Link>
  );
}

const navItems = [
  { href: '/', label: 'discover', icon: LayoutDashboard },
  { href: '/listings', label: 'allListings', icon: Search },
  { href: '/categories', label: 'categories', icon: Package },
  { href: '/saved', label: 'saved', icon: Bookmark },
  { href: '/messages', label: 'messages', icon: MessageCircle },
  { href: '/notifications', label: 'notifications', icon: Bell },
  { href: '/payments', label: 'myPayments', icon: CreditCard },
  { href: '/dashboard', label: 'sellerDashboard', icon: Gauge },
] as const;

export function AppShell({ children }: { children: React.ReactNode }) {
  const [location] = useLocation();
  const [open, setOpen] = useState(false);
  const { language, setLanguage, meta, t } = useLanguage();
  const { signOut } = useClerk();
  const { user } = useUser();
  const [isSigningOut, setIsSigningOut] = useState(false);
  const metadataFirstName = typeof user?.unsafeMetadata?.firstName === 'string' ? user.unsafeMetadata.firstName : '';
  const metadataLastName = typeof user?.unsafeMetadata?.lastName === 'string' ? user.unsafeMetadata.lastName : '';
  const metadataName = `${metadataFirstName} ${metadataLastName}`.trim();
  const displayName = user?.fullName || metadataName || user?.firstName || t('user');
  const initial = displayName.trim().charAt(0) || t('user').charAt(0);

  const handleSignOut = async () => {
    if (isSigningOut) return;
    setIsSigningOut(true);
    try {
      await signOut({ redirectUrl: `${import.meta.env.BASE_URL.replace(/\/$/, '')}/sign-in` });
    } finally {
      setIsSigningOut(false);
    }
  };
  return (
    <div dir={meta[language].dir} className="grain min-h-[100dvh] bg-[hsl(var(--background))] text-[hsl(var(--foreground))]">
      <aside className={`fixed inset-y-0 ${language === 'ar' ? 'right-0' : 'left-0'} z-40 flex w-[278px] flex-col overflow-y-auto bg-[hsl(var(--sidebar))] px-5 py-6 text-[hsl(var(--sidebar-foreground))] transition-transform duration-300 lg:translate-x-0 ${open ? 'translate-x-0' : language === 'ar' ? 'translate-x-full' : '-translate-x-full'}`}>
        <div className="mb-12 flex items-center justify-between">
          <Logo />
          <button type="button" onClick={() => setOpen(false)} className="rounded-lg p-2 text-white/55 hover:bg-white/10 hover:text-white lg:hidden" aria-label={t('closeMenu')} data-testid="button-close-menu"><X size={19} /></button>
        </div>
        <nav className="space-y-1" aria-label={t('mainNavigation')}>
          <span className="mb-3 block px-3 text-[10px] font-bold tracking-[.16em] text-white/35">{t('mainArea')}</span>
          {navItems.map((item) => {
            const active = item.href === '/' ? location === '/' : location.startsWith(item.href);
            const Icon = item.icon;
            return (
              <Link key={item.href} href={item.href} onClick={() => setOpen(false)} className={`group flex items-center gap-3 rounded-xl px-3 py-3 text-[14px] font-semibold transition-all ${active ? 'bg-[hsl(var(--sidebar-accent))] text-[hsl(var(--accent))] shadow-[inset_-3px_0_0_hsl(var(--accent))]' : 'text-white/62 hover:bg-white/[.06] hover:text-white'}`} data-testid={`link-nav-${item.label}`}>
                <Icon size={18} strokeWidth={active ? 2.4 : 1.8} />
                <span>{t(item.label)}</span>
                {item.href === '/messages' && <span className="mr-auto h-2 w-2 rounded-full bg-[hsl(var(--accent))]" />}
              </Link>
            );
          })}
        </nav>
        <div className="mt-auto">
          <div className="mb-5 rounded-2xl border border-white/10 bg-white/[.05] p-4">
            <div className="mb-3 flex items-center gap-2 text-[hsl(var(--accent))]"><ShieldCheck size={16} /><span className="text-xs font-bold">{t('trustedTrade')}</span></div>
            <p className="text-[11px] leading-6 text-white/55">{t('trustedTradeDescription')}</p>
          </div>
          <Show when="signed-in">
            <div className="border-t border-white/10 pt-4">
              <Link href="/account" className="flex items-center gap-3" data-testid="link-account-sidebar">
                <span className="flex h-9 w-9 items-center justify-center rounded-full bg-[hsl(var(--secondary))] text-sm font-bold text-[hsl(var(--primary))]">{initial}</span>
                <span className="min-w-0 flex-1"><strong className="block truncate text-xs">{displayName}</strong><small className="text-[10px] text-white/42">{t('registeredAccount')}</small></span>
                <ChevronLeft size={16} className="text-white/35" />
              </Link>
              <button type="button" onClick={handleSignOut} disabled={isSigningOut} className="mt-3 flex w-full items-center gap-2 rounded-xl px-3 py-2 text-xs font-bold text-red-200 transition hover:bg-white/[.06]" data-testid="button-sidebar-sign-out">
                {isSigningOut ? <Loader2 size={15} className="animate-spin" /> : <LogOut size={15} />}
                {isSigningOut ? t('signingOut') : t('signOut')}
              </button>
            </div>
          </Show>
          <Show when="signed-out">
            <Link href="/sign-in" className="flex items-center justify-center rounded-xl border border-white/15 px-3 py-2.5 text-xs font-bold text-white" data-testid="link-sidebar-sign-in">{t('signIn')}</Link>
          </Show>
        </div>
      </aside>
      {open && <button type="button" onClick={() => setOpen(false)} aria-label={t('closeMenu')} className="fixed inset-0 z-30 bg-[hsl(var(--primary)/.42)] backdrop-blur-sm lg:hidden" data-testid="button-overlay-menu" />}
      <div className={language === 'ar' ? 'lg:mr-[278px]' : 'lg:ml-[278px]'}>
        <header className="sticky top-0 z-20 border-b border-[hsl(var(--border)/.7)] bg-[hsl(var(--background)/.9)] px-4 py-3 backdrop-blur-md sm:px-7 lg:px-10">
          <div className="mx-auto flex max-w-[1420px] items-center gap-3">
            <button type="button" onClick={() => setOpen(true)} className="rounded-xl border border-[hsl(var(--border))] p-2.5 text-[hsl(var(--primary))] lg:hidden" aria-label={t('openMenu')} data-testid="button-open-menu"><Menu size={20} /></button>
             <div className={`hidden sm:block ${language === 'ar' ? 'text-right' : 'text-left'}`}><p className="text-[11px] font-semibold text-[hsl(var(--muted-foreground))]">{t('goodMorning', { name: displayName })}</p><p className="text-sm font-bold">{t('whatLookingFor')}</p></div>
            <div className="mr-auto flex items-center gap-2">
              <select value={language} onChange={(event) => setLanguage(event.target.value as 'ar' | 'fr' | 'en')} className="block rounded-xl border border-[hsl(var(--border))] bg-[hsl(var(--card))] px-2 py-2 text-[10px] font-bold text-[hsl(var(--primary))] outline-none transition-colors hover:bg-[hsl(var(--secondary))]" aria-label={t('language')} data-testid="select-language">
                <option value="ar">العربية</option>
                <option value="fr">FR</option>
                <option value="en">EN</option>
              </select>
              <Show when="signed-out">
                <Link href="/sign-in" className="rounded-xl border border-[hsl(var(--border))] px-3 py-2 text-xs font-bold text-[hsl(var(--primary))] transition-colors hover:bg-[hsl(var(--secondary))]" data-testid="link-header-sign-in">{t('signIn')}</Link>
              </Show>
              <Show when="signed-in">
                <Link href="/messages" className="relative rounded-xl border border-[hsl(var(--border))] p-2.5 text-[hsl(var(--primary))] transition-colors hover:bg-[hsl(var(--secondary))]" aria-label={t('messages')} data-testid="link-header-messages"><Bell size={18} /><span className="absolute right-1 top-1 h-1.5 w-1.5 rounded-full bg-[hsl(var(--accent-foreground))]" /></Link>
                <Link href="/add-listing" className="hidden items-center gap-2 rounded-xl bg-[hsl(var(--primary))] px-4 py-2.5 text-xs font-bold text-[hsl(var(--primary-foreground))] shadow-[0_5px_0_hsl(155_33%_16%/.16)] transition-all hover:-translate-y-0.5 sm:flex" data-testid="link-header-add"><Plus size={16} />{t('addListing')}</Link>
                <Link href="/account" className="flex h-9 w-9 items-center justify-center rounded-full bg-[hsl(var(--accent))] text-xs font-bold text-[hsl(var(--primary))]" aria-label={t('account')} data-testid="link-header-account">{initial}</Link>
                <button type="button" onClick={handleSignOut} disabled={isSigningOut} className="rounded-xl border border-[hsl(var(--border))] p-2.5 text-[hsl(var(--destructive))] transition-colors hover:bg-[hsl(var(--destructive)/.08)]" aria-label={t('signOut')} data-testid="button-header-sign-out">
                  {isSigningOut ? <Loader2 size={18} className="animate-spin" /> : <LogOut size={18} />}
                </button>
              </Show>
            </div>
          </div>
        </header>
        <main className="mx-auto max-w-[1420px] px-4 py-6 sm:px-7 sm:py-8 lg:px-10 lg:py-10">{children}</main>
      </div>
      <Show when="signed-in"><Link href="/messages" className="fixed bottom-20 left-4 z-20 inline-flex items-center gap-1.5 rounded-full border border-[hsl(var(--primary)/.18)] bg-[hsl(var(--card)/.96)] px-3 py-2 text-xs font-bold text-[hsl(var(--primary))] shadow-[0_7px_20px_hsl(155_20%_18%/.14)] backdrop-blur-sm transition-colors hover:bg-[hsl(var(--secondary))] sm:bottom-5 sm:left-5" aria-label={t('support')} data-testid="link-floating-support"><MessageCircle size={15} />{t('support')}</Link><Link href="/add-listing" className="fixed bottom-5 left-5 z-20 flex h-12 w-12 items-center justify-center rounded-full bg-[hsl(var(--accent))] text-[hsl(var(--primary))] shadow-[0_8px_22px_hsl(42_87%_45%/.28)] sm:hidden" aria-label={t('addListing')} data-testid="link-mobile-add"><Plus size={22} /></Link></Show>
    </div>
  );
}

export function PageHeading({ eyebrow, title, description, action }: { eyebrow?: string; title: string; description?: string; action?: React.ReactNode }) {
  return <div className="mb-7 flex flex-col justify-between gap-4 sm:flex-row sm:items-end"><div><span className="mb-2 block text-[11px] font-bold tracking-[.18em] text-[hsl(var(--muted-foreground))]">{eyebrow}</span><h1 className="text-2xl font-bold tracking-tight text-[hsl(var(--primary))] sm:text-3xl">{title}</h1>{description && <p className="mt-2 max-w-2xl text-sm leading-7 text-[hsl(var(--muted-foreground))]">{description}</p>}</div>{action}</div>;
}

export function ListingCard({ listing, onSave, featured = false, iconSize = 32 }: { listing: Listing; onSave?: (listing: Listing) => void; featured?: boolean; iconSize?: 24 | 32 }) {
  const [saved, setSaved] = useState(Boolean(listing.isSaved));
  const { language, t } = useLanguage();
  const image = listing.imageUrl || listing.images?.[0];
  const isFeatured = featured || listing.featured;
  const iconBoxClass = iconSize === 24 ? 'h-6 w-6' : 'h-8 w-8';
  const listingHref = `/listings/${listing.id}`;
  return (
    <article className={`group h-full overflow-hidden rounded-2xl border border-[hsl(var(--card-border))] bg-[hsl(var(--card))] shadow-[0_5px_18px_hsl(155_20%_18%/.045)] transition-all duration-300 hover:-translate-y-1 hover:shadow-[0_13px_28px_hsl(155_20%_18%/.11)] ${isFeatured ? 'ring-2 ring-[hsl(var(--accent)/.55)] shadow-[0_8px_24px_hsl(42_87%_45%/.14)]' : ''}`} data-testid={`card-listing-${listing.id}`}>
      <div className="flex h-full min-h-[112px] items-start gap-3 p-3">
        <Link href={listingHref} className="relative h-10 w-10 shrink-0 overflow-hidden rounded-xl bg-[hsl(var(--secondary))]" aria-label={listing.title}>
          {image ? <img src={image} alt={listing.title} className="h-10 w-10 object-cover transition-transform duration-300 group-hover:scale-105" data-testid={`img-listing-${listing.id}`} /> : <div className="flex h-10 w-10 items-center justify-center bg-[linear-gradient(135deg,hsl(155_33%_23%),hsl(153_26%_34%))] text-[hsl(var(--accent))]"><Tractor size={40} strokeWidth={1.1} /></div>}
        </Link>
        <div className="min-w-0 flex-1">
          <div className="flex items-start gap-2">
            <Link href={listingHref} className="min-w-0 flex-1" data-testid={`link-listing-${listing.id}`}>
              <div className="mb-1 flex min-w-0 items-center gap-1.5">
                {isFeatured ? <span className="shrink-0 rounded-md bg-[hsl(var(--accent))] px-1.5 py-0.5 text-[9px] font-bold leading-4 text-[hsl(var(--primary))]">{t('featuredChoice')}</span> : null}
                <span className="truncate text-[10px] font-medium text-[hsl(var(--muted-foreground))]">{listing.category}</span>
              </div>
              <h3 className="line-clamp-2 h-10 text-[14px] font-bold leading-5 text-[hsl(var(--primary))]">{listing.title}</h3>
              <div className="mt-1 flex items-center justify-between gap-2">
                <strong className="shrink-0 font-numeric text-[13px] font-extrabold text-[hsl(var(--primary))]" dir="ltr">{formatPrice(listing.price, listing.currency, language)}</strong>
                <span className="flex min-w-0 items-center gap-2 text-[10px] text-[hsl(var(--muted-foreground))]"><span className={`flex ${iconBoxClass} shrink-0 items-center justify-center`}><MapPin size={iconSize === 24 ? 24 : 16} /></span><span className="truncate">{listing.location}</span></span>
              </div>
            </Link>
            <button type="button" onClick={() => { setSaved(!saved); onSave?.(listing); }} className={`flex ${iconBoxClass} shrink-0 items-center justify-center rounded-full p-0 backdrop-blur-md transition-all ${saved ? 'bg-[hsl(var(--accent))] text-[hsl(var(--primary))]' : 'bg-[hsl(var(--primary)/.72)] text-white hover:bg-[hsl(var(--primary))]'}`} aria-label={saved ? t('removeSaved') : t('saveListing')} data-testid={`button-save-${listing.id}`}><Bookmark size={16} fill={saved ? 'currentColor' : 'none'} /></button>
          </div>
        </div>
      </div>
    </article>
  );
}

export function ListingSkeleton({ count = 4 }: { count?: number }) {
  return <div className="grid grid-cols-1 gap-5 sm:grid-cols-2 xl:grid-cols-4">{Array.from({ length: count }).map((_, i) => <div key={i} className="flex min-h-[112px] animate-pulse items-start gap-3 overflow-hidden rounded-2xl border border-[hsl(var(--border))] bg-[hsl(var(--card))] p-3"><div className="h-10 w-10 shrink-0 rounded-xl bg-[hsl(var(--muted))]" /><div className="min-w-0 flex-1 space-y-2"><div className="h-2.5 w-1/3 rounded bg-[hsl(var(--muted))]" /><div className="h-4 w-5/6 rounded bg-[hsl(var(--muted))]" /><div className="h-3 w-1/2 rounded bg-[hsl(var(--muted))]" /></div></div>)}</div>;
}

export function EmptyState({ icon: Icon = Package, title, description, action }: { icon?: typeof Package; title: string; description: string; action?: React.ReactNode }) {
  return <div className="flex min-h-[340px] flex-col items-center justify-center rounded-2xl border border-dashed border-[hsl(var(--border))] bg-[hsl(var(--card)/.5)] p-8 text-center"><span className="mb-4 flex h-14 w-14 items-center justify-center rounded-2xl bg-[hsl(var(--secondary))] text-[hsl(var(--primary))]"><Icon size={26} strokeWidth={1.5} /></span><h3 className="text-lg font-bold text-[hsl(var(--primary))]">{title}</h3><p className="mt-2 max-w-sm text-sm leading-6 text-[hsl(var(--muted-foreground))]">{description}</p>{action && <div className="mt-5">{action}</div>}</div>;
}

export function ErrorState({ onRetry, message }: { onRetry?: () => void; message?: string }) {
  const { t } = useLanguage();
  return <div className="flex min-h-[240px] flex-col items-center justify-center rounded-2xl border border-[hsl(var(--destructive)/.2)] bg-[hsl(var(--destructive)/.04)] p-8 text-center"><span className="mb-3 text-sm font-bold text-[hsl(var(--destructive))]">{t('temporaryIssue')}</span><p className="text-sm text-[hsl(var(--muted-foreground))]">{message ?? t('dataLoadError')}</p>{onRetry && <button type="button" onClick={onRetry} className="mt-4 rounded-xl bg-[hsl(var(--primary))] px-4 py-2 text-xs font-bold text-[hsl(var(--primary-foreground))]" data-testid="button-retry">{t('retry')}</button>}</div>;
}

export function StatCard({ label, value, icon: Icon, accent = false, href }: { label: string; value: string | number; icon: typeof Users; accent?: boolean; href?: string }) {
  const content = <div className={`rounded-2xl border p-5 ${accent ? 'border-[hsl(var(--primary))] bg-[hsl(var(--primary))] text-[hsl(var(--primary-foreground))]' : 'border-[hsl(var(--border))] bg-[hsl(var(--card))]'}`}>
    <div className="mb-7 flex items-start justify-between">
      <span className={`rounded-xl p-2.5 ${accent ? 'bg-white/10 text-[hsl(var(--accent))]' : 'bg-[hsl(var(--secondary))] text-[hsl(var(--primary))]'}`}><Icon size={19} /></span>
      <ArrowUpRight size={15} className={accent ? 'text-white/40' : 'text-[hsl(var(--muted-foreground))]'} />
    </div>
    <strong className="font-numeric text-2xl font-extrabold" dir="ltr">{value}</strong>
    <p className={`mt-1 text-xs ${accent ? 'text-white/60' : 'text-[hsl(var(--muted-foreground))]'}`}>{label}</p>
  </div>;

  if (!href) return content;

  return <Link href={href} className="block cursor-pointer rounded-2xl transition-all duration-200 hover:-translate-y-0.5 hover:shadow-[0_10px_24px_hsl(155_20%_18%/.12)] focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[hsl(var(--primary))] focus-visible:ring-offset-2">{content}</Link>;
}

export function SearchBar({ value, onChange, onSubmit, placeholder }: { value: string; onChange: (value: string) => void; onSubmit?: () => void; placeholder?: string }) {
  const { t } = useLanguage();
  return <form onSubmit={(event) => { event.preventDefault(); onSubmit?.(); }} className="flex items-center gap-3 rounded-2xl border border-[hsl(var(--border))] bg-[hsl(var(--card))] p-2 shadow-[0_7px_24px_hsl(155_20%_18%/.05)]"><Search size={19} className="mr-2 text-[hsl(var(--muted-foreground))]" /><input value={value} onChange={(event) => onChange(event.target.value)} placeholder={placeholder ?? t('searchPlaceholder')} className="min-w-0 flex-1 bg-transparent px-1 py-2 text-sm text-[#000000] outline-none focus:text-[#000000] placeholder:text-[#6b7280]" data-testid="input-search" /><button type="submit" className="rounded-xl bg-[hsl(var(--primary))] px-4 py-2.5 text-xs font-bold text-[hsl(var(--primary-foreground))] transition-transform hover:-translate-y-0.5" data-testid="button-submit-search">{t('search')}</button></form>;
}

export function SectionLink({ href, children }: { href: string; children: React.ReactNode }) {
  return <Link href={href} className="flex items-center gap-1 text-xs font-bold text-[hsl(var(--primary))] transition-colors hover:text-[hsl(var(--accent-foreground))]" data-testid={`link-section-${href.replace('/', '') || 'home'}`}>{children}<ChevronLeft size={15} /></Link>;
}