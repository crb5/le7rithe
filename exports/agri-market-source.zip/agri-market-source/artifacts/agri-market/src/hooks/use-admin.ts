import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { useCallback } from 'react';
import { useLanguage } from '@/lib/language';
import {
  getListCategoriesQueryKey,
  getListListingsQueryKey,
  getListLocationsQueryKey,
} from '@workspace/api-client-react';

export function useAdminFetch() {
  const { t } = useLanguage();
  return useCallback(async (path: string, options?: RequestInit) => {
    const res = await fetch(`/api${path}`, {
      ...options,
      credentials: 'same-origin',
      headers: {
        'Content-Type': 'application/json',
        ...options?.headers,
      },
    });
    if (!res.ok) {
      const error = await res.json().catch(() => ({}));
       throw new Error(error.error || t('serverConnectionError'));
    }
    if (res.status === 204) return null;
    return res.json();
  }, [t]);
}

export function useAdminMe() {
  const fetcher = useAdminFetch();
  return useQuery({
    queryKey: ['admin-me'],
    queryFn: () => fetcher('/admin/me'),
  });
}

export function useAdminOverview() {
  const fetcher = useAdminFetch();
  return useQuery({
    queryKey: ['admin-overview'],
    queryFn: () => fetcher('/admin/overview'),
  });
}

export type AdminNotification = {
  id: number;
  listingId: number | null;
  title: string;
  body: string;
  type: string;
  read: boolean;
  createdAt: string;
  listingTitle: string | null;
  sellerName: string | null;
  listingCreatedAt: string;
  listingStatus: string | null;
  paymentStatus: string;
};

export function useAdminNotifications() {
  const fetcher = useAdminFetch();
  return useQuery<{ items: AdminNotification[]; unreadCount: number }>({
    queryKey: ['admin-notifications'],
    queryFn: () => fetcher('/admin/notifications'),
    refetchInterval: 5000,
    refetchOnWindowFocus: true,
  });
}

export function useMarkAdminNotificationRead() {
  const fetcher = useAdminFetch();
  const qc = useQueryClient();
  return useMutation({
    mutationFn: (id: number) =>
      fetcher(`/admin/notifications/${id}/read`, { method: 'PATCH' }),
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ['admin-notifications'] });
    },
  });
}

export function useAdminListings(params: Record<string, string | number>) {
  const fetcher = useAdminFetch();
  const search = new URLSearchParams(params as any).toString();
  return useQuery({
    queryKey: ['admin-listings', search],
    queryFn: () => fetcher(`/admin/listings?${search}`),
  });
}

export function useAdminUsers(params: Record<string, string | number>) {
  const fetcher = useAdminFetch();
  const search = new URLSearchParams(params as any).toString();
  return useQuery({
    queryKey: ['admin-users', search],
    queryFn: () => fetcher(`/admin/users?${search}`),
  });
}

export function useAdminPayments(params: Record<string, string>) {
  const fetcher = useAdminFetch();
  const search = new URLSearchParams(params).toString();
  return useQuery({
    queryKey: ['admin-payments', search],
    queryFn: () => fetcher(`/admin/payments?${search}`),
  });
}

export function useAdminPackages() {
  const fetcher = useAdminFetch();
  return useQuery({
    queryKey: ['admin-packages'],
    queryFn: () => fetcher('/admin/packages'),
  });
}

export function useAdminPaymentMethods() {
  const fetcher = useAdminFetch();
  return useQuery({
    queryKey: ['admin-payment-methods'],
    queryFn: () => fetcher('/admin/payment-methods'),
  });
}

export function useAdminReports() {
  const fetcher = useAdminFetch();
  return useQuery({
    queryKey: ['admin-reports'],
    queryFn: () => fetcher('/admin/reports'),
  });
}

export function useAdminAuditLogs() {
  const fetcher = useAdminFetch();
  return useQuery({
    queryKey: ['admin-audit-logs'],
    queryFn: () => fetcher('/admin/audit-logs'),
  });
}

// Mutations
export function useUpdateListingStatus() {
  const fetcher = useAdminFetch();
  const qc = useQueryClient();
  return useMutation({
    mutationFn: ({ id, status, reason }: { id: number; status: string; reason?: string }) =>
      fetcher(`/admin/listings/${id}/status`, {
        method: 'PATCH',
        body: JSON.stringify({ status, reason }),
      }),
    onSuccess: (_data, variables) => {
      void fetcher(`/admin/notifications/listing/${variables.id}/read`, { method: 'PATCH' });
      qc.invalidateQueries({ queryKey: ['admin-listings'] });
      qc.invalidateQueries({ queryKey: ['admin-overview'] });
      qc.invalidateQueries({ queryKey: ['admin-payments'] });
      qc.invalidateQueries({ queryKey: getListCategoriesQueryKey() });
      qc.invalidateQueries({ queryKey: getListLocationsQueryKey() });
      qc.invalidateQueries({ queryKey: getListListingsQueryKey() });
    },
  });
}

export function useUpdateListingFeatured() {
  const fetcher = useAdminFetch();
  const qc = useQueryClient();
  return useMutation({
    mutationFn: ({ id, featured, pinned }: { id: number; featured: boolean; pinned: boolean }) =>
      fetcher(`/admin/listings/${id}/featured`, {
        method: 'PATCH',
        body: JSON.stringify({ featured, pinned }),
      }),
    onSuccess: () => qc.invalidateQueries({ queryKey: ['admin-listings'] }),
  });
}

export function useDeleteListing() {
  const fetcher = useAdminFetch();
  const qc = useQueryClient();
  return useMutation({
    mutationFn: (id: number) => fetcher(`/admin/listings/${id}`, { method: 'DELETE' }),
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ['admin-listings'] });
      qc.invalidateQueries({ queryKey: ['admin-overview'] });
      qc.invalidateQueries({ queryKey: getListCategoriesQueryKey() });
      qc.invalidateQueries({ queryKey: getListLocationsQueryKey() });
      qc.invalidateQueries({ queryKey: getListListingsQueryKey() });
    },
  });
}

export function useUpdateUserStatus() {
  const fetcher = useAdminFetch();
  const qc = useQueryClient();
  return useMutation({
    mutationFn: ({ id, status }: { id: number; status: string }) =>
      fetcher(`/admin/users/${id}/status`, {
        method: 'PATCH',
        body: JSON.stringify({ status }),
      }),
    onSuccess: () => qc.invalidateQueries({ queryKey: ['admin-users'] }),
  });
}

export function useUpdatePaymentStatus() {
  const fetcher = useAdminFetch();
  const qc = useQueryClient();
  return useMutation({
    mutationFn: ({ id, status, reason }: { id: number; status: string; reason?: string }) =>
      fetcher(`/admin/payments/${id}/status`, {
        method: 'PATCH',
        body: JSON.stringify({ status, reason }),
      }),
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ['admin-payments'] });
      qc.invalidateQueries({ queryKey: ['admin-overview'] });
    },
  });
}

export function useCreatePackage() {
  const fetcher = useAdminFetch();
  const qc = useQueryClient();
  return useMutation({
    mutationFn: (data: any) =>
      fetcher(`/admin/packages`, {
        method: 'POST',
        body: JSON.stringify(data),
      }),
    onSuccess: () => qc.invalidateQueries({ queryKey: ['admin-packages'] }),
  });
}

export function useUpdatePackage() {
  const fetcher = useAdminFetch();
  const qc = useQueryClient();
  return useMutation({
    mutationFn: ({ id, ...data }: any) =>
      fetcher(`/admin/packages/${id}`, {
        method: 'PATCH',
        body: JSON.stringify(data),
      }),
    onSuccess: () => qc.invalidateQueries({ queryKey: ['admin-packages'] }),
  });
}

export function useDeletePackage() {
  const fetcher = useAdminFetch();
  const qc = useQueryClient();
  return useMutation({
    mutationFn: (id: number) => fetcher(`/admin/packages/${id}`, { method: 'DELETE' }),
    onSuccess: () => qc.invalidateQueries({ queryKey: ['admin-packages'] }),
  });
}

export function useCreatePaymentMethod() {
  const fetcher = useAdminFetch();
  const qc = useQueryClient();
  return useMutation({
    mutationFn: (data: any) =>
      fetcher(`/admin/payment-methods`, {
        method: 'POST',
        body: JSON.stringify(data),
      }),
    onSuccess: () => qc.invalidateQueries({ queryKey: ['admin-payment-methods'] }),
  });
}

export function useUpdatePaymentMethod() {
  const fetcher = useAdminFetch();
  const qc = useQueryClient();
  return useMutation({
    mutationFn: ({ id, ...data }: any) =>
      fetcher(`/admin/payment-methods/${id}`, {
        method: 'PATCH',
        body: JSON.stringify(data),
      }),
    onSuccess: () => qc.invalidateQueries({ queryKey: ['admin-payment-methods'] }),
  });
}

export function useDeletePaymentMethod() {
  const fetcher = useAdminFetch();
  const qc = useQueryClient();
  return useMutation({
    mutationFn: (id: number) => fetcher(`/admin/payment-methods/${id}`, { method: 'DELETE' }),
    onSuccess: () => qc.invalidateQueries({ queryKey: ['admin-payment-methods'] }),
  });
}

export function useResolveReport() {
  const fetcher = useAdminFetch();
  const qc = useQueryClient();
  return useMutation({
    mutationFn: ({ id, status, action }: { id: number; status: string; action?: string }) =>
      fetcher(`/admin/reports/${id}`, {
        method: 'PATCH',
        body: JSON.stringify({ status, action }),
      }),
    onSuccess: () => qc.invalidateQueries({ queryKey: ['admin-reports'] }),
  });
}
