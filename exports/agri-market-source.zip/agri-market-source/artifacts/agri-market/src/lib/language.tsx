import { createContext, useContext, useEffect, useMemo, useState, type ReactNode } from 'react';
import ar from '@/locales/ar';
import fr from '@/locales/fr';
import en from '@/locales/en';

export type MarketplaceLanguage = 'ar' | 'fr' | 'en';

const languageMeta: Record<MarketplaceLanguage, { label: string; dir: 'rtl' | 'ltr' }> = {
  ar: { label: 'العربية', dir: 'rtl' },
  fr: { label: 'Français', dir: 'ltr' },
  en: { label: 'English', dir: 'ltr' },
};
const dictionaries = { ar, fr, en } as const;
type TranslationKey = keyof typeof en;
type InterpolationValues = Record<string, string | number>;

const localeByLanguage: Record<MarketplaceLanguage, string> = {
  // ar-MR spells September as "شتمبر" in the runtime's ICU data.
  // Use the standard Arabic locale to keep the correct "سبتمبر" spelling
  // while retaining Western digits through the numbering-system extension.
  ar: 'ar-u-nu-latn',
  fr: 'fr-MR-u-nu-latn',
  en: 'en-MR-u-nu-latn',
};

function interpolate(template: string, values?: InterpolationValues) {
  return template.replace(/\{(\w+)\}/g, (_, key) => {
    const value = values?.[key];
    return typeof value === 'number'
      ? new Intl.NumberFormat('fr-MR-u-nu-latn').format(value)
      : String(value ?? `{${key}}`);
  });
}

const LanguageContext = createContext<{
  language: MarketplaceLanguage;
  setLanguage: (language: MarketplaceLanguage) => void;
  meta: typeof languageMeta;
  t: (key: TranslationKey, values?: InterpolationValues) => string;
  formatNumber: (value: number, options?: Intl.NumberFormatOptions) => string;
  formatDate: (value: string | number | Date, options?: Intl.DateTimeFormatOptions) => string;
}>({
  language: 'ar',
  setLanguage: () => undefined,
  meta: languageMeta,
  t: (key) => en[key],
  formatNumber: (value) => String(value),
  formatDate: (value) => String(value),
});

export function LanguageProvider({ children }: { children: ReactNode }) {
  const [language, setLanguageState] = useState<MarketplaceLanguage>(() => {
    const saved = window.localStorage.getItem('marketplace-language');
    return saved === 'fr' || saved === 'en' ? saved : 'ar';
  });

  const setLanguage = (next: MarketplaceLanguage) => {
    setLanguageState(next);
    window.localStorage.setItem('marketplace-language', next);
  };

  useEffect(() => {
    document.documentElement.lang = language;
    document.documentElement.dir = languageMeta[language].dir;
  }, [language]);

  const value = useMemo(() => {
    const locale = localeByLanguage[language];
    return {
      language,
      setLanguage,
      meta: languageMeta,
      t: (key: TranslationKey, values?: InterpolationValues) => interpolate(dictionaries[language][key], values),
      formatNumber: (number: number, options?: Intl.NumberFormatOptions) => new Intl.NumberFormat(locale, options).format(number),
      formatDate: (date: string | number | Date, options?: Intl.DateTimeFormatOptions) => new Intl.DateTimeFormat(locale, options).format(new Date(date)),
    };
  }, [language]);
  return <LanguageContext.Provider value={value}>{children}</LanguageContext.Provider>;
}

export function useLanguage() {
  return useContext(LanguageContext);
}

export function translatedName(item: { name: string; nameFr?: string | null; nameEn?: string | null }, language: MarketplaceLanguage) {
  return (language === 'fr' ? item.nameFr : language === 'en' ? item.nameEn : item.name) || item.name;
}
