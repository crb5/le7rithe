import { useEffect, useRef, useState, type ReactNode } from 'react';
import { ClerkProvider, SignIn, useAuth, useClerk, useUser } from '@clerk/react';
import { publishableKeyFromHost } from '@clerk/react/internal';
import { arSA, enUS, frFR } from '@clerk/localizations';
import { shadcn } from '@clerk/themes';
import { QueryClient, QueryClientProvider } from '@tanstack/react-query';
import { setAuthTokenGetter } from '@workspace/api-client-react';
import { ErrorBoundary } from '@/components/error-boundary';
import { Toaster } from '@/components/ui/toaster';
import { TooltipProvider } from '@/components/ui/tooltip';
import { LanguageProvider, useLanguage } from '@/lib/language';
import { RequiredNameSignUp } from '@/components/required-name-sign-up';
import NotFound from '@/pages/not-found';
import {
  Account,
  AddListing,
  Dashboard,
  Home,
  ListingDetail,
  Listings,
  Messages,
  Saved,
} from '@/pages/marketplace';
import { Notifications } from '@/pages/notifications';
import { Payments } from '@/pages/payments';
import { AdminCategories, Categories } from '@/pages/category-pages';
import {
  Route,
  Switch,
  useLocation,
  Router as WouterRouter,
} from 'wouter';

import { AdminGuard } from '@/components/admin-ui';
import { AdminLogin } from '@/pages/admin/login';
import { AdminOverview } from '@/pages/admin/overview';
import { AdminListings } from '@/pages/admin/listings';
import { AdminUsers } from '@/pages/admin/users';
import { AdminPayments } from '@/pages/admin/payments';
import { AdminPackages } from '@/pages/admin/packages';
import { AdminPaymentMethods } from '@/pages/admin/payment-methods';
import { AdminReports } from '@/pages/admin/reports';
import { AdminAuditLogs } from '@/pages/admin/audit-logs';
import { AdminNotifications } from '@/pages/admin/notifications';

const queryClient = new QueryClient();
const basePath = import.meta.env.BASE_URL.replace(/\/$/, '');
const clerkPubKey = publishableKeyFromHost(
  window.location.hostname,
  import.meta.env.VITE_CLERK_PUBLISHABLE_KEY,
);
const clerkProxyUrl = import.meta.env.VITE_CLERK_PROXY_URL;
// These imported locale objects are module-level constants. Selecting one does
// not create a new localization object or remount Clerk when language changes.
const clerkLocalizationByLanguage = {
  ar: arSA,
  fr: {
    ...frFR,
    formFieldInputPlaceholder__signUpPassword: 'Créez un mot de passe',
  },
  en: enUS,
} as const;

function stripBase(path: string): string {
  return basePath && path.startsWith(basePath)
    ? path.slice(basePath.length) || '/'
    : path;
}

function Router() {
  const { isLoaded, userId } = useAuth();
  const [location, setLocation] = useLocation();
  const isSignUpRoute = location.startsWith('/sign-up');
  const isAdminAuthRoute = location.startsWith('/admin/login');
  const isAuthRoute = location.startsWith('/sign-in') || isSignUpRoute || isAdminAuthRoute;

  useEffect(() => {
    if (!isLoaded) return;
    if (!userId && !isAuthRoute) {
      setLocation('/sign-in', { replace: true });
    } else if (userId && isAuthRoute) {
      setLocation(isAdminAuthRoute ? '/admin' : '/', { replace: true });
    }
  }, [isAuthRoute, isLoaded, setLocation, userId]);

  if (!isLoaded) return null;
  if (!userId) {
    if (isAdminAuthRoute) return <AdminLogin basePath={basePath} />;
    return isSignUpRoute ? <SignUpPage /> : <SignInPage />;
  }
  if (isAuthRoute) return null;

  return (
    // Keep a shared shell (sidebar, navbar) outside the boundary so it
    // survives a page crash.
    <RoutedErrorBoundary>
      <Switch>
        <Route path="/admin/login" component={() => <AdminLogin basePath={basePath} />} />
        <Route path="/admin/listings">{() => <AdminGuard><AdminListings /></AdminGuard>}</Route>
        <Route path="/admin/users">{() => <AdminGuard><AdminUsers /></AdminGuard>}</Route>
        <Route path="/admin/payments">{() => <AdminGuard><AdminPayments /></AdminGuard>}</Route>
        <Route path="/admin/notifications">{() => <AdminGuard><AdminNotifications /></AdminGuard>}</Route>
        <Route path="/admin/packages">{() => <AdminGuard><AdminPackages /></AdminGuard>}</Route>
        <Route path="/admin/payment-methods">{() => <AdminGuard><AdminPaymentMethods /></AdminGuard>}</Route>
        <Route path="/admin/reports">{() => <AdminGuard><AdminReports /></AdminGuard>}</Route>
        <Route path="/admin/audit-logs">{() => <AdminGuard><AdminAuditLogs /></AdminGuard>}</Route>
        <Route path="/admin/categories">{() => <AdminGuard><AdminCategories /></AdminGuard>}</Route>
        <Route path="/admin">{() => <AdminGuard><AdminOverview /></AdminGuard>}</Route>

        <Route path="/" component={Home} />
        <Route path="/listings" component={Listings} />
        <Route path="/listings/:id" component={ListingDetail} />
        <Route path="/categories" component={Categories} />
        <Route path="/saved" component={Saved} />
        <Route path="/messages" component={Messages} />
        <Route path="/notifications" component={Notifications} />
        <Route path="/payments" component={Payments} />
        <Route path="/dashboard" component={Dashboard} />
        <Route path="/account" component={Account} />
        <Route path="/add-listing" component={AddListing} />
        <Route component={NotFound} />
      </Switch>
    </RoutedErrorBoundary>
  );
}

const clerkAppearance = {
  theme: shadcn,
  cssLayerName: 'clerk',
  options: {
    logoPlacement: 'inside' as const,
    logoLinkUrl: basePath || '/',
    logoImageUrl: `${window.location.origin}${basePath}/logo.svg`,
  },
  variables: {
    colorPrimary: '#1f5948',
    colorForeground: '#173d32',
    colorMutedForeground: '#6f7f77',
    colorDanger: '#b94b3e',
    colorBackground: '#f8f6ef',
    colorInput: '#ffffff',
    colorInputForeground: '#173d32',
    colorNeutral: '#d9dfd7',
    fontFamily: 'IBM Plex Sans Arabic, sans-serif',
    borderRadius: '0.9rem',
  },
  elements: {
    rootBox: 'w-full flex justify-center',
    cardBox: 'bg-[#f8f6ef] rounded-2xl w-[440px] max-w-full overflow-hidden',
    card: '!shadow-none !border-0 !bg-transparent !rounded-none',
    footer: '!shadow-none !border-0 !bg-transparent !rounded-none',
    headerTitle: 'text-[#173d32] font-bold',
    headerSubtitle: 'text-[#6f7f77]',
     socialButtonsBlockButtonText: '!text-[#173d32]',
    formFieldLabel: 'text-[#173d32]',
    footerActionLink: 'text-[#1f5948]',
    footerActionText: 'text-[#6f7f77]',
    dividerText: 'text-[#6f7f77]',
    identityPreviewEditButton: 'text-[#1f5948]',
    formFieldSuccessText: 'text-[#1f5948]',
    alertText: 'text-[#b94b3e]',
    logoBox: 'mb-3',
    logoImage: 'rounded-xl',
     socialButtonsBlockButton: 'border-[#d9dfd7] !bg-white !text-[#173d32] hover:!bg-[#f8faf8]',
     formButtonPrimary: 'bg-[#1f5948] !text-[#ffffff] hover:bg-[#174536]',
    formFieldInput: 'border-[#d9dfd7] bg-white text-[#173d32]',
    footerAction: 'text-[#6f7f77]',
    dividerLine: 'bg-[#d9dfd7]',
    alert: 'border-[#f0c6bf] bg-[#fff6f3]',
    otpCodeFieldInput: 'border-[#d9dfd7] bg-white',
    formFieldRow: 'mb-4',
    main: 'gap-4',
  },
};

function SignInPage() {
  const { language, setLanguage, meta, t } = useLanguage();
  return (
    <div dir={meta[language].dir} className="relative flex min-h-[100dvh] items-center justify-center bg-[hsl(var(--background))] px-4">
      <ClerkPasswordToggleLocalization />
      <select value={language} onChange={(event) => setLanguage(event.target.value as typeof language)} aria-label={t('language')} className="absolute right-4 top-4 rounded-xl border border-[hsl(var(--border))] bg-white px-3 py-2 text-xs font-bold text-[hsl(var(--primary))]"><option value="ar">العربية</option><option value="fr">Français</option><option value="en">English</option></select>
      <SignIn
        routing="path"
        path={`${basePath}/sign-in`}
        signUpUrl={`${basePath}/sign-up`}
        fallbackRedirectUrl={basePath || '/'}
      />
    </div>
  );
}

function SignUpPage() {
  const { language, setLanguage, meta, t } = useLanguage();
  return (
    <div dir={meta[language].dir} className="relative flex min-h-[100dvh] items-center justify-center bg-[hsl(var(--background))] px-4">
      <select value={language} onChange={(event) => setLanguage(event.target.value as typeof language)} aria-label={t('language')} className="absolute right-4 top-4 rounded-xl border border-[hsl(var(--border))] bg-white px-3 py-2 text-xs font-bold text-[hsl(var(--primary))]"><option value="ar">العربية</option><option value="fr">Français</option><option value="en">English</option></select>
      <RequiredNameSignUp basePath={basePath} />
    </div>
  );
}

function ClerkPasswordToggleLocalization() {
  const { t } = useLanguage();

  useEffect(() => {
    const localizePasswordToggles = () => {
      document.querySelectorAll<HTMLElement>('[aria-label="Show password"], [aria-label="Hide password"]').forEach((element) => {
        const isVisible = element.getAttribute('aria-label') === 'Hide password';
        element.setAttribute('aria-label', t(isVisible ? 'hidePassword' : 'showPassword'));
      });
    };
    localizePasswordToggles();
    const observer = new MutationObserver(localizePasswordToggles);
    observer.observe(document.body, { childList: true, subtree: true });
    return () => observer.disconnect();
  }, [t]);

  return null;
}

function ClerkQueryClientCacheInvalidator() {
  const { addListener } = useClerk();
  const previousUserRef = useRef<string | null | undefined>(undefined);

  useEffect(() => {
    const unsubscribe = addListener(({ user }) => {
      const userId = user?.id ?? null;
      if (
        previousUserRef.current !== undefined &&
        previousUserRef.current !== userId
      ) {
        queryClient.clear();
      }
      previousUserRef.current = userId;
    });
    return unsubscribe;
  }, [addListener]);

  return null;
}

function ClerkApiAuthBridge({ children }: { children: ReactNode }) {
  const { getToken } = useAuth();
  const [isRegistered, setIsRegistered] = useState(false);

  useEffect(() => {
    setAuthTokenGetter(getToken);
    setIsRegistered(true);
    return () => setAuthTokenGetter(null);
  }, [getToken]);

  // Protected query hooks can start fetching as soon as their components
  // render. Register the token getter before rendering those components so
  // the first request cannot race the auth bridge effect.
  return isRegistered ? children : null;
}

function ClerkProfileNameSynchronizer() {
  const { isLoaded, user } = useUser();
  const firstName = typeof user?.unsafeMetadata?.firstName === 'string'
    ? user.unsafeMetadata.firstName.trim()
    : '';
  const lastName = typeof user?.unsafeMetadata?.lastName === 'string'
    ? user.unsafeMetadata.lastName.trim()
    : '';

  useEffect(() => {
    if (!isLoaded || !user || !firstName || !lastName) return;
    if (user.firstName === firstName && user.lastName === lastName) return;
    void user.update({ firstName, lastName }).catch((error) => {
      console.error(
        'Clerk profile name sync failed. Enable first_name and last_name in the active Clerk instance.',
        error,
      );
    });
  }, [firstName, isLoaded, lastName, user]);

  return null;
}

function RoutedErrorBoundary({ children }: { children: ReactNode }) {
  const [location] = useLocation();
  return <ErrorBoundary resetKey={location}>{children}</ErrorBoundary>;
}

function ClerkProviderWithRoutes() {
  const [, setLocation] = useLocation();
  const { language } = useLanguage();

  return (
    <ClerkProvider
      publishableKey={clerkPubKey}
      proxyUrl={clerkProxyUrl}
      appearance={clerkAppearance}
      localization={clerkLocalizationByLanguage[language]}
      signInUrl={`${basePath}/sign-in`}
      signUpUrl={`${basePath}/sign-up`}
      routerPush={(to) => setLocation(stripBase(to))}
      routerReplace={(to) => setLocation(stripBase(to), { replace: true })}
    >
      <QueryClientProvider client={queryClient}>
        <ClerkApiAuthBridge>
          <ClerkQueryClientCacheInvalidator />
          <ClerkProfileNameSynchronizer />
          <TooltipProvider>
              <Router />
              <Toaster />
          </TooltipProvider>
        </ClerkApiAuthBridge>
      </QueryClientProvider>
    </ClerkProvider>
  );
}

function App() {
  return (
    <LanguageProvider>
      <WouterRouter base={basePath}>
        <ClerkProviderWithRoutes />
      </WouterRouter>
    </LanguageProvider>
  );
}

export default App;
